#include <stdio.h>
#include <stdlib.h>
float soma(float num1);

int main()
{
    float num1,i;
    printf("Digite um numero: ");
    scanf("%f", &num1);
    printf("\nA soma da serie:  ");
    soma(num1);
    for(i=1;i<num1;i++)
    {
        printf(" 1.00/%.2f + ", i);
    }
    printf("1.00/%.2f e : %.2f\n", num1,soma(num1));

    return 0;
}
float soma(float num1)
{
    if(num1==1)
    {
       return 1;
    }
    else
    {
       return ((1/num1)+(soma(num1-1)));
    }
}
