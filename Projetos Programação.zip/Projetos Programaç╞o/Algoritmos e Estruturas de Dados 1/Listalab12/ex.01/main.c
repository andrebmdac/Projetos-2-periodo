#include <stdio.h>
#include <stdlib.h>
#include <string.h>

 typedef struct Empregado{
    int matricula;
    char nome[100];
    float salario;
 }Empregado;
Empregado VetorEmpregados[1000];
int numeroEmpregados = 0;
void lerEmpregadosArquivo(Empregado VetorEmpregados[]);
void ListaCompleta(Empregado VetorEmpregados[]);
void strSplit(char *strTOsplit,char *strArr[], char *strSeparet,int nArr);

float calculoMedia(Empregado VetorEmpregados[]);
int calculoAcimaMedia(Empregado VetorEmpregados[]);
char nomeLista(Empregado Empregados[]);
void menorSalario(Empregado Empregados[]);
float maiorSalario(Empregado Empregados[]);

int main()
{
    int qtdAcimaMedia=0;
    float maiorSal=0;
    lerEmpregadosArquivo(VetorEmpregados);
    ListaCompleta(VetorEmpregados);
    qtdAcimaMedia=calculoAcimaMedia(VetorEmpregados);
    printf("\nQuantidade de empregados com salario acima da media: %i\n\n\n", qtdAcimaMedia);
    nomeLista(VetorEmpregados);
    menorSalario(VetorEmpregados);
    maiorSal=maiorSalario(VetorEmpregados);
    printf("\nO maior salario e: %.2f\n\n\n", maiorSal);
    printf("\n\nFim do programa!\n");
    return 0;
}
void strSplit(char *strTOsplit,char *strArr[], char *strSeparet,int nArr)
        {
            int i = 0;
            char * pch;

            pch = strtok (strTOsplit,strSeparet);
            for(i = 0;i < nArr;i++)
            {
                //printf ("%s\n",pch);

                strArr[i] = pch;
                pch = strtok (NULL,strSeparet);
            }
        }

void  lerEmpregadosArquivo(Empregado VetorEmpregados[])
        {

            FILE *arquivo;
            arquivo = fopen("empregados.txt", "r");
            char linha[100];
            char *result;
            char *informacoes_linha[3];
            int i=0;
            while (!feof(arquivo))  // Enquando n�o chegar no fim do arquivo..
            {
                result = *fgets (linha, 100, arquivo);//Leitura de uma linha do arquivo...
                strSplit(linha, informacoes_linha, ";",3); //Separa os campos e os armazena no vetor de 3 posi��es chamado informacoes_linha
                //Cada posi��o do vetor VetorEmpregados guarda n�o so uma mas tres informa��es.
                VetorEmpregados[i].matricula = atoi(informacoes_linha[0]);
                strcpy(VetorEmpregados[i].nome, (const char*)(informacoes_linha[1]) );
                VetorEmpregados[i].salario = atof(informacoes_linha[2]);
                i++;
            }
            numeroEmpregados = i;
        }

 void ListaCompleta(Empregado VetorEmpregados[])
        {
			int i;
			float mediaSalarios=0;
            for (i = 0;i< numeroEmpregados; i++)
            {
                printf(" %s | %d | %.2f \n", VetorEmpregados[i].nome, VetorEmpregados[i].matricula,VetorEmpregados[i].salario);
            }
            mediaSalarios=calculoMedia(VetorEmpregados);
            printf("\nA media dos salarios dos empregados e: %.2f\n\n\n", mediaSalarios);
            printf("\nEmpregados com salario abaixo da media: \n\n");
            for(i=0;i<numeroEmpregados;i++)
            {
                if(VetorEmpregados[i].salario<mediaSalarios)
                {
                    printf(" %s | %d | %.2f \n", VetorEmpregados[i].nome, VetorEmpregados[i].matricula,VetorEmpregados[i].salario);
                }
            }
            printf("\n\n");
        }

 float calculoMedia(Empregado VetorEmpregados[])
 {
     int i;
     float somaTotal=0,mediaSalario=0;
     for(i=0;i<numeroEmpregados;i++)
     {
         somaTotal+= VetorEmpregados[i].salario;
     }
     mediaSalario=somaTotal/(numeroEmpregados*1.0);
     return mediaSalario;
 }

int calculoAcimaMedia(Empregado VetorEmpregados[])
{
    int i,cont=0;
    float media=0;
    media=calculoMedia(VetorEmpregados);
    for(i=0;i<numeroEmpregados;i++)
    {
            if(VetorEmpregados[i].salario>=media)
            {
                cont++;
            }
    }
    return cont;
}

 char nomeLista(Empregado Empregados[])
 {
     char nome[50],ch;
     int i,cont=0;
     printf("\nDigite um nome: ");
     gets(nome);
     for(i=0;i<numeroEmpregados;i++)
     {
        if(strcmp(VetorEmpregados[i].nome, nome)==0)
        {
           cont++;
        }
     }
     if(cont>0)
     {
         printf("O nome %s esta contido na lista!\n\n\n", nome);
     }
     else
     {
         printf("O nome nao esta contido na lista!\n\n\n", nome);
     }
 }

void menorSalario(Empregado Empregados[])
{
    int minimo=0,i;
    minimo=VetorEmpregados[0].salario;
    for(i=0;i<numeroEmpregados;i++)
    {
        if(minimo>VetorEmpregados[i].salario)
        {
            minimo=VetorEmpregados[i].salario;
        }
    }
    printf("\nEmpregado(s) com o(s) menor(es) salario(s): \n");
    for(i=0;i<numeroEmpregados;i++)
    {
        if(VetorEmpregados[i].salario==minimo)
        {
            printf("Nome: %s | Matricula: %i", VetorEmpregados[i].nome,VetorEmpregados[i].matricula);
        }
    }
    printf("\n\n\n");
}

float maiorSalario(Empregado Empregados[])
{
    float maximo=0;
    int i;
    maximo=VetorEmpregados[0].salario;
    for(i=0;i<numeroEmpregados;i++)
    {
        if(maximo<VetorEmpregados[i].salario)
        {
            maximo=VetorEmpregados[i].salario;
        }
    }
    return maximo;

}

