#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define tam 18

typedef struct Funcionarios{
   char nome[50];
   int horasTrab;
   float valHorasTrab;
   char turno;
   char categoria;
   float salario;
   float auxilioAlimenta;

}cadastroFuncionario;
int qtdFuncionarios=0;
cadastroFuncionario VetorFuncionarios[tam];


void cadastraFuncionario();
void calculoHoraTrabalhada();
void calculaAuxilioAlimenta();
void mostraResultado();


int main()
{
    printf("*****INICIO REGISTRO FUNCIONARIOS*****\n\n");
    cadastraFuncionario();
    printf("\n\n*****FIM REGISTRO FUNCIONARIOS*****\n\n");
    calculoHoraTrabalhada();
    calculaAuxilioAlimenta();
    mostraResultado();

    return 0;
}

void cadastraFuncionario()
{
    //cadastroFuncionario fun;
    int i=0;
    for(i=0;i<tam;i++)
    {
        fflush(stdin);
        printf("Digite o nome do funcionario: ");
        gets(VetorFuncionarios[i].nome);
        printf("Digite a quantidade de horas trabalhadas: ");
        scanf("%i", &VetorFuncionarios[i].horasTrab);
        do{
            printf("Digite o turno de trabalho(M,V,N): ");
            scanf(" %c", &VetorFuncionarios[i].turno);
            if(VetorFuncionarios[i].turno!='m' && VetorFuncionarios[i].turno!='v' && VetorFuncionarios[i].turno!='n')
            {
                 printf("   *Opcao invalida*   \n");
            }
        }while(VetorFuncionarios[i].turno!='m' && VetorFuncionarios[i].turno!='v' && VetorFuncionarios[i].turno!='n');
        do{
            printf("Digite o cargo do funcionario(O,G): ");
            scanf(" %c", &VetorFuncionarios[i].categoria);
            if(VetorFuncionarios[i].categoria!='o' && VetorFuncionarios[i].categoria!='g')
            {
                printf("   *Opcao invalida*   \n");
            }
        }while(VetorFuncionarios[i].categoria!='o' && VetorFuncionarios[i].categoria!='g');
        printf("\n");
    }
}

void calculoHoraTrabalhada()
{
    int i;
    for(i=0;i<tam;i++)
    {
        if(VetorFuncionarios[i].categoria=='g')
        {
            if(VetorFuncionarios[i].turno=='n')
            {
                VetorFuncionarios[i].valHorasTrab=(950.00*0.18);
                VetorFuncionarios[i].salario=((VetorFuncionarios[i].valHorasTrab*VetorFuncionarios[i].horasTrab)*1.0);
            }
            else
            {
                VetorFuncionarios[i].valHorasTrab=(950.00*0.15);
                VetorFuncionarios[i].salario=((VetorFuncionarios[i].valHorasTrab*VetorFuncionarios[i].horasTrab)*1.0);
            }
        }
        else
        {
            if(VetorFuncionarios[i].turno=='n')
            {
                VetorFuncionarios[i].valHorasTrab=(950.00*0.13);
                VetorFuncionarios[i].salario=((VetorFuncionarios[i].valHorasTrab*VetorFuncionarios[i].horasTrab)*1.0);
            }
            else
            {
                VetorFuncionarios[i].valHorasTrab=(950.00*0.10);
                VetorFuncionarios[i].salario=((VetorFuncionarios[i].valHorasTrab*VetorFuncionarios[i].horasTrab)*1.0);
            }
        }
    }
}

void calculaAuxilioAlimenta()
{
    int i=0;
    float valorAuxilio=0;
    for(i=0;i<tam;i++)
    {
        if(VetorFuncionarios[i].salario<950)
        {
            VetorFuncionarios[i].auxilioAlimenta=(VetorFuncionarios[i].salario*0.2);
        }
        else if(VetorFuncionarios[i].salario>=950 && VetorFuncionarios[i].salario<1500)
        {
            VetorFuncionarios[i].auxilioAlimenta=(VetorFuncionarios[i].salario*0.15);
        }
        else if(VetorFuncionarios[i].salario>=1500)
        {
            VetorFuncionarios[i].auxilioAlimenta=(VetorFuncionarios[i].salario*0.05);
        }
    }

}

void mostraResultado()
{
    int i,cont=0;
    float salarioFinal=0;
    for(i=0;i<tam;i++)
    {
        salarioFinal=0;
        printf("Nome: %s\n", VetorFuncionarios[i].nome);
        printf("Numero de horas trabalhadas: %i\n", VetorFuncionarios[i].horasTrab);
        printf("Valor hora trabalhada: %.2f\n", VetorFuncionarios[i].valHorasTrab);
        printf("Salario inicial: %.2f\n", VetorFuncionarios[i].salario);
        printf("Auxilio alimentacao: %.2f\n", VetorFuncionarios[i].auxilioAlimenta);
        salarioFinal=VetorFuncionarios[i].salario+VetorFuncionarios[i].auxilioAlimenta;
        printf("Salario final: %.2f\n\n", salarioFinal);
    }
}
