#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define tam 20

typedef struct Pessoas{
   char sexo;
   float altura,peso;
}cadastroPessoa;
int quantPessoas=0;
cadastroPessoa VetorPessoas[tam];


void cadastraPessoa();
void calculaPesoMedio();
void calculaAlturaMedia();
void mostraSexoPessoa();
void mostraAlturaHomem();
void mostraAlturaMulher();


int main()
{
    int opcao=0;
    printf("*****MENU*****");
    printf("\n 1 - Cadastrar pessoa");
    printf("\n 2 - Calcular peso medio");
    printf("\n 3 - Calcular altura media");
    printf("\n 4 - Mostrar sexo da pessoa mais alta");
    printf("\n 5 - Mostrar altura do homem mais pesado");
    printf("\n 6 - Mostrar altura da mulher mais pesada");
    printf("\n 7 - Sair do programa\n");
    do{
        printf("\n*Digite a opcao desejada: ");
        scanf("%i", &opcao);
        switch(opcao)
        {
           case 1:
               printf("\n***ENTRANDO NA OPCAO 1***\n\n");
               cadastraPessoa();
               printf("\n***SAINDO DA OPCAO 1***\n\n");
               break;
           case 2:
               printf("\n***ENTRANDO NA OPCAO 2***\n\n");
               calculaPesoMedio();
               printf("\n***SAINDO DA OPCAO 2***\n\n");
               break;
           case 3:
               printf("\n***ENTRANDO NA OPCAO 3***\n\n");
               calculaAlturaMedia();
               printf("\n***SAINDO DA OPCAO 3***\n\n");
               break;
           case 4:
               printf("\n***ENTRANDO NA OPCAO 4***\n\n");
                mostraSexoPessoa();
               printf("\n***SAINDO DA OPCAO 4***\n\n");
               break;
            case 5:
               printf("\n***ENTRANDO NA OPCAO 5***\n\n");
                mostraAlturaHomem();
               printf("\n***SAINDO DA OPCAO 5***\n\n");
               break;
            case 6:
               printf("\n***ENTRANDO NA OPCAO 6***\n\n");
                mostraAlturaMulher();
               printf("\n***SAINDO DA OPCAO 6***\n\n");
               break;
           case 7:
               printf("\nSaindo do programa\n");
               break;
           default:
               printf("\nOpcao invalida!\n");

        }
    }while(opcao<7);
    return 0;
}

void cadastraPessoa()
{
    int i=0;
    printf("Digite 'x' em sexo para sair dessa opcao\n\n");
    do{
        printf("Digite seu sexo(M,F): ");
        scanf(" %c", &VetorPessoas[i].sexo);
        if(VetorPessoas[i].sexo!='x')
        {
            printf("Digite sua altura(em CM): ");
            scanf("%f", &VetorPessoas[i].altura);
            printf("Digite seu peso(em KG): ");
            scanf("%f", &VetorPessoas[i].peso);
        }
        i++;
        printf("\n");
    }while(VetorPessoas[i-1].sexo!='x');
    quantPessoas=i-1;
}

void calculaPesoMedio()
{
    int i;
    float soma=0,media=0;
    for(i=0;i<quantPessoas;i++)
    {
        soma+=VetorPessoas[i].peso;
    }
    media=soma/(quantPessoas*1.0);
    printf("A media dos pesos das pessoas cadastradas e: %.2f\n", media);
}

void calculaAlturaMedia()
{
    int i=0;
    float soma=0,media=0;
    for(i=0;i<quantPessoas;i++)
    {
        soma+=VetorPessoas[i].altura;
    }
    media=soma/(quantPessoas*1.0);
    printf("A media das alturas das pessoas cadastradas e: %.2f\n", media);
}

void mostraSexoPessoa()
{
    int i=0,opcao=0;
    float alturaMax=0;
    alturaMax=VetorPessoas[0].altura;
    for(i=0;i<quantPessoas;i++)
    {
        if(VetorPessoas[i].altura>alturaMax)
        {
            alturaMax=VetorPessoas[i].altura;
            if(VetorPessoas[i].sexo=='m')
            {
                opcao=1;
            }
            else
            {
                opcao=2;
            }
        }
    }
    printf("A pessoa mais alta tem %.2f | Sexo: ", alturaMax);
    if(opcao==1)
    {
        printf("masculino\n");
    }
    else
    {
        printf("feminino\n");
    }
}

void mostraAlturaHomem()
{
    int i,cont=0;
    float pesoMax=0,alturaMax=0;
    pesoMax=VetorPessoas[0].peso;
    for(i=0;i<quantPessoas;i++)
    {
        if(VetorPessoas[i].sexo=='m')
        {
            cont++;
            if(VetorPessoas[i].peso>pesoMax)
            {
                pesoMax=VetorPessoas[i].peso;
                alturaMax=VetorPessoas[i].altura;
            }
        }
    }
    if(cont==0)
    {
        printf("Nao ha homens para serem avaliados!\n");
    }
    else
    {
        printf("O homem mais pesado mede: %.2f\n", alturaMax);
    }
}

void mostraAlturaMulher()
{
    int i,cont=0;
    float pesoMax=0,alturaMax=0;
    pesoMax=VetorPessoas[0].peso;
    for(i=0;i<quantPessoas;i++)
    {
        if(VetorPessoas[i].sexo=='f')
        {
            cont++;
            if(VetorPessoas[i].peso>pesoMax)
            {
                pesoMax=VetorPessoas[i].peso;
                alturaMax=VetorPessoas[i].altura;
            }
        }
    }
    if(cont==0)
    {
        printf("Nao ha mulheres para serem avaliadas!\n");
    }
    else
    {
        printf("A mulher mais pesada mede: %.2f\n", alturaMax);
    }
}
