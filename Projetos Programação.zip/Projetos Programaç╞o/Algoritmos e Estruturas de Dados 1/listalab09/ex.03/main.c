#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char frase[200];
    int i,tam;
    printf("Digite uma frase: ");
    gets(frase);
    tam=strlen(frase);
    for(i=0;i<tam;i++)
    {
        if(frase[i]=='a' || frase[i]=='e' || frase[i]=='i' || frase[i]=='o' || frase[i]=='u')
        {
            frase[i]='*';
        }
    }
    printf("Frase criptografada: %s\n", frase);
    return 0;
}
