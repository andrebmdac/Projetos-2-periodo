#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char nome[100],letra[10],login[20];
    int pos[10],indice=0,quant=0,i,tam,j,a=0,tamletra=0,tamlogin=0;
    fflush(stdin);
    printf("Digite seu nome e sobrenome: ");
    gets(nome);
    tam=strlen(nome);
    for(i=0,j=0;i<tam;i++)
    {
        if(nome[i]==' ')
        {
            letra[j]=nome[i+1];
            pos[a]=i+1;
            a++;
            j++;
            quant++;
        }
    }
    strncpy(login,nome, 1);
    tamletra=strlen(letra);
    strcat(login, letra);
    tamlogin=strlen(login);
    if(quant==1)
    {
        indice=pos[0]+1;
        for(i=indice,a=2;i<tam;i++, a++)
        {
            login[a]=nome[i];
        }
    }
    else
    {
        indice=pos[quant-1];
        for(i=indice,a=2;i<tam ;i++ , a++)
        {
            login[a]=nome[i];
        }
    }
    for(i=0; i<tam; i++)
    {
        if(nome[i]==' ')
        {
            nome[i+1]=toupper(nome[i+1]);
        }

    }
    nome[0]=toupper(nome[0]);
    fflush(stdin);
    printf("Nome: %s", nome);
    fflush(stdin);
    printf("\nLogin: %s\n", login);


    return 0;
}
