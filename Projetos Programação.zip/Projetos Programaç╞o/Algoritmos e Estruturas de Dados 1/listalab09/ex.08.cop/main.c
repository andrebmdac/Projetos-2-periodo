#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
   char frase[30],c;
   int tam, quant=0;
   printf("Digite uma frase: ");
   gets(frase);
   printf("Digite uma letra: ");
   scanf(" %c", &c);
   tam=strlen(frase);
   verletra(c,frase,tam,quant);

  return 0;
}

void verletra(char c,char frase[],int tam,int quant)
{
    if(tam==0)
    {
        if(quant!=0)
        {
            printf("\nA letra ESTA presente na frase!\n");
        }
        else
        {
            printf("\nA letra NAO esta presente na frase!\n");
        }
    }
    else
    {
        if(frase[tam]==c)
        {
            quant++;
            return verletra(c,frase,(tam-1),quant);
        }
        else
        {
            return verletra(c,frase,(tam-1),quant);
        }
    }
}
