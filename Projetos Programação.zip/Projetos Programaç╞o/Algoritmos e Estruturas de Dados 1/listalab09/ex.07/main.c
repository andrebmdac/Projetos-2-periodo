#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main()
{
    char frase[50],frase2[50];
    int i,j,tam,valor;
    fflush(stdin);
    printf("Digite uma frase: ");
    gets(frase);
    strcpy(frase2, frase);
    strrev(frase2);
    tam=strlen(frase);
    printf("\nFrase 1: %s", frase);
    printf("\nFrase 2: %s", frase2);
    for(i=0; i<tam; i++)
    {
        if(frase[i] == ' ')
        {
            for(j=i; j<tam; j++)
            {
                frase[j] = frase[j+1];
            }
        }
    }
    for(i=0; i<tam; i++)
    {
        if(frase2[i] == ' ')
        {
            for(j=i; j<tam; j++)
            {
                frase2[j] = frase2[j+1];
            }
        }
    }
    printf("\nFrase 1 sem espaco: %s", frase);
    printf("\nFrase 2 sem espaco: %s\n", frase2);
    valor=strcmp(frase,frase2);
    if(valor==0)
    {
        printf("\nA frase digitada e um palindromo!\n");
    }
    else
    {
        printf("\nA frase digitada NAO e um palindromo!\n");
    }

    return 0;
}
