#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char frase[100],letra;
    int tam,i,pos=0;
    printf("Digite uma frase: ");
    gets(frase);
    printf("\nDigite uma letra base: ");
    scanf(" %c", &letra);
    tam=strlen(frase);
    for(i=0;i<tam;i++)
    {
        if(frase[i]==letra)
        {
            pos=i;
        }
        else
        {
            pos=101;
        }
    }
    letra=toupper(letra);
    if(pos==101)
    {
        printf("\nA letra %c nao esta contida na frase!\n", letra);
    }
    else
    {
        printf("\nA letra %c aparece na posicao: %i\n", letra,pos+1);
    }
    return 0;
}
