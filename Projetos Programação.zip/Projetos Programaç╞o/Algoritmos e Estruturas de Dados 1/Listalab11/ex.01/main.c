#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct Data
{
    int dia,mes,ano;
}data;

typedef struct Clientes
{
    int codigoCliente;
    char nome[100];
    char endereco[200];
}cadastroCliente;

typedef struct Recebimentos
{
    int codigoCliente;
    int numero_doc;
    int valor_doc;
    data data_emissao;
    data data_vencimento;
}cadastroRecebimento;

cadastroCliente vetorCliente[1000];
cadastroRecebimento vetorRecebimento[1000];

int qtdClientes=0;
int qtdRecebimentos=0;


void lerArquivoCliente(cadastroCliente vetorCliente[]);
void escreverArquivoCliente(cadastroCliente vetorCliente[]);
void lerArquivoRecebimentos(cadastroRecebimento vetorRecebimento[]);
void separaDados(char *linhas,char *dados_linha[], char *marcador,int qtdDados_linha);
void cadastrarCliente();
void cadastrarRecebimento();
void excluirCliente();
void excluirRecebimento(int codigo);
void alteraCadastroCliente();
void alteraRecebimento();
void mostraRecebimentosData();
void mostraRecebimentosCliente();


// CLIENTE - CODIGO/NOME/ENDERECO
// RECEBIMENTO - CODIGO/NUMERO_DOC/VALOR_DOC/DATA_EMISSAO/DATA_VENCIMENTO


int main()
{
    int opcao=0;
    printf("*****MENU***** \n2-Cadastrar cliente\n3-Cadastrar recebimento\n4-Excluir cliente\n5-Alterar cadastro cliente\n6-Alterar recebimento cliente\n7-Mostrar recebimentos no periodo\n8-Mostrar recebimentos cliente\n9-Sair do programa \n");
    do
    {
        printf("\n*Digite a opcao desejada: ");
        scanf("%i", &opcao);
         switch(opcao)
         {
            case 2:
                printf("\n*****CADASTRO CLIENTE*****\n\n");
               cadastrarCliente();
               break;
            case 3:
                printf("\n*****CADASTRO RECEBIMENTO*****\n\n");
               cadastrarRecebimento();
               break;
             case 4:
                 printf("\n*****EXCLUIR CLIENTE*****\n\n");
               excluirCliente();
               break;
            case 5:
                printf("\n*****ALTERAR CADASTRO CLIENTE*****\n\n");
               alteraCadastroCliente();
               break;
            case 6:
                printf("\n*****ALTERAR RECEBIMENTO CLIENTE*****\n\n");
               alteraRecebimento();
               break;
            case 7://
                printf("\n*****MOSTRAR RECEBIMENTO POR DATA*****\n\n");
               mostraRecebimentosData();
               break;
            case 8://
                printf("\n*****MOSTRAR RECEBIMENTO CLIENTE*****\n\n");
                mostraRecebimentosCliente();
               break;
            case 9:
                printf("\n\nSaindo do programa!\n");
               break;
            default:
                printf("\nOpcao invalida!\n");
               break;
         }

    }while(opcao!=9 && opcao>0);

    return 0;
}

//FUNCOES IVRE//
void separaDados(char *linhas,char *dados_linha[], char *marcador,int qtdDados_linha)
{
    int i = 0;
    char *result;
    result = strtok (linhas,marcador);
    for(i=0;i < qtdDados_linha;i++)
    {
        dados_linha[i] = result;
        result = strtok (NULL,marcador);
    }
}

void lerArquivoCliente(cadastroCliente vetorCliente[])//prob mostrar recebimentos aqui
{
    FILE *arquivo;
    arquivo=fopen("Clientes.txt", "r");
    char linhas[100];
    char *result;
    char *dados_linha[3];
    int i=0;
    fseek(arquivo,0,SEEK_END);
      if(ftell(arquivo)!=0)
      {
          fseek(arquivo,0,SEEK_SET);
          while(!feof(arquivo))
          {
            result = fgets(linhas,100,arquivo);
            separaDados(linhas, dados_linha, "|", 3);
            vetorCliente[i].codigoCliente= atoi(dados_linha[0]);
            strcpy(vetorCliente[i].nome, (const char*)(dados_linha[1]));
            strcpy(vetorCliente[i].endereco, (const char*)(dados_linha[2]));
            i++;
          }
          qtdClientes=i;
      }
}

void lerArquivoRecebimentos(cadastroRecebimento vetorRecebimento[])
{
    FILE *arquivo;
    arquivo=fopen("Recebimentos.txt", "r");
    char linhas[100];
    char *result;
    char *dados_linha[5];
    int i=0;
    fseek(arquivo,0,SEEK_END);
      if(ftell(arquivo)!=0)
      {
          fseek(arquivo,0,SEEK_SET);
          while(!feof(arquivo))
          {
            // RECEBIMENTO - CODIGO/NUMERO_DOC/VALOR_DOC/DATA_EMISSAO/DATA_VENCIMENTO
            result = fgets(linhas,100,arquivo);
            separaDados(linhas, dados_linha, "|", 5);
            vetorRecebimento[i].codigoCliente= atoi(dados_linha[0]);
            vetorRecebimento[i].numero_doc= atoi(dados_linha[1]);
            vetorRecebimento[i].valor_doc= atoi(dados_linha[2]);
            vetorRecebimento[i].data_emissao.dia= atoi(dados_linha[3]);
            vetorRecebimento[i].data_emissao.mes= atoi(dados_linha[3]);
            vetorRecebimento[i].data_emissao.ano= atoi(dados_linha[3]);
            vetorRecebimento[i].data_vencimento.dia= atoi(dados_linha[4]);
            vetorRecebimento[i].data_vencimento.mes= atoi(dados_linha[4]);
            vetorRecebimento[i].data_vencimento.ano= atoi(dados_linha[4]);
            i++;
          }
          qtdRecebimentos=i;
      }
}

 void escreverArquivoCliente(cadastroCliente vetorCliente[])
 {
     int i;
     for (i = 0; i < qtdClientes; i++)
     {
         printf("\nCodigo cliente: %i | Nome: %s | Endereco: Rua %s ", vetorCliente[i].codigoCliente, vetorCliente[i].nome,vetorCliente[i].endereco);
     }
 }



//FUNCOES ANDRE//
void cadastrarCliente()
{
     FILE *arqClientes=fopen("Clientes.txt", "a");
     cadastroCliente cliente;
     fseek(arqClientes,0,SEEK_END);
     int i,codigo=0,marcador=0;
     if(ftell(arqClientes)!=0)
     {
        fputc('\n', arqClientes);
        do
        {
           codigo=0;
           marcador=0;
           printf("Digite um numero para codigo do cliente(entre 1 e 9999): ");
           scanf("%d", &codigo);
           lerArquivoCliente(vetorCliente);
           for(i=0;i<qtdClientes;i++)
           {
               if(vetorCliente[i].codigoCliente==codigo)
               {
                    printf("Codigo ja em uso.\n\n");
                    marcador++;
               }
           }
        }while(marcador>0);
        cliente.codigoCliente=codigo;
        fflush(stdin);
        printf("Digite o nome do cliente: ");
        gets(cliente.nome);
        fflush(stdin);
        printf("Digite o endereco do cliente: ");
        gets(cliente.endereco);
        fprintf(arqClientes, "%04i", cliente.codigoCliente);
        fputs("|", arqClientes);
        fputs(cliente.nome, arqClientes);
        fputs("|", arqClientes);
        fputs(cliente.endereco, arqClientes);
     }
     else if(ftell(arqClientes)==0)
     {
         printf("Digite um numero para codigo do cliente(entre 1 e 1000): ");
         scanf("%i", &cliente.codigoCliente);
         fflush(stdin);
         printf("Digite o nome do cliente: ");
         gets(cliente.nome);
         fflush(stdin);
         printf("Digite o endereco do cliente: ");
         gets(cliente.endereco);
         fprintf(arqClientes, "%04i", cliente.codigoCliente);
         fputs("|", arqClientes);
         fputs(cliente.nome, arqClientes);
         fputs("|", arqClientes);
         fputs(cliente.endereco, arqClientes);
     }
     fclose(arqClientes);
}

void cadastrarRecebimento()
{
     FILE *arqRecebimentos=fopen("Recebimentos.txt", "a");
     fseek(arqRecebimentos,0,SEEK_END);
     cadastroRecebimento rec;
     int i=0,codigo=0,existencia=0,posicao=0;
     printf("Digite o codigo de cliente: ");
     scanf("%04i", &codigo);
     lerArquivoCliente(vetorCliente);
     for(i=0;i<qtdClientes;i++)
     {
         if(vetorCliente[i].codigoCliente==codigo)
         {
             existencia++;
             posicao=i;
         }
     }
     if(existencia==1)
     {
        printf("Codigo encontrado com sucesso!\n\n");
        if(ftell(arqRecebimentos)!=0)
        {
            fputc('\n', arqRecebimentos);
            rec.codigoCliente=codigo;
            printf("Digite o numero do documento: ");
            scanf("%i", &rec.numero_doc);
            printf("Digite o valor do documento: ");
            scanf("%i", &rec.valor_doc);
            printf("Digite a data de emissao: ");
            scanf("%02i %02i %i", &rec.data_emissao.dia,&rec.data_emissao.mes,&rec.data_emissao.ano);
            printf("Digite a data de vencimento: ");
            scanf("%02i %02i %i", &rec.data_vencimento.dia,&rec.data_vencimento.mes,&rec.data_vencimento.ano);
            fprintf(arqRecebimentos, "%04i", rec.codigoCliente);
            fputs("|", arqRecebimentos);
            fprintf(arqRecebimentos, "%i", rec.numero_doc);
            fputs("|", arqRecebimentos);
            fprintf(arqRecebimentos, "%i", rec.valor_doc);
            fputs("|", arqRecebimentos);
            fprintf(arqRecebimentos, "%02i/%02i/%i", rec.data_emissao.dia,rec.data_emissao.mes,rec.data_emissao.ano);
            fputs("|", arqRecebimentos);
            fprintf(arqRecebimentos, "%02i/%02i/%i", rec.data_vencimento.dia,rec.data_vencimento.mes,rec.data_vencimento.ano);
        }
        else
        {
            rec.codigoCliente=codigo;
            printf("Digite o numero do documento: ");
            scanf("%i", &rec.numero_doc);
            printf("Digite o valor do documento: ");
            scanf("%i", &rec.valor_doc);
            printf("Digite a data de emissao: ");
            scanf("%02i %02i %i", &rec.data_emissao.dia,&rec.data_emissao.mes,&rec.data_emissao.ano);
            printf("Digite a data de vencimento: ");
            scanf("%02i %02i %i", &rec.data_vencimento.dia,&rec.data_vencimento.mes,&rec.data_vencimento.ano);
            fprintf(arqRecebimentos, "%04i", rec.codigoCliente);
            fputs("|", arqRecebimentos);
            fprintf(arqRecebimentos, "%i", rec.numero_doc);
            fputs("|", arqRecebimentos);
            fprintf(arqRecebimentos, "%i", rec.valor_doc);
            fputs("|", arqRecebimentos);
            fprintf(arqRecebimentos, "%02i/%02i/%i", rec.data_emissao.dia,rec.data_emissao.mes,rec.data_emissao.ano);
            fputs("|", arqRecebimentos);
            fprintf(arqRecebimentos, "%02i/%02i/%i", rec.data_vencimento.dia,rec.data_vencimento.mes,rec.data_vencimento.ano);
        }
    fclose(arqRecebimentos);
    }
    else
    {
        int escolha=0;
        printf("Codigo de cliente nao encontrado. Deseja cadastrar agora? 1-Sim | 2-Nao: ");
        scanf("%i", &escolha);
        printf("\n");
        if(escolha==1)
        {
            cadastrarCliente();
        }
    }

}

void excluirCliente()
{
   lerArquivoCliente(vetorCliente);
   FILE *arqClientes = fopen("Clientes.txt", "w");
   fseek(arqClientes, 0, SEEK_SET);
   int i=0, codigo=0, posicao=0;
   printf("Digite o codigo do cliente que deseja excluir: ");
   scanf("%04i", &codigo);
   int cont=0;
   for(i=0; i<qtdClientes; i++)
   {
       if(vetorCliente[i].codigoCliente==codigo)
       {
           printf("Cliente encontrado!\n");
           posicao=i;
           cont++;
       }
       else if(vetorCliente[i].codigoCliente!=codigo)
       {
           if(cont==0)
           {
               printf("Codigo nao encontrado!\n");
               cont++;
           }
       }
   }
   for(i=0; i<qtdClientes; i++)
   {
       if(i!=posicao)
       {
            fprintf(arqClientes, "%04i", vetorCliente[i].codigoCliente);
            fputc('|', arqClientes);
            fprintf(arqClientes, "%s", vetorCliente[i].nome);
            fputc('|', arqClientes);
            fprintf(arqClientes, "%s", vetorCliente[i].endereco);
            if(i==posicao && i!=qtdClientes-1)
            {
                fputc('\n', arqClientes);
            }
       }
   }
   fclose(arqClientes);
   //excluirRecebimento(codigo);
}

void excluirRecebimento(int codigo)
{
   lerArquivoRecebimentos(vetorRecebimento);
   FILE *arqClientes = fopen("Recebimentos.txt", "w");
   fseek(arqClientes, 0, SEEK_SET);
   cadastroRecebimento rec;
   int i=0,posicao=0;
   int cont=0;
   for(i=0; i<qtdClientes; i++)
   {
       if(vetorRecebimento[i].codigoCliente==codigo)
       {
           //printf("Cliente encontrado!\n");
           posicao=i;
       }
   }
   for(i=0; i<qtdRecebimentos; i++)
   {
       if(i!=posicao)
       {
            rec.codigoCliente=codigo;
            fprintf(arqClientes, "%04i", rec.codigoCliente);
            fputs("|", arqClientes);
            fprintf(arqClientes, "%i", rec.numero_doc);
            fputs("|", arqClientes);
            fprintf(arqClientes, "%i", rec.valor_doc);
            fputs("|", arqClientes);
            fprintf(arqClientes, "%02i/%02i/%i", rec.data_emissao.dia,rec.data_emissao.mes,rec.data_emissao.ano);
            fputs("|", arqClientes);
            fprintf(arqClientes, "%02i/%02i/%i", rec.data_vencimento.dia,rec.data_vencimento.mes,rec.data_vencimento.ano);
            if(i==posicao && i!=qtdClientes-1)
            {
                fputc('\n', arqClientes);
            }
       }
   }
   fclose(arqClientes);
}

void alteraCadastroCliente()
{
   lerArquivoCliente(vetorCliente);
   FILE *arqClientes = fopen("Clientes.txt", "w");
   fseek(arqClientes,0,SEEK_END);
   int codigo=0, i=0, posicao=0;
   printf("Digite o codigo do cliente que deseja mudar as informacoes: ");
   scanf("%04i", &codigo);
   for(i=0; i<qtdClientes; i++)
   {
        if(vetorCliente[i].codigoCliente==codigo)
        {
          posicao=i;
        }
   }
   fflush(stdin);
   printf("Digite o nome do cliente para alteracao: ");
   gets(vetorCliente[posicao].nome);
   fflush(stdin);
   printf("Digite o endereco do cliente para alteracao: ");
   gets(vetorCliente[posicao].endereco);
   //fseek(arqClientes, 0, SEEK_SET);
   for(i=0; i<qtdClientes; i++)
    {
        fprintf(arqClientes, "%04i", vetorCliente[i].codigoCliente);
        fputc('|', arqClientes);
        fprintf(arqClientes, "%s", vetorCliente[i].nome);
        fputc('|', arqClientes);
        fprintf(arqClientes, "%s", vetorCliente[i].endereco);
        if(i==posicao && i!=qtdClientes-1)
        {
            fputc('\n', arqClientes);
        }
    }
   fclose(arqClientes);
}


void alteraRecebimento()
{
   lerArquivoCliente(vetorCliente);
   FILE *arqClientes = fopen("Recebimentos.txt", "w");
   fseek(arqClientes,0,SEEK_END);
   int numero=0, i=0, posicao=0;
   printf("Digite o numero do documento que deseja mudar as informacoes: ");
   scanf("%i", &numero);
   for(i=0; i<qtdClientes; i++)
   {
        if(vetorRecebimento[i].numero_doc==numero)
        {
          posicao=i;
        }
   }
   printf("Digite o valor do documento: ");
   scanf("%i", &vetorRecebimento[posicao].valor_doc);
   printf("Digite a data de emissao: ");
   scanf("%02i %02i %i", &vetorRecebimento[posicao].data_emissao.dia,&vetorRecebimento[posicao].data_emissao.mes,&vetorRecebimento[posicao].data_emissao.ano);
   printf("Digite a data de vencimento: ");
   scanf("%02i %02i %i", &vetorRecebimento[posicao].data_emissao.dia,&vetorRecebimento[posicao].data_emissao.mes,&vetorRecebimento[posicao].data_emissao.ano);
   for(i=0; i<qtdClientes; i++)
   {
        fprintf(arqClientes, "%04i", vetorRecebimento[i].codigoCliente);
        fputc('|', arqClientes);
        fprintf(arqClientes, "%i", vetorRecebimento[i].valor_doc);
        fputc('|', arqClientes);
        fprintf(arqClientes, "%02i/%02i/%i", vetorRecebimento[i].data_emissao.dia,vetorRecebimento[i].data_emissao.mes,vetorRecebimento[i].data_emissao.ano);
        fputc('|', arqClientes);
        fprintf(arqClientes, "%02i/%02i/%i", vetorRecebimento[i].data_vencimento.dia,vetorRecebimento[i].data_vencimento.mes,vetorRecebimento[i].data_vencimento.ano);
        if(i==posicao && i!=qtdClientes-1)
        {
            fputc('\n', arqClientes);
        }
   }
   fclose(arqClientes);
}


void mostraRecebimentosData()
{
    lerArquivoRecebimentos(vetorRecebimento);
    FILE *arqClientes = fopen("Clientes.txt", "r");
    fseek(arqClientes,0,SEEK_END);
    int idia,imes,iano,fdia,fmes,fano,i,cont=0;
    printf("Digite a data inicial: ");
    scanf("%02i %02i %i", &idia,&imes,&iano);
    printf("Digite a data final: ");
    scanf("%02i %02i %i", &fdia,&fmes,&fano);
    for(i=0;i<qtdRecebimentos;i++)
    {
        printf("Entrou 1\n");
        if(vetorRecebimento[i].data_vencimento.ano>=iano && vetorRecebimento[i].data_vencimento.ano<=fano)
        {
            printf("Entrou 2\n");
            if(vetorRecebimento[i].data_vencimento.mes>=imes && vetorRecebimento[i].data_vencimento.mes<=fmes)
            {
                printf("Entrou 3\n");
                if(vetorRecebimento[i].data_vencimento.dia>=idia && vetorRecebimento[i].data_vencimento.dia<=fdia)
                {
                    printf("\n***RECEBIMENTO %i***\n\n", cont+1);
                    printf("Codigo cliente: %04i", vetorRecebimento[i].codigoCliente);
                    printf("\nNumero documento: %i", vetorRecebimento[i].numero_doc);
                    printf("\nValor documento: %i", vetorRecebimento[i].valor_doc);
                    printf("\nData de emissao: %02i/%02i/%i", vetorRecebimento[i].data_emissao.dia,vetorRecebimento[i].data_emissao.mes,vetorRecebimento[i].data_emissao.ano);
                    printf("\nData de vencimento: %02i/%02i/%i\n\n", vetorRecebimento[i].data_vencimento.dia,vetorRecebimento[i].data_vencimento.mes,vetorRecebimento[i].data_vencimento.ano);
                    cont++;
                }
            }
        }
    }
}


void mostraRecebimentosCliente()
{
   lerArquivoRecebimentos(vetorRecebimento);
   FILE *arqClientes = fopen("Clientes.txt", "r");
   fseek(arqClientes,0,SEEK_END);
   int codigo=0, i=0,cont=0,teste=0;
   printf("Digite o codigo do cliente que deseja pesquisar: ");
   scanf("%04i", &codigo);
   for(i=0; i<qtdRecebimentos; i++)
   {
        if(vetorRecebimento[i].codigoCliente==codigo)
        {
            printf("\n***RECEBIMENTO %i***\n\n", cont+1);
            printf("Codigo cliente: %04i", vetorRecebimento[i].codigoCliente);
            printf("\nNumero documento: %i", vetorRecebimento[i].numero_doc);
            printf("\nValor documento: %i", vetorRecebimento[i].valor_doc);
            printf("\nData de emissao: %02i/%02i/%i", vetorRecebimento[i].data_emissao.dia,vetorRecebimento[i].data_emissao.mes,vetorRecebimento[i].data_emissao.ano);
            printf("\nData de vencimento: %02i/%02i/%i\n\n", vetorRecebimento[i].data_vencimento.dia,vetorRecebimento[i].data_vencimento.mes,vetorRecebimento[i].data_vencimento.ano);
            cont++;
            teste++;
        }
   }
   if(teste==0)
   {
       printf("O cliente nao possui recebimentos!\n");
   }
}





