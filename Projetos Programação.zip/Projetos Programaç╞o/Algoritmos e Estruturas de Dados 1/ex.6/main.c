#include <stdio.h>
#include <stdlib.h>
int calcmdc(int n1,int n2);
int testmdc(int n1,int n2,int res);

int main()
{
    int n1,n2,res,res2;
    printf("Digite dois numeros e vou dizer o MDC deles\n");
    printf("\nDigite o primeiro numero: ");
    scanf("%i", &n1);
    printf("Digite o segundo numero: ");
    scanf("%i", &n2);
    res=calcmdc(n1,n2);
    printf("\nO MDC calculado e: %i\n", calcmdc(n1,n2));
    res2=testmdc(n1,n2,res);
    if(res2==2)
    {
        printf("\nO MDC esta correto!\n");
    }
    else
    {
        printf("\nO MDC foi calculado errado!\n");
    }

    return 0;
}
int calcmdc(int n1,int n2)
{
    if(n1>n2)
    {
        return calcmdc((n1-n2), n2);
    }
    else if(n2>n1)
    {
        return calcmdc(n1,(n2-n1));
    }
    else
        return n1;
}


int testmdc(int n1,int n2,int res)
{
    int cont=0;
    if(n1%res==0)
    {
        cont ++;
    }
    if(n2%res==0)
    {
        cont ++;
    }

return cont;
}
