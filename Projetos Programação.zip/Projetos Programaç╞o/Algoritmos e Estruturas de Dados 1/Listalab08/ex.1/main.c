#include <stdio.h>
#include <stdlib.h>
#define tam 15
int calcvet(int nume[]);

int main()
{
    int nume[tam],i;
    for(i=0; i<tam; i++)
    {
        printf("Digite um numero: ");
        scanf("%i", &nume[i]);
    }
    calcvet(nume);
    return 0;
}

int calcvet(int nume[])
{
    int i,j,aux,ig2=0,mult3,posmult2;
    for(i=0;i<tam;i++)
    {
        if(nume[i] == 2)
        {
            ig2++;
        }
    }
    printf("\n%i posicoes tem elementos iguais a 2\n", ig2);
    for(i=0;i<tam;i++)
    {
        if(nume[i]%3==0)
        {
            printf("\n%i e multiplo de 3", nume[i]);
        }
    }
    printf("\n");
    for(i=0;i<tam;i++)
    {
        if(nume[i]%2==0)
        {
            printf("\nA posicao %i possui um multiplo e 2", i);
        }
    }
    printf("\n");
}
