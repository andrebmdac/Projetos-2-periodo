#include <stdio.h>
#include <stdlib.h>
#define tam1 10
#define tam2 5
void calcvetor1(int vet1[],int vet2[]);
void calcvetor2(int vet1[],int vet2[]);

int main()
{
    int vet1[tam1],vet2[tam2],i;
    printf("     Lista 1:\n\n");
    for(i=0;i<tam1;i++)
    {
        printf("Digite um numero: ");
        scanf("%i", &vet1[i]);
    }
    printf("\n    Lista 2:\n\n");
    for(i=0;i<tam2;i++)
    {
        printf("Digite um numero: ");
        scanf("%i", &vet2[i]);
    }
    printf("\n                   Listas antigas:\n\n");
    printf("        Lista 1                      Lista 2");
    printf("\n\n");
    printf("  ");
    for(i=0;i<tam1;i++)
    {
        printf("%i ", vet1[i]);
    }
    printf("              ");
    for(i=0;i<tam2;i++)
    {
        printf("%i ", vet2[i]);
    }
    printf("\n\n");
    calcvetor1(vet1,vet2);

    return 0;
}
 void calcvetor1(int vet1[],int vet2[])
 {
     int i,j,contpar=0,somavet2=0;
     for(i=0;i<tam1;i++)
     {
         if(vet1[i]%2==0)
         {
             contpar++;
         }
     }
     for(i=0;i<tam2;i++)
     {
         somavet2+=vet2[i];
     }
     int vetres[contpar];
     for(i=0,j=0;i<tam1;i++)
     {
         if(vet1[i]%2==0)
         {
            vetres[j]=vet1[i]+somavet2;
            j++;
         }
     }
     printf("Primeiro vetor resultante: ");
     for(j=0;j<contpar;j++)
     {
         printf(" %i ", vetres[j]);
     }
     printf("\n");
     calcvetor2(vet1,vet2);
 }

void calcvetor2(int vet1[],int vet2[])
 {
     int i,j,conti=0;
     for(i=0;i<tam1;i++)
     {
         if(vet1[i]%2!=0)
         {
             conti++;
         }
     }
     int vetres[conti],div=0;
     for(i=0,j=0;i<tam1;i++)
     {
         if(vet1[i]%2!=0)
         {
            vetres[j]=vet1[i];
            j++;
         }
     }
     for(i=0;i<conti;i++)
     {
         for(j=0;j<tam2;j++)
         {
             if(vetres[i]%vet2[j]==0)
             {
                 div++;
             }
         }
         vetres[i]=div;
         div=0;

     }
     printf("Segundo vetor resultante: ");
     for(j=0;j<conti;j++)
     {
         printf(" %i ", vetres[j]);
     }
     printf("\n\n");
 }
