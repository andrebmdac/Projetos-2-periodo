#include <stdio.h>
#include <stdlib.h>
#define tam 10

int main()
{
    int i;
    float comi[tam],vend[tam],comissao[tam],totvendas=0;
    char nome[tam];

    for(i=0;i<tam;i++)
    {
        printf("Digite o nome do vendedor: ");
        scanf(" %c", &nome[i]);
        printf("Digite o total de vendas do vendedor: ");
        scanf("%f", &vend[i]);
        totvendas+=vend[i];
        printf("Digite o percentual da comissao do vendedor: ");
        scanf("%f", &comi[i]);
        printf("\n");
    }
    for(i=0;i<tam;i++)
    {
        comissao[i]=(comi[i]/100)*vend[i];
        printf("O vendedor || %c || recebe R$ %.2f de comissao\n", nome[i],comissao[i]);
        comissao[i];
    }
    printf("\nO total de vendas foi: R$ %.2f\n", totvendas);

    calcmm(comissao,nome);

    return 0;
}

void calcmm(float comissao[],char nome[])
{
    int i,j,aux1,aux2;
    for(i=0;i<(tam-1);i++)
    {
        for(j=i+1;j<tam;j++)
        {
            if(comissao[i]>comissao[j])
            {
                aux1=comissao[i];
                aux2=nome[i];
                comissao[i]=comissao[j];
                nome[i]=nome[j];
                comissao[j]=aux1;
                nome[j]=aux2;
            }
        }
    }
    printf("\n");
    printf("O vendedor || %c || recebeu o menor valor: R$ %.2f", nome[0],comissao[0]);
    printf("\n");
    printf("O vendedor || %c || recebeu o maior valor: R$ %.2f\n", nome[i],comissao[i]);
}
