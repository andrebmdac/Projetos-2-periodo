#include <stdio.h>
#include <stdlib.h>
#define tam 5
int calcvet(int nume[],int nume2[]);

int main()
{
    int nume[tam],nume2[tam],i;
    printf("              Lista 1:\n\n");
    for(i=0;i<tam;i++)
    {
        printf("Digite um numero: ");
        scanf("%i", &nume[i]);
    }
    printf("\n              Lista 2:\n\n");
    for(i=0;i<tam;i++)
    {
        printf("Digite um numero: ");
        scanf("%i", &nume2[i]);
    }
    printf("\n              Listas antigas:\n\n");
    printf("   Lista 1                      Lista 2");
    printf("\n\n");
    printf("  ");
    for(i=0;i<tam;i++)
    {
        printf("%i ", nume[i]);
    }
    printf("                   ");
    for(i=0;i<tam;i++)
    {
        printf("%i ", nume2[i]);
    }
    printf("\n\n");
    calcvet(nume,nume2);
    return 0;
}

int calcvet(int nume[],int nume2[])
{
    int nume3[tam*2],i,j;
    for(i=0,j=0; i<(tam); i++,j+=2)
    {
        nume3[j]=nume[i];
        nume3[j+1]=nume2[i];
    }
    printf("\n              Lista nova:\n\n");
    printf("    ");
    for(i=0; i<(tam*2); i++)
    {
        printf(" %i ", nume3[i]);

    }
    printf("\n\n");
}

