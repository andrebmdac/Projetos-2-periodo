#include <stdio.h>
#include <stdlib.h>
#define tam 10

int main()
{
    int idade[tam],i;
    float peso[tam];

    for(i=0;i<tam;i++)
    {
        do{
        printf("Digite sua idade: ");
        scanf("%i", &idade[i]);
            if(idade[i]<=0)
            {
                printf("Numero invalido,digite outro numero!\n\n");
            }
        }while(idade[i]<=0);

        do{
        printf("Digite seu peso: ");
        scanf("%f", &peso[i]);
        printf("\n");
            if(peso[i]<=0)
                {
                    printf("Numero invalido,digite outro numero!\n\n");
                }
        }while(peso[i]<=0);
    }
    calcvet(idade,peso);
    return 0;
}

void calcvet(int idade[],float peso[])
{
    int i,conti50=0,contp70=0,conti23=0;
    float mediaconti23=0,contp23=0;
    for(i=0;i<tam;i++)
    {
        if(idade[i]>50)
        {
            conti50++;
        }
        if(peso[i]>70)
        {
            contp70++;
        }
        if(idade[i]>20 && idade[i]<30)
        {
            conti23++;
            contp23+=peso[i];
        }
    }
    printf("\nA quantidade de pessoas com idade superior a 50 e: %i", conti50);
    printf("\nA quantidade de pessoas com peso superior a 70 e: %i", contp70);
    if(conti23==0)
    {
        printf("\nNao existem pessoas com idade entre 20 e 30 anos!\n");
    }
    else
    {
         mediaconti23=contp23/(conti23*1.0);
         printf("\nA media dos pesos das pessoas com idade entre 20 e 30 anos e: %.2f\n", mediaconti23);
    }

}
