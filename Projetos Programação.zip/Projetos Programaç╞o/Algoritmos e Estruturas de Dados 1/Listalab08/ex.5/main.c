#include <stdio.h>
#include <stdlib.h>
#define tam 10
int prevetor();
int ordvetor(int num[]);
int printvetor(int num[]);


int main()
{
    prevetor();

return 0;
}

int prevetor()
{
    int num[tam],i;
    for(i=0;i<tam;i++)
    {
        printf("Digite um numero: ");
        scanf("%i", &num[i]);
    }
    printf("\nVetor original:");

        for(i=0;i<(tam-1);i++)
        {
            printf(" %i |", num[i]);
        }
        printf(" %i\n", num[i]);
    ordvetor(num);
}

int ordvetor(int num[])
{
    int a,b,aux;
    for(a=0;a<(tam-1);a++)
    {
       for(b=a+1; b<tam; b++)
       {
           if(num[a]>num[b])
           {
               aux=num[a];
               num[a]=num[b];
               num[b]=aux;
           }
       }
    }
    printvetor(num);
}

int printvetor(int num[])
{
    int i;
    printf("Vetor ordenado:");
    for(i=0;i<(tam-1);i++)
    {
        printf(" %i |", num[i]);
    }
    printf(" %i\n", num[i]);
}
