#include <stdio.h>
#include <stdlib.h>

int main()
{
    int vet[7] = {3, 1, 5, 2, 6, 0, 8}, A, B, aux, i;

    printf("\nVetor original: ");
    for(i = 0; i<7; i++)
    {
     printf("%d | ", vet[i]);
    }

    for(A=0; A<6; A++)
    {
        for(B=A+1; B<7; B++)
        {
            if(vet[A] > vet[B])
            {
                aux = vet[A];
                vet[A] = vet[B];
                vet[B] = aux;
            }
        }
    }

    printf("\nVetor ordenado: ");
    for(i = 0; i<7; i++)
    {
     printf("%d | ", vet[i]);
    }
    return 0;
}
