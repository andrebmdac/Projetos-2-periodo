#include <stdio.h>
#include <stdlib.h>
#define linhas 4
#define colunas 4

int main()
{
    int matriz[linhas][colunas],i,j,valor;
    for(i=0;i<linhas;i++)
    {
        for(j=0;j<colunas;j++)
        {
            printf("Digite um numero %i|%i: ", i,j);
            scanf("%i", &matriz[i][j]);
        }
    }
    printf("\nMatriz original: \n");
    for(i=0;i<linhas;i++)
    {
        printf("\n");
        for(j=0;j<colunas;j++)
        {
            printf(" %i |", matriz[i][j]);
        }
    }
    printf("\n\nDigite um valor para multiplicar os valores da matriz: ");
    scanf("%i", &valor);
    for(i=0;i<linhas;i++)
    {
        for(j=0;j<colunas;j++)
        {
            matriz[i][j]=matriz[i][j]*valor;
        }
    }
    printf("\nMatriz nova: \n");
    for(i=0;i<linhas;i++)
    {
        printf("\n");
        for(j=0;j<colunas;j++)
        {
            printf(" %i |", matriz[i][j]);
        }
    }
    printf("\n");
    return 0;
}
