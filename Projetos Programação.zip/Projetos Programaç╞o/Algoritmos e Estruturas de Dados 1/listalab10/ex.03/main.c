#include <stdio.h>
#include <stdlib.h>
#define linhas 8
#define colunas 6


int main()
{
    int matriz[linhas][colunas],i,j;
    float media,soma;
    for(i=0;i<linhas;i++)
    {
        for(j=0;j<colunas;j++)
        {
            printf("Digite um numero %i|%i: ", i,j);
            scanf("%i", &matriz[i][j]);
        }
    }

    printf("\nMatriz original: \n");
    for(i=0;i<linhas;i++)
    {
        printf("\n");
        for(j=0;j<colunas;j++)
        {
            printf(" %i |", matriz[i][j]);
        }
    }
    printf("\n");
    int cont=0;
    for(i=0;i<linhas;i++)
    {
        for(j=0;j<colunas;j++)
        {
            if(i%2==0)
            {
                soma+=(matriz[i][j]*1.0);
            }
        }
        if(i%2==0)
        {
        media=soma/(colunas*1.0);
        printf("\nA media da linha %i e: %.2f", i,media);
        soma=0;
        media=0;
        }
    }

    printf("\n\n");
    return 0;
}






