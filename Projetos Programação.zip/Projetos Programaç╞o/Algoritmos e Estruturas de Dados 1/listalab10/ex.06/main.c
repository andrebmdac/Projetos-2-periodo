#include <stdio.h>
#include <stdlib.h>
#define tam 10

int main()
{
    int vet1[tam],vet2[tam],vet3[tam],i,j;
    for(i=0;i<tam;i++)
    {
        printf("Digite um numero para Vetor 1 - %i: ", i);
        scanf("%i", &vet1[i]);
    }
    printf("\n");
    for(i=0;i<tam;i++)
    {
        printf("Digite um numero para Vetor 2 - %i: ", i);
        scanf("%i", &vet2[i]);
    }
    printf("\n");
    for(i=0;i<tam;i++)
    {
        printf("Digite um numero para Vetor 3 - %i: ", i);
        scanf("%i", &vet3[i]);
    }
    int aux;
    for(i=0;i<(tam-1);i++)
    {
       for(j=i+1; j<tam; j++)
       {
           if(vet1[i]>vet1[j])
           {
               aux=vet1[i];
               vet1[i]=vet1[j];
               vet1[j]=aux;
           }
       }
    }
    for(i=0;i<(tam-1);i++)
    {
       for(j=i+1; j<tam; j++)
       {
           if(vet2[i]<vet2[j])
           {
               aux=vet2[i];
               vet2[i]=vet2[j];
               vet2[j]=aux;
           }
       }
    }
    for(i=0;i<(tam-1);i++)
    {
       for(j=i+1; j<tam; j++)
       {
           if(vet3[i]>vet3[j])
           {
               aux=vet3[i];
               vet3[i]=vet3[j];
               vet3[j]=aux;
           }
       }
    }
    int linhas=tam,colunas=3;
    int matriz[linhas][colunas];
    for(i=0;i<linhas;i++)
    {
        for(j=0;j<colunas;j++)
        {
            if(j==0)
            {
                matriz[i][j]=vet1[i];
            }
            if(j==1)
            {
                matriz[i][j]=vet2[i];
            }
            if(j==2)
            {
                matriz[i][j]=vet3[i];
            }

        }
    }
    printf("\nMatriz :\n");
    for(i=0;i<linhas;i++)
    {
        printf("\n");
        for(j=0;j<colunas;j++)
        {
            printf("|%i| ", matriz[i][j]);
        }
    }
    printf("\n\n");
    return 0;
}
