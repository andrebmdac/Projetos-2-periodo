#include <stdio.h>
#include <stdlib.h>
#define dias 7

int main()
{
    int semanas,prodm=0,i,j=0;
    float soma=0,media=0;
    printf("Digite a quantidade de semanas do relatorio: ");
    scanf("%i", &semanas);
    int matriz[semanas][dias];
    printf("\nDigite a producao para cada dia da semana: \n");
    for(i=0;i<semanas;i++)
    {
        printf("\n");
        for(j=0;j<dias;j++)
        {
            printf("Semana %i | Dia %i: ", i+1,j+1);
            scanf("%i", &matriz[i][j]);
            soma+=matriz[i][j];
        }
    }
    media=(soma*1.0)/((semanas*dias)*1.0);
    for(i=0;i<semanas;i++)
    {
        for(j=0;j<dias;j++)
        {
            if(matriz[i][j]>media)
            {
                prodm++;
            }
        }
    }
    //LAYOUT CORRETO

    printf("\n\n    RELATORIO DE PRODUCAO RELATIVO A %i SEMANAS", semanas);
    printf("\n__________________________________________________ \n");
    printf("\nProducao media: %.2f", media);
    printf("\nNumero de dias com producao acima da media: %i", prodm);
    printf("\n\n    INDICACAO DOS DIAS DE MINIMA PRODUCAO:\n");
    float min=0;
    int dia=0;
    for(i=0;i<semanas;i++)
    {
        min=matriz[i][j];
        for(j=0;j<dias;j++)
        {
            if(min>matriz[i][j])
            {
                min=matriz[i][j];
                dia=j;
            }
        }
         printf("\nSemana %d -------- Dia %d", i+1, dia+1);
    }
printf("\n\n");
    return 0;
}
