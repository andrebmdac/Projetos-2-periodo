#include <stdio.h>
#include <stdlib.h>
void pesohomem(float altura);
void pesomulher(float altura);

int main()
{
    float altura;
    char sexo;

    while(sexo!='m' && sexo!='f')
    {
    printf("Digite seu sexo:");
    scanf("%c", &sexo);
    }

    if(sexo=='m')
    {
        printf("Digite sua altura(em M):");
        scanf("%f", &altura);
        pesohomem(altura);
    }
    else if(sexo=='f')
    {
        printf("Digite sua altura(em M):");
        scanf("%f", &altura);
        pesomulher(altura);
    }

    return 0;
}
void pesohomem(float altura)
{
     float pesoideal;
     pesoideal=((72.7*altura)-58);
     printf("Seu peso ideal e: %.2f \n", pesoideal);
}

void pesomulher(float altura)
{
     float pesoideal;
     pesoideal=((62.1*altura)-44.7);
     printf("Seu peso ideal e: %.2f \n", pesoideal);
}

