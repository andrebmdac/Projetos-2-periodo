#include <stdio.h>
#include <stdlib.h>
void calchora(int horas);

int main()
{
    int horas;

    do
    {
    printf("Digite um quantidade inteira de horas:");
    scanf("%i", &horas);
    calchora(horas);
    }while(horas<=0);

    return 0;
}
 void calchora(int horas)
 {
     int minutos=0,segundos=0,milissegundos=0;
     minutos=horas*60;
     segundos=horas*3600;
     milissegundos=segundos*1000;
     printf("\nEm ");
     printf(" %i horas tem: ", horas);
     printf(" %i minutos,", minutos);
     printf(" %i segundos,", segundos);
     printf(" %i milisegundos .", milissegundos);

 }
