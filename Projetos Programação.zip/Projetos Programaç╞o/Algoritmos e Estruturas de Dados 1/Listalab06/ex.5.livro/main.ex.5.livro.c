#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void vernum(int);

int main()
{
    int numero;
    printf("Digite um numero:");
    scanf("%d", &numero);
    vernum(numero);

    return 0;
}
void vernum(int numero)
{
    char valor[10];
    if(numero > 0)
    {
       strcpy(valor, "positivo");
    }
    else if(numero < 0)
    {
       strcpy(valor, "negativo");
    }
    else
    {
        strcpy(valor, "nulo");
    }
    printf("O numero ");
    printf("%d e: ", numero);
    printf("%s", valor);


return valor;
}
