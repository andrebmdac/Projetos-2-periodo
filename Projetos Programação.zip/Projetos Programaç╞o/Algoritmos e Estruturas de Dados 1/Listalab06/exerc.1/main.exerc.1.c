#include <stdio.h>
#include <stdlib.h>
char calcon(float nota);

int main()
{
    float nota;
    char conceito,nome[30];

    printf("Digite seu nome:");
    scanf("%s", &nome);
    printf("Digite sua nota:");
    scanf("%f", &nota);
    conceito = calcon(nota);
    printf("\nO aluno %s obteve a nota %.2f e conceito %c", nome,nota,conceito);

    return 0;
}

char calcon(float nota)
{
    char conceito='z';

    if(nota>=90)
    {
        conceito='A';
    }
    else if(nota>=80 && nota<90)
    {
        conceito='B';
    }
    else if(nota>=70 && nota<80)
    {
        conceito='C';
    }
    else if(nota>=60 && nota<70)
    {
        conceito='D';
    }
    else if(nota>=0 && nota<60)
    {
        conceito='E';
    }
    return conceito;
}
