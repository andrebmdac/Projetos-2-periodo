#include <stdio.h>
#include <stdlib.h>
void calcdiv();

int main()
{
    calcdiv();
    return 0;
}

void calcdiv()
{
    int numero,i,divis=0;

     printf("Digite um valor inteiro positivo:");
     scanf("%i", &numero);
     for(i=1; i<=numero; i++)
     {
       if(numero%i==0)
       {
           divis+=i;
           printf("O numero %i e divisor de %i \n", divis,numero);
           divis=0;
       }
     }
}




