#include <stdio.h>
#include <stdlib.h>
void calcprimo(int);

int main()
{
      int i;
      printf("Os primos sao:");
      for(i=1; i<=1000; i++)
      {
          calcprimo(i);
      }


    return 0;
}
void calcprimo(int i)
{
    int j, divi=0;
    float resto=0;
    for(j=1; j<=i; j++)
    {
        resto=i%j;
        if(resto==0)
        {
            divi++;
        }
    }
    if(divi==2)
    {
        printf("\n%i", i);
    }
}
