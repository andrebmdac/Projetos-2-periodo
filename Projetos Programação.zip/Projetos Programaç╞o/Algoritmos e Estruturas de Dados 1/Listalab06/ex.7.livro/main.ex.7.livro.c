#include <stdio.h>
#include <stdlib.h>
void calmedia();

int main()
{
    calmedia();

    return 0;
}

void calmedia()
{
   float numero=0,contador=0,soma=0,media;
    printf("Digite 0 para sair:\n \n");
    do
    {

    printf("Digite um numero positivo:");
    scanf("%f",&numero);
    soma+=numero;
    contador++;

    }while(numero!=0);

    media=(soma/(contador-1));
    printf("A media e : %.2f", media);
}
