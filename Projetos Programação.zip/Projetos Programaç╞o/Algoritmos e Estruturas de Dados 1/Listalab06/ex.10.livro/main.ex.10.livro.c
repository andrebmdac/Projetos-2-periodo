#include <stdio.h>
#include <stdlib.h>

int main()
{
    int tamanho,i;
    float soma;

     printf("Diga o tamanho da lista:");
     scanf("%i", &tamanho);
     for(i=1; i<=tamanho ; i++)
     {
         soma+=(1/(i*1.0));
     }

    printf("A soma dos %i parametros e %.2f", tamanho,soma);


    return 0;
}
