#include <iostream>
#include <stdio.h>
#include <conio.h>
using namespace std;

class TIPO{
public:
    int codigoTipo;
    float percentualTipo;
};

class PRODUTO: public TIPO{
private:
    char descricao[200];
    float preco;
    float imposto;
public:
    void calcularPrecoFinal()
    {
       float precoFinal=0;
       cout<<"Digite o tipo do produto(1 - Alimentacao | 2 - Limpeza): ";
       cin>>codigoTipo;
       cout<<"Digite o preco do produto: ";
       cin>>preco;
       fflush(stdin);
       cout<<"Digite a descricao do produto: ";
       gets(descricao);
       if(codigoTipo==1)
       {
           percentualTipo=10;
       }
       else if(codigoTipo==2)
       {
           percentualTipo=20;
       }
       imposto=((percentualTipo/100.00)*preco);
       precoFinal=preco+imposto;
       cout<<"\nO preco final e: "<<precoFinal;
       cout<<"\n";
    }
};



int main()
{
    PRODUTO objeto1;
    objeto1.calcularPrecoFinal();

    return 0;
}
