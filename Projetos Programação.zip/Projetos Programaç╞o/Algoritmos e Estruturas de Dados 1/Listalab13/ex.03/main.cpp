#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
using namespace std;
int qtdAlunos=0;

class ALUNO{
public:
    char nome[50],endereco[200];
    int idade;
    int numMatricula;
public:
    void cadastrarAluno()
    {
        cout<<"***Cadastro ALUNO***\n";
        fflush(stdin);
        cout<<"\nDigite o nome do aluno: ";
        gets(nome);
        fflush(stdin);
        cout<<"Digite o endereco: ";
        gets(endereco);
        cout<<"Idade: ";
        cin>>idade;
        qtdAlunos++;
        numMatricula=qtdAlunos;
        cout<<"Matricula: "<<numMatricula;
        cout<<"\n\n";
    }
    void mostraAlunos(ALUNO objeto1[])
    {
        float matricula=0;
        cout<<"Digite a matricula do aluno: ";
        cin>>matricula;
        for(int i=0;i<qtdAlunos;i++)
        {
            if(objeto1[i].numMatricula==matricula)
            {
                cout<<"\nNome: "<<objeto1[i].nome;
                cout<<"\nMatricula: "<<objeto1[i].numMatricula;
                cout<<"\nIdade: "<<objeto1[i].idade;
                cout<<"\nEndereco: "<<objeto1[i].endereco;
                cout<<"\n\n";
            }
        }
    }

};



int main()
{
    ALUNO objeto1[40],cadastra,mostra;
    int opcao=0;
    do{
        cout<<"*****MENU*****\n1 - Cadastrar aluno\n2 - Mostrar info aluno\n\n*Digite a opcao desejada: ";
        cin>>opcao;
        cout<<"\n";
        switch(opcao)
        {
            case 1:
             objeto1[qtdAlunos].cadastrarAluno();
                break;
            case 2:
              mostra.mostraAlunos(objeto1);
                break;
        }
    }while(opcao<3);

    return 0;
}
