#include <iostream>
#include <stdio.h>
#include <conio.h>
using namespace std;
int qtdContas=0;
int qtdClientes=0;

class Cliente{
public:
    char nome[250];
    char rg[250];
    int cpf;
    char endereco[250];
    float renda;
    int idade;
public:
    void cadastrarCliente()
    {
        fflush(stdin);
        cout<<"Digite o nome: ";
        gets(nome);
        fflush(stdin);
        cout<<"Digite o RG: ";
        gets(rg);
        cout<<"Digite o CPF: ";
        cin>>cpf;
        fflush(stdin);
        cout<<"Digite o endereco: ";
        gets(endereco);
        fflush(stdin);
        cout<<"Digite o valor da renda: ";
        cin>>renda;
        cout<<"Digite a idade: ";
        cin>>idade;
        qtdClientes++;
    }
    void mostrarCliente(Cliente objeto1[]){
        int cpfConta=0,cont=0;
        cout<<"Digite o CPF que deseja ver a conta: ";
        cin>>cpfConta;
        int j=0;
        for(int i=0;i<qtdClientes;i++)
        {
            if(objeto1[i].cpf==cpfConta)
            {
                cout<<"\n***CLIENTE***\n";
                cout<<"\nNome: "<<objeto1[i].nome;
                cout<<"\nRG: "<<objeto1[i].rg;
                cout<<"\nCPF: "<<objeto1[i].cpf;
                cout<<"\nEndereco: "<<objeto1[i].endereco;
                cout<<"\nValor da renda: "<<objeto1[i].renda;
                cout<<"\nIdade: "<<objeto1[i].idade;
                cout<<"\n\n";
                cont++;
            }
        }
        if(cont==0)
        {
            cout<<"\nCPF nao cadastrado!\n";
        }
    }
};

class Conta{
public:
    int conta;
    int agencia;
    int cpf;
    float saldo;
public:
    void cadastrarConta(Cliente objeto1[])
    {
        int cpfConta=0,cont=0;
        cout<<"Digite o CPF que deseja cadastrar a conta: ";
        cin>>cpfConta;
        for(int i=0;i<qtdClientes;i++)
        {
            if(cpfConta==objeto1[i].cpf)
            {
                cout<<"Digite o numero da conta: ";
                cin>>conta;
                cout<<"Digite a agencia: ";
                cin>>agencia;
                cpf=cpfConta;
                cout<<"Digite o saldo da conta: ";
                cin>>saldo;
                cont++;
            }
        }
        if(cont==0)
        {
            cout<<"\nCliente nao encontrado\n";
        }
        qtdContas++;
    }
    void saqueConta(Cliente objeto1[],Conta objeto2[])
    {
        int numConta=0;
        float valor=0;
        cout<<"Digite o numero da conta: ";
        cin>>numConta;
        for(int i=0;i<qtdContas;i++)
        {
            if(numConta==objeto2[i].conta)
            {
                cout<<"Digite o valor do saque: ";
                cin>>valor;
                if(valor>objeto2[i].saldo)
                {
                    cout<<"Saldo nao disponivel em conta!";
                }
                else
                {
                    objeto2[i].saldo=objeto2[i].saldo-valor;
                    cout<<"Saque efetuado com sucesso!\n";
                    cout<<"Saldo atualizado: "<<objeto2[i].saldo;
                    cout<<"\n";
                }
            }
        }
    }
    void depositoConta(Cliente objeto1[],Conta objeto2[])
    {
        int numConta=0;
        float valor=0;
        cout<<"Digite o numero da conta: ";
        cin>>numConta;
        for(int i=0;i<qtdContas;i++)
        {
            if(numConta==objeto2[i].conta)
            {
                cout<<"Digite o valor do deposito: ";
                cin>>valor;
                objeto2[i].saldo=objeto2[i].saldo+valor;
                cout<<"Deposito efetuado com sucesso!\n";
                cout<<"Saldo antigo: "<<objeto2[i].saldo-valor;
                cout<<"\n";
                cout<<"Saldo atualizado: "<<objeto2[i].saldo;
                cout<<"\n";
            }
        }
    }
    void transferenciaConta(Cliente objeto1[],Conta objeto2[])
    {
        int contaOrigem=0,contaDestino=0;
        float valor=0;
        cout<<"Digite o numero da conta a sacar o valor: ";
        cin>>contaOrigem;
        for(int i=0;i<qtdContas;i++)
        {
            if(contaOrigem==objeto2[i].conta)
            {
                cout<<"\nSALDO: "<<objeto2[i].saldo;
                cout<<"\n";
                cout<<"Digite o valor do saque: ";
                cin>>valor;
                if(valor>objeto2[i].saldo)
                {
                    cout<<"Saldo nao disponivel em conta!";
                }
                else
                {
                    cout<<"Digite a conta de destino: ";
                    cin>>contaDestino;
                    for(int j=0;j<qtdContas; j++)
                    {
                        if(objeto2[j].conta==contaDestino)
                        {
                            objeto2[i].saldo=objeto2[i].saldo-valor;
                            objeto2[j].saldo=objeto2[j].saldo+valor;
                            cout<<"Transferencia efetuada com sucesso!\n";
                        }
                    }
                }
            }
        }
      }
    void mostrarConta(Cliente objeto1[],Conta objeto2[])
    {
        int numConta=0;
        cout<<"Digite o numero da conta: ";
        cin>>numConta;
        for(int i=0;i<qtdContas;i++)
        {
            if(objeto2[i].conta==numConta)
            {
                cout<<"\nCONTA";
                cout<<"\nNumero da conta: "<<objeto2[i].conta<<"\n";
                cout<<"Agencia: "<<objeto2[i].agencia<<"\n";
                cout<<"CPF titular: "<<objeto2[i].cpf<<"\n";
                cout<<"Saldo: "<<objeto2[i].saldo<<"\n\n";
            }
        }
    }
};


int main()
{
    Cliente objeto1[50], mostraCli;
    Conta objeto2[50], mostraCon,dep,saq,transf;
    int opcao=0;
    do{
        printf("**********MENU********** \n1 - Cadastrar Cliente\n2 - Cadastrar conta\n3 - Sacar dinheiro\n4 - Depositar dinheiro\n5 - Transferencia entre contas\n6 - Mostrar info cliente\n7 - Mostrar info conta\n\n*Digite o que fazer: ");
        scanf("%i", &opcao);
        switch(opcao)
        {
            case 1:
                 printf("\n");
                 objeto1[qtdClientes].cadastrarCliente();
                 printf("\n");
                break;
            case 2:
                 printf("\n");
                 objeto2[qtdContas].cadastrarConta(objeto1);
                 printf("\n");
                break;
            case 3:
                 printf("\n");
                 saq.saqueConta(objeto1,objeto2);
                 printf("\n");
                break;
            case 4:
                 printf("\n");
                 dep.depositoConta(objeto1,objeto2);
                 printf("\n");
                break;
            case 5:
                 printf("\n");
                 transf.transferenciaConta(objeto1,objeto2);
                 printf("\n");
                break;
            case 6:
                 printf("\n");
                 mostraCli.mostrarCliente(objeto1);
                 printf("\n");
                break;
            case 7:
                printf("\n");
                mostraCon.mostrarConta(objeto1,objeto2);
                printf("\n");
                break;
        }
    }while(opcao<8);
    return 0;
}
