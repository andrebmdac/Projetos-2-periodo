//
//  main.cpp
//  Exercicio_1_lab13_aed
//
//  Created by Julia Gontijo Lopes on 17/06/20.
//  Copyright © 2020 Julia Gontijo Lopes. All rights reserved.
//

#include <iostream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
using namespace std;

class TIPO{
protected:
    int cod_tipo;
    float percentual;
};

class PRODUTO: public TIPO{
private:
    char descricao[250];
    float preco, precofinal;
    float imposto;
public:
    void calcularPrecoFinal(){
        cout<<"Digite o tipo do produto (1 - Alimentacao ou 2 - Limpeza): ";
        cin>>cod_tipo;
        cout<< "Digite o preco do produto: ";
        cin>>preco;
        cout<<"Digite uma breve descricao do produto: ";
        fflush(stdin);
        gets(descricao);
        if(cod_tipo==1)
        {
            percentual=10;
        }
        else{
            percentual=20;
        }
        imposto=(percentual/100)*preco;
        precofinal=preco+imposto;
        cout<<"Preco final: "<<precofinal;
    }
    
};



int main(int argc, const char * argv[]) {
    
    PRODUTO obj1;
    obj1.calcularPrecoFinal();
    return 0;
}
