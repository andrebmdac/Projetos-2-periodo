//
//  main.cpp
//  Exercicio_3_lab13_aed
//
//  Created by Julia Gontijo Lopes on 21/06/20.
//  Copyright © 2020 Julia Gontijo Lopes. All rights reserved.
//

#include <iostream>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

using namespace std;
int quantAlunos=0;

class ALUNO{
public:
    char nome[100], endereco[200];
    double matricula=0;
    int idade=0, falta=0;
    float notaBio=0.0, notaGeo=0.0, notaMat=0.0, notaPort=0.0, notaFilo=0.0;
public:
    void cadastraAluno()
    {
        cout<<"****CADASTRO DE ALUNO****";
        cout<<"\nDigite o nome do aluno: ";
        fflush(stdin);
        gets(nome);
        cout<<"Endereco: ";
        fflush(stdin);
        gets(endereco);
        cout<<"Idade: ";
        cin>>idade;
        quantAlunos++;
        matricula=quantAlunos;
        cout<<"Matricula gerada: "<<matricula;
    }
    void alteranota(ALUNO objaluno[])
    {
        int curso=0,i=0;
        double nmatricula=0;
        cout<<"****ALTERAMENTO DE NOTAS****";
        cout<<"\nDigite a matricula do aluno o qual deseja mudar a nota: ";
        cin>>nmatricula;
        for(i=0; i<quantAlunos; i++)
        {
            if(objaluno[i].matricula == nmatricula)
            {
                int quantidade=0;
                do{
                cout<<"Materia a qual deseja alterar a nota:\n";
                cout<<"(1 - Biologia; 2 - Geografia; 3 - Matematica; 4 - Portugues; 5 - Filosofia)\n";
                cin>>curso;
        
                switch(curso)
                {
                    case 1:
                        cout<<"Nota atual de Biologia: "<<objaluno[i].notaBio;
                        cout<<"\nDigite a nova nota: ";
                        cin>>objaluno[i].notaBio;
                        break;
                    case 2:
                        cout<<"Nota atual de Geografia: "<<objaluno[i].notaGeo;
                        cout<<"\nDigite a nova nota: ";
                        cin>>objaluno[i].notaGeo;
                        break;
                    case 3:
                        cout<<"Nota atual de Matematica: "<<objaluno[i].notaMat;
                        cout<<"\nDigite a nova nota: ";
                        cin>>objaluno[i].notaMat;
                        break;
                    case 4:
                        cout<<"Nota atual de Portugues: "<<objaluno[i].notaPort;
                        cout<<"\nDigite a nova nota: ";
                        cin>>objaluno[i].notaPort;
                        break;
                    case 5:
                        cout<<"Nota atual de Filosofia: "<<objaluno[i].notaFilo;
                        cout<<"\nDigite a nova nota: ";
                        cin>>objaluno[i].notaFilo;
                        break;
                    default:
                        cout<<"\nOpcao invalida";
                }
                    cout<<"Deseja alterar mais alguma nota? (1 - sim / 2 - nao)\n";
                    cin>>quantidade;
                }while(quantidade!=2);
                
            }
        }
        
    }
    void faltas(ALUNO objaluno[])
    {
        double nmatricula=0;
        int i=0, faltas=0;
        cout<<"****FALTAS****";
        cout<<"\nDigite a matricula do aluno: ";
        cin>>nmatricula;
        for(i=0; i<quantAlunos; i++)
        {
            if(objaluno[i].matricula ==  nmatricula)
            {
                cout<<"Numero de faltas a adcionar: ";
                cin>>faltas;
                objaluno[i].falta =  objaluno[i].falta + faltas;
                cout<<"Quantidade de faltas atualizada: "<<objaluno[i].falta;
            }
        }
    }
    void infos(ALUNO objaluno[])
    {
        double nmatricula=0;
        int i=0;
        cout<<"****INFORMACOES DE ALUNO****\n";
        cout<<"Digite a matricula do aluno que deseja as informacoes: ";
        cin>>nmatricula;
        for(i=0; i<quantAlunos; i++)
        {
            if(objaluno[i].matricula ==  nmatricula)
            {
                cout<<"\nNome: "<<objaluno[i].nome;
                cout<<"\nMatricula: "<<objaluno[i].matricula;
                cout<<"\nEndereco: "<<objaluno[i].endereco;
                cout<<"\nIdade: "<<objaluno[i].idade;
                cout<<"\nNotas--- \n";
                cout<<"Biologia: "<<objaluno[i].notaBio<<"\nGeografia: "<<objaluno[i].notaGeo<<"\nMatematica: "<<objaluno[i].notaMat<<"\nPortugues: "<<objaluno[i].notaPort<<"\nFilosofia: "<<objaluno[i].notaFilo;
                cout<<"\nNumero de faltas: "<<objaluno[i].falta<<"\n\n";
            }
        }
        
    }
    
};

int main(int argc, const char * argv[]) {
    ALUNO objaluno[100], notas, faltas, mostra;
    int opcao=0;
    do{
        cout<<"\n\n___MENU___"<<"\n1 - cadastrar novo aluno"<<"\n2 - alterar notas"<<"\n3 - reportar falta"<<"\n4 - mostrar na tela as informacoes sobre um aluno\n5 - sair do programa\n";
        cout<<"OPCAO: ";
        cin>>opcao;
        cout<<"\n";
        switch(opcao){
            case 1:
                objaluno[quantAlunos].cadastraAluno();
                break;
            case 2:
                notas.alteranota(objaluno);
                break;
            case 3:
                faltas.faltas(objaluno);
                break;
            case 4:
                mostra.infos(objaluno);
                break;
            case 5:
                cout<<"Saindo do programa";
                break;
            default:
                cout<<"Opcao invalida";
                
                
        }
    }while(opcao!=5);
    return 0;
}
