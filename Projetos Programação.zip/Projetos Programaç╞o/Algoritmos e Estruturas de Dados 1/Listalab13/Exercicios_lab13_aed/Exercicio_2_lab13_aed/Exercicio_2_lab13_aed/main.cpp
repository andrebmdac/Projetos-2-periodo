//
//  main.cpp
//  Exercicio_2_lab13_aed
//
//  Created by Julia Gontijo Lopes on 17/06/20.
//  Copyright © 2020 Julia Gontijo Lopes. All rights reserved.
//

#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

using namespace std;
int quantClientes=0, quantContas=0;

class Cliente{
public:
    char nome[100], rg[100], end[200];
    int idade;
    double renda, cpf;
public:
    //QUESTAO A)
    void cadastrarCliente(){
        cout<<"\n\n***CADASTRO DE CLIENTE***";
        cout<<"\nDigite seu nome: ";
        fflush(stdin);
        gets(nome);
        cout<<"Digite seu RG: ";
        fflush(stdin);
        gets(rg);
        cout<<"Informe seu endereco: ";
        fflush(stdin);
        gets(end);
        fflush(stdin);
        cout<<"Digite seu CPF: ";
        fflush(stdin);
        cin>>cpf;
        fflush(stdin);
        cout<<"Sua idade: ";
        fflush(stdin);
        cin>>idade;
        fflush(stdin);
        cout<<"Digite sua renda: ";
        fflush(stdin);
        cin>>renda;
        fflush(stdin);
        quantClientes++;
    }
    void printaCliente(Cliente objcliente[])
    {
        double cpftitular=0;
        cout<<"\n****INFORMACOES SOBRE CLIENTE****\n";
        cout<<"Digite o numero de CPF do cliente sobre quem deseja obter as informacoes: ";
        cin>>cpftitular;
        int j=0, quant=0;
        for(j=0; j<quantClientes; j++)
        {
            if(objcliente[j].cpf==cpftitular)
            {
                cout<<"\nCLIENTE";
                cout<<"\nNome: "<<objcliente[j].nome<<"\n";
                cout<<"RG: "<<objcliente[j].rg<<"\n";
                cout<<"Endereco: "<<objcliente[j].end<<"\n";
                cout<<"CPF: "<<objcliente[j].cpf<<"\n";
                cout<<"Idade: "<<objcliente[j].idade<<"\n";
                cout<<"Renda: "<<objcliente[j].renda<<"\n\n";
                quant++;
            }
        }
        if(quant==0)
        {
            cout<<"\nCPF nao cadastrado\n";
        }
    }
};

class Conta{
public:
    int num_conta, agencia;
    double saldo, saque, deposito, cpf;
public:
    void cadastrarConta(Cliente objcliente[]){
        double cpftitular;
        int quant=0;
        int i=0;
        cout<<"\n\n****CADASTRO DE CONTA****";
        cout<<"\nCPF do titular: ";
        cin>>cpftitular;
        for(i=0; i<quantClientes; i++)
        {
            if(cpftitular == objcliente[i].cpf)
            {
                cpf=cpftitular;
                cout<<"Digite o numero de sua conta: ";
                cin>>num_conta;
                cout<<"Digite o numero da agencia: ";
                cin>>agencia;
                cout<<"Informe seu saldo bancario: ";
                cin>>saldo;
                quantContas++;
                quant++;
            }
        }
        if(quant==0)
        {
            cout<<"\nCliente nao encontrado. Cadastre primeiro um cliente com esse CPF para depois cadastrar uma conta em seu nome\n";
        }
    }
    void saqueConta(Conta objconta[], Cliente objcliente[]){
        int numerodaconta, i=0;
        cout<<"\n\n****SAQUE****\n";
        cout<<"Digite o numero da conta a sacar o valor: ";
        cin>>numerodaconta;
        for(i=0; i<quantContas; i++)
        {
            if(numerodaconta== objconta[i].num_conta)
            {
                cout<<"Valor que voce deseja sacar da conta: ";
                cin>>saque;
                objconta[i].saldo=objconta[i].saldo-saque;
                cout<<"Saldo atualizado: "<<objconta[i].saldo<<"\n";
            }
        }
        
    }
    void depositoConta(Conta objconta[], Cliente objcliente[]){
        int numerodaconta=0, i=0;
        cout<<"\n\n****DEPOSITO****\n";
        cout<<"Digite o numero da conta na qual deseja realizar o deposito: ";
        cin>>numerodaconta;
        for(i=0; i<quantContas; i++)
        {
            if(numerodaconta==objconta[i].num_conta)
            {
                cout<<"\nValor que deseja depositar: ";
                cin>>deposito;
                objconta[i].saldo=objconta[i].saldo+deposito;
                cout<<"Saldo atualizado: "<<objconta[i].saldo<<"\n";
            }
        }
    }
    void transferencia(Conta objconta[], Cliente objcliente[]){
        cout<<"\n\n****TRANSFERENCIA DE CONTAS****";
        saqueConta(objconta, objcliente);
        depositoConta(objconta, objcliente);
        
    }
    void printaConta(Conta objconta[], Cliente objcliente[])
    {
        int numeroconta=0;
        cout<<"\n****INFORMACOES SOBRE CONTA****\n";
        cout<<"Digite o numero da conta sobre a qual deseja obter as informacoes: ";
        cin>>numeroconta;
        int x=0;
        for(x=0; x<quantContas; x++)
        {
            if(objconta[x].num_conta==numeroconta)
            {
                cout<<"\nCONTA";
                cout<<"\nNumero da conta: "<<objconta[x].num_conta<<"\n";
                    cout<<"Agencia: "<<objconta[x].agencia<<"\n";
                    cout<<"CPF titular: "<<objconta[x].cpf<<"\n";
                    cout<<"Saldo: "<<objconta[x].saldo<<"\n\n";
            }
        }
    }
        
};


int main(int argc, const char * argv[]) {
    
    
    
        Cliente objcliente[200], printacli;
        Conta objconta[200], deposito, saque, transf, printacont;
    int opcao=0, i=0;
    do{
        cout<<"\n------MENU------"<<"\n\n1 - cadastro de cliente"<<"\n2 - cadastro de conta"<<"\n3 - realizar um saque"<<"\n4 - realizar um deposito"<<"\n5 - realizar uma transferencia"<<"\n6 - printar informacoes sobre cliente na tela\n7 - printar informacoes sobre conta na tela\n8 - sair do programa\n"<<"OPCAO: ";
        cin>>opcao;
        switch(opcao)
        {
            case 1:
                objcliente[quantClientes].cadastrarCliente();
                break;
            case 2:
                objconta[quantContas].cadastrarConta(objcliente);
                break;
            case 3:
                saque.saqueConta(objconta, objcliente);
                break;
            case 4:
                deposito.depositoConta(objconta, objcliente);
                break;
            case 5:
                transf.transferencia(objconta, objcliente);
                break;
            case 6:
                printacli.printaCliente(objcliente);
                break;
            case 7:
                printacont.printaConta(objconta, objcliente);
                break;
            case 8:
                cout<<"\n\nEncerrando o programa";
                break;
            default:
                cout<<"\n\nOpcao invalida";
        }
        i++;
    }while(opcao!=8);
    
        
    
    
    
    
    
    
    return 0;
}
