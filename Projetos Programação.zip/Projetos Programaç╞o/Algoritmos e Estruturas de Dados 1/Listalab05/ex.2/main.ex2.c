#include <stdio.h>
#include <stdlib.h>

int main()
{
    float idade=1,desconto=0,valorfinal=0,faturamento=0;
    while(idade>0)
    {
      printf("Digite sua idade e lhe direi seu desconto. Para parar digite idade= -1:");
      scanf("%f", &idade);
      if(idade>0)
      {
          desconto=(idade/2.0);
          printf("\nSeu desconto e de: &.2f %%", desconto);
          valorfinal=1000.0-((desconto/100.0)*1000.0);
          printf("\nO valor a ser pago e de: %.2f", valorfinal);
          faturamento+=valorfinal;
      }
      else if(idade=0)
      {
          printf("\nEssa nao e uma idade valida!");
      }
      else
      {
       printf("Calculo finalizado");
      }

    }


   printf("\nO faturamento total da loja foi: %.2f", faturamento);


    return 0;
}
