#include <stdio.h>
#include <stdlib.h>
int divisao(int n1,int n2,int conta);

int main()
{
    int num1,num2,cont=0,result;
    do{
        printf("Digite o primeiro numero: ");
        scanf("%i", &num1);
    }while(num1==0);
    do{
        printf("Digite o segundo numero: ");
        scanf("%i", &num2);
    }while(num1==0);
    divisao(num1,num2,cont);
    printf("\nO resultado da divisao e: %i\n", divisao(num1,num2,cont));

    return 0;
}
int divisao(int n1,int n2,int conta)
{
    if(n1<0)
    {
        return (conta-1);
    }
    else
    {
        return divisao((n1-n2),n2,(conta+1));
    }



}
