#include <stdio.h>
#include <stdlib.h>

int main()
{
    int canal=1, pessoas=0, quant4=0, quant5=0, quant7=0, quant12=0, quanttotal=0;
    float percent;
    while(canal>0)
    {
        printf("Digite o numero do canal desejado (4,5,7,12). Para parar digite 0:");
        scanf("%d" , &canal);

        if(canal>0)
        {
            printf("\nDigite a quantidade de pessoas que assiste a esse canal:");
            scanf("%d", &pessoas);
            if(canal==4)
            {
            quant4+=pessoas;
             }
            if(canal==5)
            {
            quant5+=pessoas;
            }
            if(canal==7)
            {
            quant7+=pessoas;
            }
            if(canal==12)
            {
            quant12+=pessoas;
            }
            quanttotal+=pessoas;

        }

   }
   percent=0;
   percent=(quant4*100.0)/quanttotal;
   printf("\nA porcentagem de audiencia do canal 4 e: %.2f\n", percent);
   percent=0;
   percent=(quant5*100.0)/quanttotal;
   printf("\nA porcentagem de audiencia do canal 5 e: %.2f\n", percent);
   percent=0;
   percent=(quant7*100.0)/quanttotal;
   printf("\nA porcentagem de audiencia do canal 7 e: %.2f\n", percent);
   percent=0;
   percent=(quant12*100.0)/quanttotal;
   printf("\nA porcentagem de audiencia do canal 12 e: %.2f\n", percent);

    return 0;
}
