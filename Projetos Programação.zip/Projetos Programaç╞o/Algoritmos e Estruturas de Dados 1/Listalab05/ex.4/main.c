#include <stdio.h>
#include <stdlib.h>
int soma(int n1);

int main()
{
    int n1;
    printf("Digite o numero: ");
    scanf("%i", &n1);
    soma(n1);
    printf("\nA soma entre todos os numero entre 0 e %i e: %i\n", n1,soma(n1));

    return 0;
}
int soma(int n1)
{
    if(n1==0)
    {
        return 0;
    }
    else
    {
        return n1+soma(n1-1);
    }
}
