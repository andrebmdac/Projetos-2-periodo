#include <stdio.h>
#include <stdlib.h>

int main()
{
    int    olvecalocont=0;
    float  sexo=0,idade=0,altura=0,peso=0,somidade=0,mediaidade=0,somapeso=0,mediapeso=0,somaltura=0,mediaaltura=0,percentfem=0,percentmasc=0,continuar=0,continuac=2,nummasc,numfem,corolho=0,corcabelo=0,olvecalores=0,particip=0;
    do{
            printf("\nDigite seu sexo (1-masculino e 2-feminino) :");
            scanf("%f", &sexo);
            if(sexo==1)
            {
                nummasc++;
            }
            else
            {
                numfem++;
            }
            printf("\nDigite a cor dos seus olhos (1-Azul,2-Verde,3-Castanho) :");
            scanf("%f", &corolho);
            if(corolho==2)
            {
             olvecalocont++;
            }
            else
            {
             olvecalocont+=0;
            }
            printf("\nDigite a cor dos seus cabelos (1-Loiro,2-Castanho,3-Preto) :");
            scanf("%f", &corcabelo);
            if(corcabelo==1)
            {
                olvecalocont++;
            }
            else
            {
                olvecalocont+=0;
            }
            printf("\nDigite sua idade:");
            scanf("%f", &idade);
            somidade+=idade;
            printf("\nDigite sua altura (em CM):");
            scanf("%f", &altura);
            somaltura+=altura;
            printf("\nDigite seu peso:");
            scanf("%f", &peso);
            somapeso+=peso;
            particip++;
            printf("\nDeseja continuar (1-Sim , 2-Nao) :");
            scanf("%f", &continuar);
            if(continuar==1)
            {
                continuac+=0;
            }
            else
            {
                continuac++;
            }

    }while(continuac<=2);

    mediaidade=somidade/particip;
    printf("\nA media das idades e: %.2f", mediaidade);
    mediapeso=somapeso/particip;
    printf("\nA media dos pesos e: %.2f", mediapeso);
    mediaaltura=somaltura/particip;
    printf("\nA media das alturas e (em CM): %.2f", mediaaltura);
    percentmasc=((nummasc/(nummasc+numfem))*100);
    printf("\nA porcentagem de homens e: %.2f", percentmasc);
    percentfem=((numfem/(nummasc+numfem))*100);
    printf("\nA porcentagem de mulheres e: %.2f", percentfem);
    olvecalores=(olvecalocont/2);
    printf("\nO numero de pessoas com olho verde e cabelo loiro e: %i", olvecalores);

    return 0;
}
