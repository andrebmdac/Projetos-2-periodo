#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>


int main()
{
  char opcao='E';
  double salarioatual,salarionovo;
  while(toupper(opcao) !='D')
  {
      printf("Digite o salario atual:");
      scanf("%lf", &salarioatual);
      printf("Escolha uma opcao de calculo:");
      printf("\nA - Aumento de 8%%");
      printf("\nB - Aumento de 11%%");
      printf("\nC - Aumento fixo de R$ 450");
      printf("\nD - Para sair");
      printf("\nDigite sua opcao:");
      scanf(" %c", &opcao);
      switch(toupper(opcao))
      {
        case 'A':
          salarionovo=salarioatual+(salarioatual*0.08);
          printf("O seu salario novo e: %.2f", salarionovo);
        break;
        case 'B':
          salarionovo=salarioatual+(salarioatual*0.11);
          printf("O seu salario novo e: %.2f", salarionovo);
        break;
        case 'C':
          salarionovo=salarioatual+450;
          printf("O seu salario novo e: %.2f", salarionovo);
        break;
        case 'D':
          printf("Saindo do programa!");
        break;
        default:
            printf("\nOpcao invalida do menu");
      }
  }


    return 0;
}

