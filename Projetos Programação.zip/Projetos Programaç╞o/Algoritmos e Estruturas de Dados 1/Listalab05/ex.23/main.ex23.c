#include <stdio.h>
#include <stdlib.h>

int main()
{
    int opcao=0, meses=0;
    float salat=0, nvsal=0, ferias=0, dec3=0;
    do
    {
        printf("Menu de opcoes:\nDigite 1 para novo salario\nDigite 2 para ferias\nDigite 3 para decimo terceiro\nDigite 4 para sair do programa\nDigite a opcao desejada:");
        scanf("%d", &opcao);
        if(opcao==1)
        {
            printf("\nDigite o salario atual:");
            scanf("%f", &salat);
            if(salat<=210.0)
            {
                nvsal=salat*1.15;
                printf("Seu novo salario e: %.2f", nvsal);
            }
            else if(salat>210.0 && salat<=600.0)
            {
                nvsal=salat*1.10;
                printf("Seu novo salario e: %.2f", nvsal);
            }
            else
            {
                nvsal=salat*1.05;
                printf("Seu novo salario e: %.2f", nvsal);
            }
        }
        else if(opcao==2)
        {
            printf("Digite seu salario atual:");
            scanf("%f", &salat);
            ferias=salat+(salat/3.0);
            printf("Suas ferias serao: %.2f", ferias);
        }
        else if(opcao==3)
        {
            printf("Digite o seu salario atual:");
            scanf("%f", &salat);
            printf("Digite o numero de meses de trabalho na empresa:");
            scanf("%d", &meses);
                if(meses > 12)
                {
                    printf("Quantidade de meses invalida!");
                }
                else
                {
                    dec3=(salat*meses)/12.0;
                    printf("O valor do decimo terceiro e: %.2f", dec3);
                }
        }
        else if(opcao==4)
        {
            printf("Voce saiu do programa:");
        }
        else
        {
            printf("Opcao invalida!");
        }




    }while(opcao!=4);

return 0;
}
