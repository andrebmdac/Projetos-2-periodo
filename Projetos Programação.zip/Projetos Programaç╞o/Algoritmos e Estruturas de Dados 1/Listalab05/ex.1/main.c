#include <stdio.h>
#include <stdlib.h>
int multiplica(int n1,int n2);

int main()
{
    int num1,num2;
    printf("Digite o primeiro numero: ");
    scanf("%i", &num1);
    printf("Digite o segundo numero: ");
    scanf("%i", &num2);
    multiplica(num1,num2);
    printf("\nO produto entre eles e: %i\n", multiplica(num1,num2));

    return 0;
}
int multiplica(int n1,int n2)
{
    if(n2==0)
    {
        return 0;
    }
    else
    {
        return n1+(multiplica(n1,n2-1));
    }
}
