#include <stdio.h>
#include <stdlib.h>

int main()
{
  int x=0,y=0,z=0,quant=1,menor=0,maior=0;
  printf("Digite a quantidade de numeros que deseja digitar:");
  scanf("%d", &quant);
  printf("\nDigite um numero:");
  scanf("%d", &x);
  printf("Digite um numero:");
  scanf("%d", &y);
  quant-=2;
  while(quant>0)
  {
      printf("Digite um numero:");
      scanf("%d", &z);
      if(z>x && z>y)
      {
          if(x>y)
          {
              x=z;
          }
          else
          {
              y=z;
          }
      }
      if(z<y && z<x)
      {
          if(y<x)
          {
              y=z;
          }
          else
          {
              x=z;
          }
      }
      quant--;
  }
  if(x>y)
  {
      maior=x;
      menor=y;
  }
  else
  {
      maior=y;
      menor=x;
  }
  printf("O maior e o menor numero sao: %.2d e %.2d", maior,menor);



    return 0;
}
