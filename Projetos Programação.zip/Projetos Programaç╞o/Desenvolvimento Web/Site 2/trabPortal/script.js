var dados = {
    "noticias": 
    [
        {
           "titulo": "Primeira noticia bom",
           "imagem": "https://source.unsplash.com/random/140x140?sig=1",
           "fonte": "Carta Capital",
           "data": "02/06/2020",
           "resumo": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, explicabo voluptatibus molestias cupiditate debitis corporis?",
           "url": "http://www.cartacapital.com.br"
        },
        {
            "titulo": "Segunda noticia muito bom",
            "imagem": "https://source.unsplash.com/random/140x140?sig=2",
            "fonte": "Veja",
            "data": "03/06/2020",
            "resumo": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, explicabo voluptatibus molestias cupiditate debitis corporis?",
            "url": "http://www.veja.com.br"
        },
        {
            "titulo": "Terceira noticia bacana",
            "imagem": "https://source.unsplash.com/random/140x140?sig=3",
            "fonte": "Estado de S.P",
            "data": "04/06/2020",
            "resumo": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, explicabo voluptatibus molestias cupiditate debitis corporis?",
            "url": "http://www.estadao.com.br"
        } 
    ]
}

function init (){
   var elemMain = document.querySelector('main.conteudo');
   var textoHTML= '';
   for(i=0; i<dados.noticias.length; i++)
   {
       var noticia = dados.noticias[i];
       textoHTML= textoHTML+ `
       <div class="box-noticia">
         <img class="thumbnail" src="${noticia.imagem}" width="140" height="140">
         <div class="barra-icones">
             <div class="icone icone_preferida"></div>
             <div class="icone icone_share"></div>
         </div>
         <h3><a href="${noticia.url}" target="_blank">${noticia.titulo}</a></h3>
         <h4><span class="data">${noticia.data}</span> - <span class="fonte">${noticia.fonte}</span></h4>
         <p class="texto">${noticia.resumo} </p>
       </div>
       `
   }



   elemMain.innerHTML = textoHTML;
}