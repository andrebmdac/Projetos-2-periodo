import java.io.*;
import java.util.Random;

class Jogador
{
    private int id;
    private String nome;
    private int altura;
    private int peso;
    private String universidade;
    private String anoNascimento;
    private String cidadeNascimento;
    private String estadoNascimento;
    // construtor que inicia as variáveis
    Jogador()
    {
        this.id=0;
        this.nome="";
        this.altura=0;
        this.peso=0;
        this.universidade="";
        this.anoNascimento="";
        this.cidadeNascimento="";
        this.estadoNascimento="";
    }
    // construtor que atribue os valores padrão as variáveis
    Jogador(int id,String nome,int altura,int peso,String universidade,String anoNascimento,String cidadeNascimento,String estadoNascimento)
    {
        this.id=id;
        this.nome=nome;
        this.altura=altura;
        this.peso=peso;
        this.universidade=universidade;
        this.anoNascimento=anoNascimento;
        this.cidadeNascimento=cidadeNascimento;
        this.estadoNascimento=estadoNascimento;  
    }
    // todos os set a seguir atribuem o valor da variavel lida na linha à variável correspondente da classe
    public void setID(int id)
    {
        this.id=id;
    }
    public void setNome(String nome)
    {
        this.nome=nome;
    }
    public void setAltura(int altura)
    {
        this.altura=altura;
    }
    public void setPeso(int peso)
    {
        this.peso=peso;
    }
    public void setUniversidade(String universidade)
    {
        this.universidade=universidade;
    }
    public void setAnoNascimento(String anoNascimento)
    {
        this.anoNascimento=anoNascimento;
    }
    public void setCidade(String cidadeNascimento)
    {
        this.cidadeNascimento=cidadeNascimento;
    }
    public void setEstado(String estadoNascimento)
    {
        this.estadoNascimento=estadoNascimento;
    }
    // todos os get a seguir retornam o valor da variavel desejada na posicao atual
    public int getID()
    {
        return this.id;
    }
    public String getNome()
    {
        return this.nome;
    }
    public int getAltura()
    {
        return this.altura;
    }
    public int getPeso()
    {
        return this.peso;
    }
    public String getUniversidade()
    {
        return this.universidade;
    }
    public String getAnoNascimento()
    {
        return this.anoNascimento;
    }
    public String getCidade()
    {
        return this.cidadeNascimento;
    }
    public String getEstado()
    {
        return this.estadoNascimento;
    }
}

public class Main{
    public static void main(String[] args){
        double start=System.currentTimeMillis();
        int comp=0;
        Arq.openRead("/tmp/players.csv");
        // String csv = "players.csv";
        String linha=Arq.readLine();
        int i=0;
        Jogador[] vetor=new Jogador[5000];
        while(Arq.hasNext()!=false)
        {
                linha=Arq.readLine();
                vetor[i]=new Jogador();  
                linha=tratarLinha(linha);
                String[] jogadores= linha.split(",");
                vetor[i].setID(i);
                vetor[i].setNome(jogadores[1]);
                vetor[i].setAltura(Integer.parseInt(jogadores[2]));
                vetor[i].setPeso(Integer.parseInt(jogadores[3]));
                vetor[i].setUniversidade(jogadores[4]);
                vetor[i].setAnoNascimento(jogadores[5]);
                vetor[i].setCidade(jogadores[6]);
                vetor[i].setEstado(jogadores[7]);
                i++;
        }
        Arq.close();
        // guarda os codigos em um subarray
        String[] codigo=new String[100];
        int j=0;
        do{
            codigo[j]= new String();
            codigo[j]=MyIO.readString();
            j++;
        }while(isFim(codigo[j-1])==false);
        j--;
        // guarda os nomes em um subarray
        String[] nomes=new String[101];
        int k=0;
        do{
            nomes[k]= new String();
            nomes[k]=MyIO.readLine();
            k++;
        }while(isFim(nomes[k-1])==false);
        k--;
        String agora;
        int pos=0;
        int numAgora=0;
        // percorre o array de nomes
        for(int z=0;z<k;z++)
        {
            // percorre o array original
            for(int v=0;v<i;v++)
            {
                comp++;
                // compara o subarray de nomes na posicao atual com todos os nomes do vetor original
                if(vetor[v].getNome().equals(nomes[z]))
                {
                    // guarda a posicao de nomes coincidentes
                    pos=v;
                    boolean teste=false;
                    // percorre o subarray de codigos buscando o codigo encontrado no vetor original
                    for(int n=0;n<j;n++)
                    {
                        numAgora=Integer.parseInt(codigo[n]);
                        comp++;
                        if(numAgora==pos)
                        {
                            teste=true;  
                        }
                    }
                    comp++;
                    if(teste==true)
                    {
                        MyIO.println("SIM");
                    }
                    else
                    {
                        MyIO.println("NAO");
                    }  
                }
            }
        }
        Arq.openWrite("matricula_sequencial.txt");
        Arq.print("700481");
        Arq.print("\t");
        Arq.print(((System.currentTimeMillis()-start)/1000));
        Arq.print("s");
        Arq.print("\t");
        Arq.print(comp);
        Arq.close();
    }


    // função que corrige as linhas com espaços vazios, substituindo-os por "nao informado"
    public static String tratarLinha(String linha)
    {
        String nova="";
        for(int i=0;i<linha.length();i++)
        {
            if(linha.charAt(i)==',' && i!=linha.length()-1)
            {
                if(linha.charAt(i+1)==',')
                {
                    nova+=",nao informado";
                }
                else
                {
                    nova+=linha.charAt(i);
                }
            }
            else if(linha.charAt(i)==',' && i==linha.length()-1)
            {
                nova+=",nao informado";
            }
            else
            {
                nova+=linha.charAt(i);
            }
        }
        linha=nova;
        return nova;
    }

    // função booleana que testa se a string testada é o marcador de parada "FIM"
    public static boolean isFim(String s)
    {
       return (s.length() == 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }
}