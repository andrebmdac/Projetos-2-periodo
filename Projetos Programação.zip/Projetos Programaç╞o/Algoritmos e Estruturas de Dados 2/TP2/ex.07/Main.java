import java.io.*;
import java.util.Random;

class Jogador
{
    private int id;
    private String nome;
    private int altura;
    private int peso;
    private String universidade;
    private String anoNascimento;
    private String cidadeNascimento;
    private String estadoNascimento;
    // construtor que inicia as variáveis
    Jogador()
    {
        this.id=0;
        this.nome="";
        this.altura=0;
        this.peso=0;
        this.universidade="";
        this.anoNascimento="";
        this.cidadeNascimento="";
        this.estadoNascimento="";
    }
    // construtor que atribue os valores padrão as variáveis
    Jogador(int id,String nome,int altura,int peso,String universidade,String anoNascimento,String cidadeNascimento,String estadoNascimento)
    {
        this.id=id;
        this.nome=nome;
        this.altura=altura;
        this.peso=peso;
        this.universidade=universidade;
        this.anoNascimento=anoNascimento;
        this.cidadeNascimento=cidadeNascimento;
        this.estadoNascimento=estadoNascimento;  
    }
    // todos os set a seguir atribuem o valor da variavel lida na linha à variável correspondente da classe
    public void setID(int id)
    {
        this.id=id;
    }
    public void setNome(String nome)
    {
        this.nome=nome;
    }
    public void setAltura(int altura)
    {
        this.altura=altura;
    }
    public void setPeso(int peso)
    {
        this.peso=peso;
    }
    public void setUniversidade(String universidade)
    {
        this.universidade=universidade;
    }
    public void setAnoNascimento(String anoNascimento)
    {
        this.anoNascimento=anoNascimento;
    }
    public void setCidade(String cidadeNascimento)
    {
        this.cidadeNascimento=cidadeNascimento;
    }
    public void setEstado(String estadoNascimento)
    {
        this.estadoNascimento=estadoNascimento;
    }
    // todos os get a seguir retornam o valor da variavel desejada na posicao atual
    public int getID()
    {
        return this.id;
    }
    public String getNome()
    {
        return this.nome;
    }
    public int getAltura()
    {
        return this.altura;
    }
    public int getPeso()
    {
        return this.peso;
    }
    public String getUniversidade()
    {
        return this.universidade;
    }
    public String getAnoNascimento()
    {
        return this.anoNascimento;
    }
    public String getCidade()
    {
        return this.cidadeNascimento;
    }
    public String getEstado()
    {
        return this.estadoNascimento;
    }
}

public class Main{
    public static void main(String[] args){
        double start=System.currentTimeMillis();
        int comp=0;
        int mov=0;
        Arq.openRead("/tmp/players.csv");
        // String csv = "players.csv";
        String linha=Arq.readLine();
        int i=0;
        Jogador[] vetor=new Jogador[5000];
        int marcador=0;
        // percorre o arquivo guardando as info do arquivo em um vetor
        while(Arq.hasNext()!=false)
        {
                linha=Arq.readLine();
                vetor[i]=new Jogador();   
                linha=tratarLinha(linha);
                String[] jogadores= linha.split(",");
                vetor[i].setID(i);
                vetor[i].setNome(jogadores[1]);
                vetor[i].setAltura(Integer.parseInt(jogadores[2]));
                vetor[i].setPeso(Integer.parseInt(jogadores[3]));
                vetor[i].setUniversidade(jogadores[4]);
                vetor[i].setAnoNascimento(jogadores[5]);
                vetor[i].setCidade(jogadores[6]);
                vetor[i].setEstado(jogadores[7]);
                i++;
        }
        Arq.close();
        String[] codigo=new String[1000];
        Jogador[] vetor2=new Jogador[1000];
        int j=0;
        // recebe os codigos do pub.in
        do{
            codigo[j]= new String();
            codigo[j]=MyIO.readString();
            j++;
        }while(isFim(codigo[j-1])==false);
        j--;
        int z=0;
        // guarda no vetor de jogadores auxiliar as info do jogador na posicao desejada
        for(z=0;z<j;z++)
        {
            vetor2[z]=vetor[Integer.parseInt(codigo[z])];
        }
        for(int k=1;k<z;k++)
        {
            Jogador tmp=vetor2[k];
            j=k-1;
            // ordena o vetor jogador auxiliar apartir de ano nascimento            
            while((j>=0) && (Integer.parseInt(vetor2[j].getAnoNascimento())>Integer.parseInt(tmp.getAnoNascimento())))
            {
                vetor2[j+1]=vetor2[j];
                j--;
            }
            // ordena o vetor jogador auxiliar desempatando os jogadores com mesmo ano nascimento 
            while((j>=0)&&(Integer.parseInt(vetor2[j].getAnoNascimento())==Integer.parseInt(tmp.getAnoNascimento())) && (vetor2[j].getNome().compareTo(tmp.getNome())>0))
            {
                vetor2[j+1]=vetor2[j];
                j--;
            }
            vetor2[j+1]=tmp;
        }
        for(j=0;j<z;j++)
        {
             MyIO.println("["+ vetor2[j].getID() +" ## "+vetor2[j].getNome()+" ## "+vetor2[j].getAltura()+" ## "+vetor2[j].getPeso()+" ## "+vetor2[j].getAnoNascimento()+" ## "+vetor2[j].getUniversidade()+" ## "+vetor2[j].getCidade()+" ## "+vetor2[j].getEstado()+"]");
        }
        
    }


    // função que corrige as linhas com espaços vazios, substituindo-os por "nao informado"
    public static String tratarLinha(String linha)
    {
        String nova="";
        for(int i=0;i<linha.length();i++)
        {
            if(linha.charAt(i)==',' && i!=linha.length()-1)
            {
                if(linha.charAt(i+1)==',')
                {
                    nova+=",nao informado";
                }
                else
                {
                    nova+=linha.charAt(i);
                }
            }
            else if(linha.charAt(i)==',' && i==linha.length()-1)
            {
                nova+=",nao informado";
            }
            else
            {
                nova+=linha.charAt(i);
            }
        }
        linha=nova;
        return nova;
    }

    // função booleana que testa se a string testada é o marcador de parada "FIM"
    public static boolean isFim(String s)
    {
       return (s.length() == 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }
}