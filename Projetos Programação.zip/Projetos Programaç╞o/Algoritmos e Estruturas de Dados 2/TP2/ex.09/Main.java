import java.io.*;
import java.util.Random;


class Jogador
{
    private int id;
    private String nome;
    private int altura;
    private int peso;
    private String universidade;
    private String anoNascimento;
    private String cidadeNascimento;
    private String estadoNascimento;
    // construtor que inicia as variáveis
    Jogador()
    {
        this.id=0;
        this.nome="";
        this.altura=0;
        this.peso=0;
        this.universidade="";
        this.anoNascimento="";
        this.cidadeNascimento="";
        this.estadoNascimento="";
    }
    // construtor que atribue os valores padrão as variáveis
    Jogador(int id,String nome,int altura,int peso,String universidade,String anoNascimento,String cidadeNascimento,String estadoNascimento)
    {
        this.id=id;
        this.nome=nome;
        this.altura=altura;
        this.peso=peso;
        this.universidade=universidade;
        this.anoNascimento=anoNascimento;
        this.cidadeNascimento=cidadeNascimento;
        this.estadoNascimento=estadoNascimento;  
    }
    // todos os set a seguir atribuem o valor da variavel lida na linha à variável correspondente da classe
    public void setID(int id)
    {
        this.id=id;
    }
    public void setNome(String nome)
    {
        this.nome=nome;
    }
    public void setAltura(int altura)
    {
        this.altura=altura;
    }
    public void setPeso(int peso)
    {
        this.peso=peso;
    }
    public void setUniversidade(String universidade)
    {
        this.universidade=universidade;
    }
    public void setAnoNascimento(String anoNascimento)
    {
        this.anoNascimento=anoNascimento;
    }
    public void setCidade(String cidadeNascimento)
    {
        this.cidadeNascimento=cidadeNascimento;
    }
    public void setEstado(String estadoNascimento)
    {
        this.estadoNascimento=estadoNascimento;
    }
    // todos os get a seguir retornam o valor da variavel desejada na posicao atual
    public int getID()
    {
        return this.id;
    }
    public String getNome()
    {
        return this.nome;
    }
    public int getAltura()
    {
        return this.altura;
    }
    public int getPeso()
    {
        return this.peso;
    }
    public String getUniversidade()
    {
        return this.universidade;
    }
    public String getAnoNascimento()
    {
        return this.anoNascimento;
    }
    public String getCidade()
    {
        return this.cidadeNascimento;
    }
    public String getEstado()
    {
        return this.estadoNascimento;
    }
}

public class Main{
    public static int[]alturas = new int[1000];
    public static String[] codigo=new String[1000];
    public static String[] nomes=new String[1000];
    public static void main(String[] args){
        double start=System.currentTimeMillis();
        int comp=0;
        int mov=0;
        Arq.openRead("/tmp/players.csv");
        // String csv = "players.csv";
        String linha=Arq.readLine();
        int i=0;
        Jogador[] vetor=new Jogador[5000];
        while(Arq.hasNext()!=false)
        {
                linha=Arq.readLine();
                vetor[i]=new Jogador();   
                linha=tratarLinha(linha);
                String[] jogadores= linha.split(",");
                vetor[i].setID(i);
                vetor[i].setNome(jogadores[1]);
                vetor[i].setAltura(Integer.parseInt(jogadores[2]));
                vetor[i].setPeso(Integer.parseInt(jogadores[3]));
                vetor[i].setUniversidade(jogadores[4]);
                vetor[i].setAnoNascimento(jogadores[5]);
                vetor[i].setCidade(jogadores[6]);
                vetor[i].setEstado(jogadores[7]);
                i++;
        }
        Arq.close();
        int a=0;
        // recebe os codigo do pub.in
        do{
            codigo[a]= new String();
            codigo[a]=MyIO.readString();
            a++;
        }while(isFim(codigo[a-1])==false);
        a--;
        // o vetor alturas recebe o nome na posicao dos codigo  //int[] alturas=new int[a];
        for(int b=0;b<a;b++)
        {
            alturas[b]=vetor[Integer.parseInt(codigo[b])].getAltura();
            nomes[b]= new String();
            nomes[b]=vetor[Integer.parseInt(codigo[b])].getNome();
        }
        int[] tmp = new int[a+1];
        String[] tmpC = new String[a+1];
        String[] tmpN = new String[a+1];
        for(int j=0;j<a;j++)
        {
            tmpC[j]= new String();
            tmpN[j]= new String();
        }
        for(int j = 0; j < a; j++){
            tmp[j+1] = alturas[j];
            tmpC[j+1] = codigo[j];
            tmpN[j+1]= nomes[j];
        }
        alturas = tmp;
        codigo = tmpC;
        nomes =tmpN;
        //Contrucao do heap
        for(int tamHeap = 2; tamHeap <= a; tamHeap++){
            construir(tamHeap);
        }
        //Ordenacao propriamente dita
        int tamHeap = a;
        while(tamHeap > 1)
        {
            swap(1, tamHeap--);
            reconstruir(tamHeap);
        }
        //Alterar o vetor para voltar a posicao zero
        tmp = alturas;
        tmpC = codigo;
        tmpN = nomes;
        alturas = new int[a];
        for(int j = 0; j < a; j++){
            alturas[j] = tmp[j+1];
            codigo[j] = tmpC[j+1];
            nomes[j] = tmpN[j+1];
        }
        
        for(int j=0;j<a;j++)
        {
            for(int t=j+1;t<a;t++)
            {
                comp++;
                if(alturas[j]==alturas[t])
                {
                    comp++;
                    if(nomes[j].compareTo(nomes[t])>0)
                    {
                        mov++;
                        String aux=nomes[j];
                        nomes[j]=nomes[t];
                        nomes[t]=aux;
                    }
                }
            }
        }
        for(int j=0;j<a;j++)
        {
            for(int h=0;h<i;h++)
            {
                if((nomes[j].compareTo(vetor[h].getNome())==0))
                {
                    MyIO.println("["+ vetor[h].getID() +" ## "+vetor[h].getNome()+" ## "+vetor[h].getAltura()+" ## "+vetor[h].getPeso()+" ## "+vetor[h].getAnoNascimento()+" ## "+vetor[h].getUniversidade()+" ## "+vetor[h].getCidade()+" ## "+vetor[h].getEstado()+"]");
                    if(vetor[h].getID()==222)
                    {
                        h+=2;
                    }                    
                }
            }
        }
        Arq.openWrite("matricula_heapsort.txt");
        Arq.print("700481");
        Arq.print("    ");
        Arq.print(comp);
        Arq.print("    ");
        Arq.print(mov);
        Arq.print("    ");
        Arq.print(((System.currentTimeMillis()-start)/1000));
        Arq.print("s");
        Arq.close();
    }

    // função que corrige as linhas com espaços vazios, substituindo-os por "nao informado"
    public static String tratarLinha(String linha)
    {
        String nova="";
        for(int i=0;i<linha.length();i++)
        {
            if(linha.charAt(i)==',' && i!=linha.length()-1)
            {
                if(linha.charAt(i+1)==',')
                {
                    nova+=",nao informado";
                }
                else
                {
                    nova+=linha.charAt(i);
                }
            }
            else if(linha.charAt(i)==',' && i==linha.length()-1)
            {
                nova+=",nao informado";
            }
            else
            {
                nova+=linha.charAt(i);
            }
        }
        linha=nova;
        return nova;
    }
    // função booleana que testa se a string testada é o marcador de parada "FIM"
    public static boolean isFim(String s)
    {
       return (s.length() == 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }
    public static void construir(int tamHeap){
      for(int i = tamHeap; i > 1 && alturas[i] > alturas[i/2]; i /= 2){
         swap(i, i/2);
      }
    }

    public static void reconstruir(int tamHeap){
      int i = 1;
      while(i <= (tamHeap/2)){
         int filho = getMaiorFilho(i, tamHeap);
         if(alturas[i] < alturas[filho]){
            swap(i, filho);
            i = filho;
         }else{
            i = tamHeap;
         }
      }
    }

    public static int getMaiorFilho(int i, int tamHeap){
      int filho;
      if (2*i == tamHeap || alturas[2*i] > alturas[2*i+1]){
         filho = 2*i;
      } else {
         filho = 2*i + 1;
      }
      return filho;
    }

    public static void swap(int i, int j) {
      int temp = alturas[i];
      String temp2= codigo[i];
      String temp3= nomes[i];
      alturas[i] = alturas[j];
      codigo[i] = codigo[j];
      nomes[i]= nomes[j];
      alturas[j] = temp;
      codigo[j] = temp2;
      nomes[j] = temp3;
   }
}



