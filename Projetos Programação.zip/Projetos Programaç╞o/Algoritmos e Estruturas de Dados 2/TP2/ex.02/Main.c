#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define MAX 5000


typedef struct jogador
{
    int ID;
    int altura;
    int peso;
    char nome[MAX];
    char universidade[MAX];
    int anoNascimento;
    char cidadeNascimento[MAX];
    char estadoNascimento[MAX];
}Jogador;

Jogador jogadores[5000];
int numJogadores = 0;

Jogador clone(int i){
    Jogador clone;
    clone.ID = jogadores[i].ID;
    clone.altura = jogadores[i].altura;
    clone.peso = jogadores[i].peso;
    clone.anoNascimento = jogadores[i].anoNascimento;
    strcpy(clone.nome, jogadores[i].nome);
    strcpy(clone.universidade, jogadores[i].universidade);
    strcpy(clone.cidadeNascimento, jogadores[i].cidadeNascimento);
    strcpy(clone.estadoNascimento, jogadores[i].estadoNascimento);
    return clone;
}

int getID(int i);
int getAltura(int i);
int getPeso(int i);
int getAnoNascimento(int i);
char* getNome(int i);
char* getUniversidade(int i);
char* getCidadeNascimento(int i);
char* getEstadoNascimento(int i);
void imprimirInfo(int i);
Jogador clone(int i);

// faz a quebra das informações da linha, guardando em um vetor
void strSplit(char *str, char *dados[], char *marcador, int tam){
    char *parte;
    parte = strsep(&str, marcador);
    for(int i = 0; i < tam; i++){
        dados[i] = parte;
        parte = strsep(&str, marcador);
    }
}

// substitui os \r(tecla enter) por \0
void corrigeQuebra(char linha[]){
    int comprimento = strlen(linha);
    if(linha[comprimento-2] == '\r' && linha[comprimento-1] == '\n'){
        linha[comprimento-2] = '\0';
    }else if (linha[comprimento-1] == '\r' || linha[comprimento-1] == '\n'){
        linha[comprimento-1] = '\0';
    }
}

// preenche o vetor jogadores na posicao atual com os dados de jogador lidos na linha atual
void preencheDados(char *dados[], int i){
    jogadores[i].ID = atoi(dados[0]);
    strcpy(jogadores[i].nome, (const char*)(dados[1]));
    jogadores[i].altura = atoi(dados[2]);
    jogadores[i].peso = atoi(dados[3]);
    if(*dados[4]=='\0'){
        dados[4]="nao informado";
    }
    jogadores[i].anoNascimento = atoi(dados[5]);
    if(*dados[6]=='\0'){
        dados[6]="nao informado";
    }
    if(*dados[7]=='\0'){
        dados[7]="nao informado";
    }
    strcpy(jogadores[i].universidade, (const char*)(dados[4]));
    strcpy(jogadores[i].cidadeNascimento, (const char*)(dados[6]));
    strcpy(jogadores[i].estadoNascimento, (const char*)(dados[7]));
}

// le o arquivo jogadores
void lerArquivo(){
    FILE *csv = fopen("/tmp/players.csv", "r");
    char * infoLeitura[8];
    char linha[MAX];
    int i = 0;
    // da o fgets duas vezes para corrigir pois a primeira linha do arquivo deve ser desconsiderada
    fgets(linha, 1024, csv);
    fgets(linha, 1024, csv);
    // lê enquanto não chega ao final do arquivo
    while(!feof(csv)){
        corrigeQuebra(linha);
        strSplit(linha, infoLeitura, ",", 8);
        preencheDados(infoLeitura, i);
        i++;
        fgets(linha, 1024, csv);
    }
    fclose(csv);
}


// imprime os dados do jogador desejado
void imprimirInfo(int i){
    printf("[%d ## %s ## %d ## %d ## %d ## %s ## %s ## %s]\n", jogadores[i].ID, jogadores[i].nome,jogadores[i].altura, jogadores[i].peso, jogadores[i].anoNascimento, jogadores[i].universidade, jogadores[i].cidadeNascimento, jogadores[i].estadoNascimento); 
}

// todos os set a seguir atribuem ao dado no vetor jogador a informação lida na linha do arquivo correspondente
void setID(int i, int novoID){
    jogadores[i].ID = novoID;
}

void setAltura(int i, int novaAltura){
    jogadores[i].altura = novaAltura;
}

void setPeso(int i, int novoPeso){
    jogadores[i].peso = novoPeso;
}

void setNome(int i, char novoNome[]){
    strcpy(jogadores[i].nome, novoNome);
}

void setAnoNascimento(int i, int novoAnoNascimento){
    jogadores[i].anoNascimento = novoAnoNascimento;
}

void setUniversidade(int i, char novaUniversidade[]){
    strcpy(jogadores[i].universidade, novaUniversidade);
}

void setCidadeNascimento(int i, char novaCidadeNascimento[]){
    strcpy(jogadores[i].cidadeNascimento, novaCidadeNascimento);
}

void setEstadoNascimento(int i, char novoEstadoNascimento[]){
    strcpy(jogadores[i].estadoNascimento, novoEstadoNascimento);
}

// todos os get a seguir retornam a info do jogador na linha desejada
int getID(int i){
    return jogadores[i].ID;
}

int getAltura(int i){
    return jogadores[i].altura;
}

int getPeso(int i){
    return jogadores[i].peso;
}

int getAnoNascimento(int i){
    return jogadores[i].anoNascimento;
}

char* getNome(int i){
    return jogadores[i].nome;
}

char* getUniversidade(int i){
    return jogadores[i].universidade;
}

char* getCidadeNascimento(int i){
    return jogadores[i].cidadeNascimento;
}

char* getEstadoNascimento(int i){
    return jogadores[i].estadoNascimento;
}


int main(){
    char ID_Jogador[MAX];
    scanf(" %[^\n]", ID_Jogador);
    lerArquivo();
    do{
        int num = atoi(ID_Jogador);
        imprimirInfo(num);
        scanf(" %[^\n]", ID_Jogador);
    }while(strcmp(ID_Jogador, "FIM") != 0);
    return 0;
}





