#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define TAM 5000

typedef struct Jogador{
    int ID, altura, peso, anoNascimento;
    char nome[TAM];
    char universidade[TAM];
    char cidadeNascimento[TAM];
    char estadoNascimento[TAM];
}Jogador;

Jogador jogadores[5000];

void strSplit(char *str, char *strArr[], char *strSeparet, int nArr){
    char *agora;
    agora = strsep(&str, strSeparet);
    for(int i = 0; i < nArr; i++){
        strArr[i] = agora;
        agora = strsep(&str, strSeparet);
    }
}

void arrumarLinha(char s[]){
    int tam = strlen(s);
    if(s[tam-1] == '\n' && s[tam-2] == '\r' ){
        s[tam-2] = '\0';
    }else if ( s[tam-1] == '\n' || s[tam-1] == '\r'){
        s[tam-1] = '\0';
    }
}

void completarNF(char *arr[], int i){
    jogadores[i].ID = atoi(arr[0]);
    strcpy(jogadores[i].nome, (const char*)(arr[1]));
    jogadores[i].altura = atoi(arr[2]);
    jogadores[i].peso = atoi(arr[3]);
    if(*arr[4]=='\0'){
        arr[4]="nao informado";
    }
    jogadores[i].anoNascimento = atoi(arr[5]);
    if(*arr[6]=='\0'){
        arr[6]="nao informado";
    }
    if(*arr[7]=='\0'){
        arr[7]="nao informado";
    }
    strcpy(jogadores[i].universidade, (const char*)(arr[4]));
    strcpy(jogadores[i].cidadeNascimento, (const char*)(arr[6]));
    strcpy(jogadores[i].estadoNascimento, (const char*)(arr[7]));
}


void setId(int i, int newID){
    jogadores[i].ID = newID;
}

void setAltura(int i, int newAltura){
    jogadores[i].altura = newAltura;
}

void setPeso(int i, int newPeso){
    jogadores[i].peso = newPeso;
}

void setUni(int i, char newUni[]){
    strcpy(jogadores[i].universidade, newUni);
}

void setCidade(int i, char newCidadeNascimento[]){
    strcpy(jogadores[i].cidadeNascimento, newCidadeNascimento);
}

void setNome(int i, char newNome[]){
    strcpy(jogadores[i].nome, newNome);
}

void setAno(int i, int newAnoNascimento){
    jogadores[i].anoNascimento = newAnoNascimento;
}

void setEstado(int i, char newEstadoNascimento[]){
    strcpy(jogadores[i].estadoNascimento, newEstadoNascimento);
}


char* getUni(int i){
    return jogadores[i].universidade;
}

char* getCidade(int i){
    return jogadores[i].cidadeNascimento;
}

char* getEstado(int i){
    return jogadores[i].estadoNascimento;
}

int getPeso(int i){
    return jogadores[i].peso;
}

int getAno(int i){
    return jogadores[i].anoNascimento;
}

int getId(int i){
    return jogadores[i].ID;
}

int getAltura(int i){
    return jogadores[i].altura;
}

char* getName(int i){
    return jogadores[i].nome;
}


Jogador clone(int i){
    Jogador clone;
    clone.altura = jogadores[i].altura;
    clone.peso = jogadores[i].peso;
    clone.anoNascimento = jogadores[i].anoNascimento;
    clone.ID = jogadores[i].ID;
    strcpy(clone.universidade, jogadores[i].universidade);
    strcpy(clone.nome, jogadores[i].nome);
    strcpy(clone.estadoNascimento, jogadores[i].estadoNascimento);
    strcpy(clone.cidadeNascimento, jogadores[i].cidadeNascimento);
    return clone;
}


void lerArq(){
    FILE *arq = fopen("/tmp/players.csv", "r");
    int i = 0;
    char * infos[8], str[TAM];
    fgets(str, 1024, arq);
    fgets(str, 1024, arq);
    while(!feof(arq)){
        arrumarLinha(str);
        strSplit(str, infos, ",", 8);
        completarNF(infos, i);
        fgets(str, 1024, arq);
        i++;
    }
    fclose(arq);
}


void printarInfo(int i){
    printf("[%d ## %s ## %d ## %d ## %d ## %s ## %s ## %s]\n", jogadores[i].ID, jogadores[i].nome,jogadores[i].altura, jogadores[i].peso, jogadores[i].anoNascimento, jogadores[i].universidade, jogadores[i].cidadeNascimento, jogadores[i].estadoNascimento);
}

typedef struct nomesEntrada{
    int peso;
    char nome[200];
}pubInPlayers;

pubInPlayers infoArq[TAM];
pubInPlayers aux[TAM];
int codPubIn[TAM];
int comp = 0;
int mov = 0;

clock_t inicio, fim, tempo;

void shellsort(int);
void insercaoPorCor(int, int, int);

int main(){
    lerArq();
    char id[TAM];
    int numCodEntrada = 0;
    scanf(" %[^\n]c", id);
    while(strcmp(id,"FIM") != 0){
        int cod = atoi(id);
        scanf(" %[^\n]c", id);
        codPubIn[numCodEntrada++] = cod;          
    }

    for (int i = 0; i < numCodEntrada; i++){            
        infoArq[i].peso = jogadores[codPubIn[i]].peso;
        strcpy(infoArq[i].nome, jogadores[codPubIn[i]].nome);
    }

    inicio = clock();                   
    shellsort(numCodEntrada);
    fim = clock();                      
    tempo = fim-inicio;

    for (int i = 0; i < numCodEntrada; i++){                       
        for (int j = i+1; j < numCodEntrada; j++){                  
            if (infoArq[i].peso == infoArq[j].peso){
                if(strcmp(infoArq[i].nome, infoArq[j].nome) > 0){
                    char AuxNome[200];
                    int AuxCode , AuxPeso;

                    AuxCode = codPubIn[i];
                    codPubIn[i] = codPubIn[j];
                    codPubIn[j] = AuxCode;

                    strcpy(AuxNome, infoArq[i].nome);
                    strcpy(infoArq[i].nome, infoArq[j].nome);
                    strcpy(infoArq[j].nome, AuxNome);

                    AuxPeso = infoArq[i].peso;
                    infoArq[i].peso = infoArq[j].peso;
                    infoArq[j].peso = AuxPeso;
                }
            }
        }
    }

    for (int i = 0; i < numCodEntrada; i++){
        printarInfo(codPubIn[i]);
    }

    FILE *arq = fopen(" matrícula_shellsort.txt", "w");
    fputs("700481", arq);
    fputc('\t', arq);
    fprintf(arq, "%d", comp);
    fputc('\t', arq);
    fprintf(arq, "%d", mov);
    fputc('\t', arq);
    fprintf(arq, "%.4lf", ((double)tempo));

    return 0;
}


void shellsort(int n) {
    int h = 1;
    do { h = (h * 3) + 1; } while (h < n);
    do {
        h /= 3;
        for(int cor = 0; cor < h; cor++){
            insercaoPorCor(n, cor, h);
        }
    } while (h != 1);
}

void insercaoPorCor(int n, int cor, int h){
    for (int i = (h + cor); i < n; i+=h) {
        int tmp = infoArq[i].peso;
        int code = codPubIn[i];
        char nomeAux[200];
        strcpy(nomeAux, infoArq[i].nome);
        int j = i - h;
        while ((j >= 0) && (infoArq[j].peso > tmp)) {           
            comp++;
            infoArq[j + h].peso = infoArq[j].peso;
            codPubIn[j + h] = codPubIn[j];
            strcpy(infoArq[j + h].nome, infoArq[j].nome);
            j-=h;
            mov+=3;
        }
        infoArq[j + h].peso = tmp;
        codPubIn[j+h] = code;
        strcpy(infoArq[j + h].nome, nomeAux);
        mov+=3;
    }
}