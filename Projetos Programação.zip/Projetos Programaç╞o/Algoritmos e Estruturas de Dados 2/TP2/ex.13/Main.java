import java.io.*;
import java.util.Random;


class Jogador
{
    private int id;
    private String nome;
    private int altura;
    private int peso;
    private String universidade;
    private String anoNascimento;
    private String cidadeNascimento;
    private String estadoNascimento;
    // construtor que inicia as variáveis
    Jogador()
    {
        this.id=0;
        this.nome="";
        this.altura=0;
        this.peso=0;
        this.universidade="";
        this.anoNascimento="";
        this.cidadeNascimento="";
        this.estadoNascimento="";
    }
    // construtor que atribue os valores padrão as variáveis
    Jogador(int id,String nome,int altura,int peso,String universidade,String anoNascimento,String cidadeNascimento,String estadoNascimento)
    {
        this.id=id;
        this.nome=nome;
        this.altura=altura;
        this.peso=peso;
        this.universidade=universidade;
        this.anoNascimento=anoNascimento;
        this.cidadeNascimento=cidadeNascimento;
        this.estadoNascimento=estadoNascimento;  
    }
    // todos os set a seguir atribuem o valor da variavel lida na linha à variável correspondente da classe
    public void setID(int id)
    {
        this.id=id;
    }
    public void setNome(String nome)
    {
        this.nome=nome;
    }
    public void setAltura(int altura)
    {
        this.altura=altura;
    }
    public void setPeso(int peso)
    {
        this.peso=peso;
    }
    public void setUniversidade(String universidade)
    {
        this.universidade=universidade;
    }
    public void setAnoNascimento(String anoNascimento)
    {
        this.anoNascimento=anoNascimento;
    }
    public void setCidade(String cidadeNascimento)
    {
        this.cidadeNascimento=cidadeNascimento;
    }
    public void setEstado(String estadoNascimento)
    {
        this.estadoNascimento=estadoNascimento;
    }
    // todos os get a seguir retornam o valor da variavel desejada na posicao atual
    public int getID()
    {
        return this.id;
    }
    public String getNome()
    {
        return this.nome;
    }
    public int getAltura()
    {
        return this.altura;
    }
    public int getPeso()
    {
        return this.peso;
    }
    public String getUniversidade()
    {
        return this.universidade;
    }
    public String getAnoNascimento()
    {
        return this.anoNascimento;
    }
    public String getCidade()
    {
        return this.cidadeNascimento;
    }
    public String getEstado()
    {
        return this.estadoNascimento;
    }
}

public class Main{
    public static String[] universidade = new String[2000];
    public static String[] nomes=new String[2000];
    public static String[] codigo=new String[2000];
    public static void main(String[] args){
        double start=System.currentTimeMillis();
        int comp=0;
        int mov=0;
        Arq.openRead("/tmp/players.csv");
        // String csv = "players.csv";
        String linha=Arq.readLine();
        int j=0;
        Jogador[] vetor=new Jogador[5000];
        while(Arq.hasNext()!=false)
        {
                linha=Arq.readLine();
                vetor[j]=new Jogador();   
                linha=tratarLinha(linha);
                String[] jogadores= linha.split(",");
                vetor[j].setID(j);
                vetor[j].setNome(jogadores[1]);
                vetor[j].setAltura(Integer.parseInt(jogadores[2]));
                vetor[j].setPeso(Integer.parseInt(jogadores[3]));
                vetor[j].setUniversidade(jogadores[4]);
                vetor[j].setAnoNascimento(jogadores[5]);
                vetor[j].setCidade(jogadores[6]);
                vetor[j].setEstado(jogadores[7]);
                j++;
        }
        Arq.close();
        int a=0;
        // recebe os codigo do pub.in
        do{
            codigo[a]= new String();
            codigo[a]=MyIO.readString();
            a++;
        }while(isFim(codigo[a-1])==false);
        a--;
        for(int b=0;b<a;b++)
        {
            universidade[b]= new String();
            universidade[b]=vetor[Integer.parseInt(codigo[b])].getUniversidade();
            nomes[b]= new String();
            nomes[b]=vetor[Integer.parseInt(codigo[b])].getNome();
        }
        sort(a, comp, mov);
        for(int p=0;p<a;p++)
        {
            for(int t=p+1;t<a;t++)
            {
                if(universidade[p].compareTo(universidade[t])==0)
                {
                    if(nomes[p].compareTo(nomes[t])>0)
                    {
                        String aux=nomes[p];
                        nomes[p]=nomes[t];
                        nomes[t]=aux;
                    }
                }
            }
        }
        for(int p=0;p<a;p++)
        {
            for(int h=0;h<j;h++)
            {
                if((nomes[p].compareTo(vetor[h].getNome())==0))
                {
                    MyIO.println("["+ vetor[h].getID() +" ## "+vetor[h].getNome()+" ## "+vetor[h].getAltura()+" ## "+vetor[h].getPeso()+" ## "+vetor[h].getAnoNascimento()+" ## "+vetor[h].getUniversidade()+" ## "+vetor[h].getCidade()+" ## "+vetor[h].getEstado()+"]");
                    if(vetor[h].getID()==222)
                    {
                        h+=2;
                    }                    
                }
            }
        }
        Arq.openWrite("matricula_mergesort.txt");
        Arq.print("700481");
        Arq.print("    ");
        Arq.print(comp);
        Arq.print("    ");
        Arq.print(mov);
        Arq.print("    ");
        Arq.print(((System.currentTimeMillis()-start)/1000));
        Arq.print("s");
        Arq.close();
        
        
        
    }

    // função que corrige as linhas com espaços vazios, substituindo-os por "nao informado"
    public static String tratarLinha(String linha)
    {
        String nova="";
        for(int i=0;i<linha.length();i++)
        {
            if(linha.charAt(i)==',' && i!=linha.length()-1)
            {
                if(linha.charAt(i+1)==',')
                {
                    nova+=",nao informado";
                }
                else
                {
                    nova+=linha.charAt(i);
                }
            }
            else if(linha.charAt(i)==',' && i==linha.length()-1)
            {
                nova+=",nao informado";
            }
            else
            {
                nova+=linha.charAt(i);
            }
        }
        linha=nova;
        return nova;
    }
    // função booleana que testa se a string testada é o marcador de parada "FIM"
    public static boolean isFim(String s)
    {
       return (s.length() == 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }

    public static void sort(int a,int comp,int mov) {
        mergesort(0, a-1,comp , mov);
    }

    public static void mergesort(int esq, int dir, int comp, int mov) {
        if (esq < dir){
            comp++;
            int meio = esq+((dir-esq)/2);
            mergesort(esq, meio, comp, mov);
            mergesort(meio+1, dir, comp, mov);
            intercalar(esq, meio, dir, comp, mov);
        }
    }
    
    public static void intercalar(int esq, int meio, int dir, int comp, int mov) {
        int n = dir - esq + 1;      
        String[] b = new String[n];
        String[] b2 = new String[n];  
        int n1 = esq;               
        int n2 = meio + 1;            
        int j = 0;                   
        while (n1 <= meio && n2 <= dir) {
            comp++;
            if (universidade[n1].compareTo(universidade[n2]) < 0) {
                mov++;
                b[j] = universidade[n1];
                b2[j] = nomes[n1];
                n1++;
            } else {
                mov++;
                b[j] = universidade[n2];
                b2[j] = nomes[n2];
                n2++;
            }
            j++;
        }

        while (n1 <= meio) {
            comp++;
            b[j] = universidade[n1];
            b2[j] = nomes[n1];
            n1++;
            j++;
        }

        while (n2 <= dir) {
            comp++;
            b[j] = universidade[n2];
            b2[j] = nomes[n2];
            n2++;
            j++;
        }

        for (j = 0; j < n; j++) {
            mov+=2;
            universidade[esq + j] = b[j];
            nomes[esq + j] = b2[j];
        }    
    }

}    



