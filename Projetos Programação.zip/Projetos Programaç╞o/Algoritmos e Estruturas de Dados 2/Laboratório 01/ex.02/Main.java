public class Main{
  public static void main(String args[]){
    String frase = MyIO.readLine();
    do{
      int z = 0;
      z = isMaiuscula(frase);
      MyIO.println(z);
      frase = MyIO.readLine();
    }while(isFim(frase)==false);
  }

  public static int isMaiuscula(String s){
    int result = 0;
    int i = 0;
    if(s.length() == i){
        return 0;
    }else{
        if(Character.isUpperCase(s.charAt(0)) == true){
            result++;
            return isMaiuscula(s.substring(1))+1;
        }
        else{
            return isMaiuscula(s.substring(1));
        }
    }
  }

  public static boolean isFim(String s){
    return (s.length() == 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
  }

}
