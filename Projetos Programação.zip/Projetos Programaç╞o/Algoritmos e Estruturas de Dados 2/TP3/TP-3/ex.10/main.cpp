#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <string.h>

#define tamLimiteLinha 250
#define tamMax 5000

typedef struct {
    int id;
    int peso;
    int altura;
    char nome[70];
    char universidade[70];
    int anoNascimento;
    char cidadeNascimento[70];
    char estadoNascimento[70];
}Jogador;

typedef struct Celula{
	Jogador jog;        
	struct Celula* prox; 
}Celula;

Celula* novaCelula(Jogador jog) {
   Celula* nova = (Celula*) malloc(sizeof(Celula));
   nova->jog = jog;
   nova->prox = NULL;
   return nova;
}

Celula* topo = NULL;

Jogador clone(Jogador *jogador);
char* montaSubstring(char str[], int start, int end);
void insere(Jogador x);
Jogador remover();
int printarInverso(int contador, Celula* i);
Jogador vetCompletoJogadores[tamMax];

void insereNaoInformado(char *line, char *linhaNova) {
    int tam = strlen(line);
    for (int i = 0; i <= tam; i++, line++) {
        *linhaNova++ = *line;
        if (*line == ',' && (*(line + 1) == ',' || *(line + 1) == '\0')) {
            strcpy(linhaNova, "nao informado");
            linhaNova += strlen("nao informado");
        }
    }
}

void removerQuebraDeLinha(char line[]) {
    int tam = strlen(line);
    if (line[tam - 2] == '\r' && line[tam - 1] == '\n') 
        line[tam - 2] = '\0'; 

    else if (line[tam - 1] == '\r' || line[tam - 1] == '\n') 
        line[tam - 1] = '\0'; 
}

void lerInfo(Jogador *jogador, char linha[]) {
    char linhaNova[tamLimiteLinha];
    removerQuebraDeLinha(linha);
    insereNaoInformado(linha, linhaNova);
    jogador->id = atoi(strtok(linhaNova, ","));
    strcpy(jogador->nome, strtok(NULL, ","));
    jogador->altura = atoi(strtok(NULL, ","));
    jogador->peso = atoi(strtok(NULL, ","));
    strcpy(jogador->universidade, strtok(NULL, ","));
    jogador->anoNascimento = atoi(strtok(NULL, ","));
    strcpy(jogador->cidadeNascimento, strtok(NULL, ","));
    strcpy(jogador->estadoNascimento, strtok(NULL, ","));
}


Jogador clone(Jogador *jogador) {
    Jogador clone;
    clone.id = jogador->id;
    strcpy(clone.nome, jogador->nome);
    clone.altura = jogador->altura;
    clone.peso = jogador->peso;
    clone.anoNascimento = jogador->anoNascimento;
    strcpy(clone.universidade, jogador->universidade);
    strcpy(clone.cidadeNascimento, jogador->cidadeNascimento);
    strcpy(clone.estadoNascimento, jogador->estadoNascimento);
    return clone;
}

void preencheVetJogInfoArq(){
    FILE *csv = fopen("/tmp/players.csv", "r");
    char * infos_receb[8];
    char linha[tamLimiteLinha];
    int i = 0;
    fgets(linha, 1024, csv);
    fgets(linha, 1024, csv);
    while(!feof(csv)){
        lerInfo(&vetCompletoJogadores[i], linha);
        i++;
        fgets(linha, 1024, csv);
    }
    fclose(csv);
}

void preencherPilha(){
    char line[tamLimiteLinha];
    scanf("%s", line);
    do{
        insere(vetCompletoJogadores[atoi(line)]);
        scanf("%s", line);
    }while(strcmp(line, "FIM")!=0);
}

void insere(Jogador jog) {
   Celula* tmp = novaCelula(jog);
   tmp->prox = topo;
   topo = tmp;
   tmp = NULL;
}

Jogador remover() {
   if (topo == NULL) {
      printf("Erro ao remover!");
   }
   Jogador jogad = topo->jog;
   Celula* tmp = topo;
   topo = topo->prox;
   tmp->prox = NULL;
   free(tmp);
   tmp = NULL;
   return jogad;
}

int printarInverso(int contador, Celula* i){
    if(i!=NULL){
        contador = printarInverso(contador, i->prox);
        printf("[%d] ## %s ## %d ## %d ## %d ## %s ## %s ## %s ##\n",contador,i->jog.nome,i->jog.altura,i->jog.peso,i->jog.anoNascimento,i->jog.universidade,i->jog.cidadeNascimento,i->jog.estadoNascimento);
        contador++;
    }
    return contador;
}

void corrigirCommandLine(char *linha){
    removerQuebraDeLinha(linha);
    if(linha[0] == 'I'){
        char *linhaNova = montaSubstring(linha, 2, strlen(linha));
        insere(vetCompletoJogadores[atoi(linhaNova)]);
    }else if(linha[0] == 'R'){
        Jogador excluido = remover();
        printf("(R) %s\n", excluido.nome);
    }
}

char* montaSubstring(char str[], int comeco, int fim) {
    int i, j;
    char *substituta; 
    if(comeco >= fim || fim > strlen(str)) {
        return NULL;
    }
    substituta = (char *) malloc(sizeof(char) * (fim - comeco + 1));    
    for(i = comeco, j = 0; i < fim; i++, j++) {
        substituta[j] = str[i];
    }
    substituta[j] = '\0';
    return substituta;
}

int main(){
    preencheVetJogInfoArq();
    preencherPilha();
    int qtdOps;
    scanf("%d", &qtdOps);
    char linhaComando[tamLimiteLinha];
    scanf(" %[^\n]", linhaComando);
    do{
		corrigirCommandLine(linhaComando);
        scanf(" %[^\n]", linhaComando);
	}while(--qtdOps > 0);
    int x = printarInverso(0, topo);
    return 0;
}