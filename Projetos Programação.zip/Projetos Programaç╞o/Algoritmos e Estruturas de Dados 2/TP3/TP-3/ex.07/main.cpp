#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <string.h>

#define tamLimiteLinha 250
#define tamMax 5000

typedef struct {
    int id;
    int peso;
    int altura;
    char nome[70];
    char universidade[70];
    int anoNascimento;
    char cidadeNascimento[70];
    char estadoNascimento[70];
}Jogador;

typedef struct Celula{
    Jogador elemento;
    struct Celula *prox;
}Celula;

typedef struct Fila{
    struct Celula *primeiro, *ultimo;
    int size;
} Fila;

Jogador clone(Jogador *jogador);
char* montaSubstring(char str[], int start, int end);
Jogador desenfilaFila(Fila *f);
Fila novaFila();
void enfileiraFila(Fila *f, Jogador elemento);
Celula* novaCelula(Jogador elemento);
void calculaMediaAlturaFila(Fila *f);
int aproximacao(double number);

Fila novaFila(){
    Fila temporario;
    Jogador jog;
    temporario.primeiro = temporario.ultimo = novaCelula(jog);
    temporario.size = 0;
    return temporario;
}

void enfileiraFila(Fila *queue, Jogador jog){
    queue->ultimo->prox = novaCelula(jog);
    queue->ultimo = queue->ultimo->prox;
    queue->size++;
}

Jogador desenfilaFila(Fila *queue){
    Celula *cel = queue->primeiro;
    queue->primeiro = queue->primeiro->prox;
    queue->size--;
    free(cel);
    return queue->primeiro->elemento;
}

void printarFila(Fila *queue){
    Celula *cel;
    int cont = 0;
    for (cel = queue->primeiro->prox; cel != NULL; cel = cel->prox, cont++)
    {
        printf("[%d] ## %s ## %d ## %d ## %d ## %s ## %s ## %s ##\n",cont,cel->elemento.nome, cel->elemento.altura,cel->elemento.peso,cel->elemento.anoNascimento,cel->elemento.universidade,cel->elemento.cidadeNascimento,cel->elemento.estadoNascimento);
    }
}


Celula* novaCelula(Jogador elemento){
    Celula *temp = (Celula*)malloc(sizeof(Celula));
    temp->elemento = elemento;
    temp->prox = NULL;
    return temp;
}

Jogador vetCompletoJogadores[tamMax];
Fila f;

void insereNF(char *line, char *linhaNova) {
    int tam = strlen(line);
    for (int i = 0; i <= tam; i++, line++) {
        *linhaNova++ = *line;
        if (*line == ',' && (*(line + 1) == ',' || *(line + 1) == '\0')) {
            strcpy(linhaNova, "nao informado");
            linhaNova += strlen("nao informado");
        }
    }
}

void removeQuebraDeLinha(char linha[]) {
    int tam = strlen(linha);
    if (linha[tam - 2] == '\r' && linha[tam - 1] == '\n')
    {
        linha[tam - 2] = '\0'; 
    }
    else if (linha[tam - 1] == '\r' || linha[tam - 1] == '\n')
    { 
        linha[tam - 1] = '\0'; 
    }
}

void lerInfo(Jogador *jog, char linha[]) 
{
    char novaLinha[tamLimiteLinha];
    removeQuebraDeLinha(linha);
    insereNF(linha, novaLinha);
    jog->id = atoi(strtok(novaLinha, ","));
    strcpy(jog->nome, strtok(NULL, ","));
    jog->altura = atoi(strtok(NULL, ","));
    jog->peso = atoi(strtok(NULL, ","));
    strcpy(jog->universidade, strtok(NULL, ","));
    jog->anoNascimento = atoi(strtok(NULL, ","));
    strcpy(jog->cidadeNascimento, strtok(NULL, ","));
    strcpy(jog->estadoNascimento, strtok(NULL, ","));
}


Jogador clone(Jogador *jogador) {
    Jogador clone;
    clone.id = jogador->id;
    strcpy(clone.nome, jogador->nome);
    clone.altura = jogador->altura;
    clone.peso = jogador->peso;
    clone.anoNascimento = jogador->anoNascimento;
    strcpy(clone.universidade, jogador->universidade);
    strcpy(clone.cidadeNascimento, jogador->cidadeNascimento);
    strcpy(clone.estadoNascimento, jogador->estadoNascimento);
    return clone;
}


void preencheVetJogComInfoArq(){
    FILE *csv = fopen("/tmp/players.csv", "r");
    char * infos_receb[8];
    char line[tamLimiteLinha];
    int i = 0;
    fgets(line, 1024, csv);
    fgets(line, 1024, csv);
    while(!feof(csv)){
        lerInfo(&vetCompletoJogadores[i], line);
        i++;
        fgets(line, 1024, csv);
    }
    fclose(csv);
}


void preencherFila(){
    f = novaFila();
    char linha[tamLimiteLinha];
    scanf("%s", linha);
    do{
        if(f.size<5){
            enfileiraFila(&f, vetCompletoJogadores[atoi(linha)]);
            calculaMediaAlturaFila(&f);
        }else{
            Jogador tmp = desenfilaFila(&f);
            enfileiraFila(&f, vetCompletoJogadores[atoi(linha)]);
            calculaMediaAlturaFila(&f);
        }
        scanf("%s", linha);
    }while(strcmp(linha, "FIM")!=0);
}

void calculaMediaAlturaFila(Fila *f){
    double soma = 0;
    Celula *cel;
    int cont = 0;
    for (cel = f->primeiro->prox; cel != NULL; cel = cel->prox, cont++)
    {
        soma+=cel->elemento.altura;
    }
    printf("%d\n", aproximacao(soma/cont));
}

int aproximacao(double numero){
    return (numero >= 0) ? (int)(numero + 0.5) : (int)(numero - 0.5);
}


void corrigeCommand(char *linha){
    removeQuebraDeLinha(linha);
    if(linha[0] == 'I'){
        char *linhaNova = montaSubstring(linha, 2, strlen(linha));
        if(f.size<5){
            enfileiraFila(&f, vetCompletoJogadores[atoi(linhaNova)]);
            calculaMediaAlturaFila(&f);
        }else{
            Jogador tmp = desenfilaFila(&f);
            enfileiraFila(&f, vetCompletoJogadores[atoi(linhaNova)]);
            calculaMediaAlturaFila(&f);
        }
    }else if(linha[0] == 'R'){
        //remove o primeiro jogador da fila
        Jogador removido = desenfilaFila(&f);
        printf("(R) %s\n", removido.nome);
    }
}

char* montaSubstring(char str[], int comeco, int fim) {
    int i, j;
    char *substituta; 
    if(comeco >= fim || fim > strlen(str)) {
        return NULL;
    }
    substituta = (char *) malloc(sizeof(char) * (fim - comeco + 1));    
    for(i = comeco, j = 0; i < fim; i++, j++) {
        substituta[j] = str[i];
    }
    substituta[j] = '\0';
    return substituta;
}

int main(){
    preencheVetJogComInfoArq();
    preencherFila();
    int qtdOps;
    scanf("%d", &qtdOps);
    char commandLine[tamLimiteLinha];
    scanf(" %[^\n]", commandLine);
    do{
		corrigeCommand(commandLine);
        scanf(" %[^\n]", commandLine);
	}while(--qtdOps > 0);
    printarFila(&f);
    return 0;
}