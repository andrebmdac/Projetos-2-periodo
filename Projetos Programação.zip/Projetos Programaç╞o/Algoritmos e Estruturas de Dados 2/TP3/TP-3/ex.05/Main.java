public class Main{
	public static Jogador[]vetorJogadorCheio = vetorPreenche();

	private static Jogador[] vetorPreenche(){
		Arq.openRead("/tmp/players.csv");
        Jogador vetorDeJogador[] = new Jogador[5000];
        String linha = Arq.readLine();
        linha = Arq.readLine();
        int i = 0;
        while(Arq.hasNext()){
            vetorDeJogador[i] = new Jogador(linha);
            linha = Arq.readLine();
            i++;
        }
        vetorDeJogador[i] = new Jogador(linha);
        Arq.close();
        return vetorDeJogador;
	}

    public static void main(String[]args){
		try{
			Lista listaAgora = new Lista();
			String linhaAgora = MyIO.readString();
			do{
				listaAgora.insereFim(vetorJogadorCheio[Integer.parseInt(linhaAgora)]);
				linhaAgora = MyIO.readString();
			}while(!(linhaAgora.equals("FIM")));
			
			linhaAgora = MyIO.readString();
			int qtdOps = Integer.parseInt(linhaAgora);
			do{
				linhaAgora = MyIO.readLine();
				String[]procedimentos = linhaAgora.split(" ");
				listaAgora = Lista.fazerManipulacaoLista(procedimentos, listaAgora, vetorJogadorCheio);
			}while(--qtdOps > 0);
			listaAgora.printar();
		}
		catch(Exception e){
			MyIO.println(e.getMessage());
		}
		
    }
}

class Lista{
	private Celula first;
	private Celula last;
	private int n = 0;

	public Lista(){
		first = new Celula();
		last = first;
	}

	public static Lista fazerManipulacaoLista(String[]procedimentos,Lista listaAtual, Jogador[]vetorJogadorCheio) throws Exception{
		if(procedimentos[0].equals("II"))
			listaAtual.insereInicio(vetorJogadorCheio[Integer.parseInt(procedimentos[1])]);

		else if(procedimentos[0].equals("I*"))
			listaAtual.insere(vetorJogadorCheio[Integer.parseInt(procedimentos[2])], Integer.parseInt(procedimentos[1]));

		else if(procedimentos[0].equals("IF"))
			listaAtual.insereFim(vetorJogadorCheio[Integer.parseInt(procedimentos[1])]);

		else if(procedimentos[0].equals("RI")){
			Jogador jogExcluido = listaAtual.removerInicio();
			MyIO.println("(R) "+jogExcluido.getNome());
		}

		else if(procedimentos[0].equals("R*")){
			Jogador jogExcluido = listaAtual.remover(Integer.parseInt(procedimentos[1]));
			MyIO.println("(R) "+jogExcluido.getNome());
		}

		else if(procedimentos[0].equals("RF")){
			Jogador jogExcluido = listaAtual.removeFim();
			MyIO.println("(R) "+jogExcluido.getNome());
		}

		return listaAtual;
	}

	public void insereInicio(Jogador jog){
		n++;
		Celula tmp = new Celula(jog);
		tmp.prox = first.prox;
		first.prox = tmp;
		if(first == last)
			last = tmp;
		tmp = null;
	}

	public void insereFim(Jogador jog){
		n++;
		last.prox = new Celula(jog);
		last = last.prox;
	}

	public Jogador removerInicio() throws Exception{
		if(first == last)
			throw new Exception("Erro na remocao");
		Celula tmp = first;
		first = first.prox;
		Jogador excluido = first.elemento;
		tmp.prox = null;
		tmp = null;
		n--;
		return excluido;
	}

	public Jogador removeFim() throws Exception {
		if (first == last) {
			throw new Exception("Erro na remocao");
		} 
      	Celula cel;
      	for(cel = first; cel.prox != last; cel = cel.prox);
      	Jogador resp = last.elemento; 
      	last = cel; 
		cel = last.prox = null;
		n--;
		return resp;
	}

	public void insere(Jogador x, int pos) throws Exception {
		int tam = tamanho();
		if(pos < 0 || pos > tam){
			throw new Exception("Erro ao insere posicao (" + pos + " / tamanho = " + tam + ") invalida!");
		}else if (pos == 0){
			insereInicio(x);
		}else if (pos == tam){
			insereFim(x);
		}else {
			Celula cel = first;
			for(int j = 0; j < pos; j++, cel = cel.prox);
			Celula tmp = new Celula(x);
			tmp.prox = cel.prox;
			cel.prox = tmp;
			tmp = cel = null;
		}
		n++;
	}

	public Jogador remover(int pos) throws Exception {
		Jogador jog;
		int tam = tamanho();
		if (first == last){
			throw new Exception("Erro na remocao");
  
		} else if(pos < 0 || pos >= tam){
			throw new Exception("Erro ao remover (posicao " + pos + " / " + tam + " invalida");
		} else if (pos == 0){
		   jog = removerInicio();
		} else if (pos == tam - 1){
		   jog = removeFim();
		} else {
		   Celula cel = first;
		   for(int j = 0; j < pos; j++, cel = cel.prox);
		   Celula tmp = cel.prox;
		   jog = tmp.elemento;
		   cel.prox = tmp.prox;
		   tmp.prox = null;
		   cel = tmp = null;
		}
		n--;
		return jog;
	}

	public void printar() {
		int cont = 0;
		for (Celula i = first.prox; i != null; i = i.prox, cont++) {
			MyIO.println("["+cont+"] ## "+i.elemento.getNome()+" ## "+i.elemento.getAltura()+" ## "+i.elemento.getPeso()+" ## "+i.elemento.getAnoNascimento()+" ## "+i.elemento.getUniversidade()+" ## "+i.elemento.getCidadeNascimento()+" ## "+i.elemento.getEstadoNascimento()+" ##");
		}
	}

	public int tamanho() {
		int tam = 0; 
		for(Celula i = first; i != last; i = i.prox, tam++);
		return tam;
	}

}

class Celula{
    public Jogador elemento;
    public Celula prox;

    public Celula(){
		this(null);
	}

	public Celula(Jogador elemento){
		this.elemento = elemento;
		this.prox = null;
	}
}

class Jogador {
    private int id;
	private String nome;
	private int altura;
	private int peso;
	private String universidade;
	private int anoNascimento;
	private String cidadeNascimento;
	private String estadoNascimento;

	public Jogador() {
	}

	public Jogador(String linha) {
		String infos[] = linha.split(",");
		this.id = Integer.parseInt(infos[0]);
		this.nome = infos[1];
		this.altura = Integer.parseInt(infos[2]);
		this.peso = Integer.parseInt(infos[3]);
		this.universidade = (infos[4].isEmpty()) ? "nao informado" : infos[4];
		this.anoNascimento = Integer.parseInt(infos[5]);
		if (infos.length > 6) {
			this.cidadeNascimento = (infos[6].isEmpty())? "nao informado": infos[6];
			if (infos.length < 8) {
				this.estadoNascimento = "nao informado";
			} else {
				this.estadoNascimento = infos[7];
			}
		} else {
			this.cidadeNascimento = "nao informado";
			this.estadoNascimento = "nao informado";
		}
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public void setAnoNascimento(int anoNascimento){
		this.anoNascimento = anoNascimento;
	}

	public int getAnoNascimento(){
		return anoNascimento;
	}

	public String getUniversidade() {
		return universidade;
	}

	public void setUniversidade(String universidade) {
		this.universidade = universidade;
	}

	public String getCidadeNascimento() {
		return cidadeNascimento;
	}

	public void setCidadeNascimento(String cidadeNascimento) {
		this.cidadeNascimento = cidadeNascimento;
	}

	public String getEstadoNascimento() {
		return estadoNascimento;
	}

	public void setEstadoNascimetno(String estadoNascimento) {
		this.estadoNascimento = estadoNascimento;
	}

	public Jogador clone() {
		Jogador clone = new Jogador();
		clone.id = this.id;
		clone.nome = this.nome;
		clone.altura = this.altura;
		clone.anoNascimento = this.anoNascimento;
		clone.peso = this.peso;
		clone.universidade = this.universidade;
		clone.cidadeNascimento = this.cidadeNascimento;
		clone.estadoNascimento = this.estadoNascimento;
		return clone;
	}

	public void printar() {
		System.out.println("## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + " ##");
	}

	public String toString() {
		return "[" + id + " ## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + "]";
	}
}