public class Main{
	public static Jogador[]vetorJogadorCheio = vetorPreenche();
	private static Jogador[] vetorPreenche(){
		Arq.openRead("/tmp/players.csv");
        Jogador vetorDeJogador[] = new Jogador[5000];
        String linha = Arq.readLine();
        linha = Arq.readLine();
        int i = 0;
        while(Arq.hasNext()){
            vetorDeJogador[i] = new Jogador(linha);
            linha = Arq.readLine();
            i++;
        }
        vetorDeJogador[i] = new Jogador(linha);
        Arq.close();
        return vetorDeJogador;
	}

    public static void main(String[]args){
		try{
			Pilha pilhaAgora = new Pilha();
			String linhaAgora = MyIO.readString();
			do{
				pilhaAgora.insere(vetorJogadorCheio[Integer.parseInt(linhaAgora)]);
				linhaAgora = MyIO.readString();
			}while(!(linhaAgora.equals("FIM")));
			
			linhaAgora = MyIO.readString();
			int qtdOps = Integer.parseInt(linhaAgora);
			do{
				linhaAgora = MyIO.readLine();
				String[]procedimentos = linhaAgora.split(" ");
				pilhaAgora = Pilha.fazerManipulacaoPilha(procedimentos, pilhaAgora, vetorJogadorCheio);
			}while(--qtdOps > 0);
			int x = pilhaAgora.mostraInverso(0, pilhaAgora.topCel);
			//pilhaAgora.mostra();

		}
		catch(Exception e){
			MyIO.println(e.getMessage());
		}
		
    }
}

class Pilha{
	public Celula topCel;
	public Pilha(){
		topCel = null;
	}
	public static Pilha fazerManipulacaoPilha(String[]procedimentos,Pilha pilhaAgora, Jogador[]vetorJogadorCheio) throws Exception{
		if(procedimentos[0].equals("I"))
			pilhaAgora.insere(vetorJogadorCheio[Integer.parseInt(procedimentos[1])]);
		else if(procedimentos[0].equals("R")){
			Jogador excluido = pilhaAgora.remove();
			MyIO.println("(R) "+excluido.getNome());
		}
		return pilhaAgora;
	}

	public void insere(Jogador jog){
		Celula tmp = new Celula(jog);
		tmp.prox = topCel;
		topCel = tmp;
		tmp = null;
	}

	public Jogador remove() throws Exception{
		if(topCel == null)
			throw new Exception("Erro ao remover(Vazio)!");
		Jogador excluido = topCel.infoManipulada;
		Celula tmp = topCel;
		topCel = topCel.prox;
		tmp.prox = null;
		tmp = null;
		return excluido;
	}

	public void mostra() {
		int cont = 0;
		for (Celula i = topCel; i != null; i = i.prox, cont++) {
			MyIO.println("["+cont+"] ## "+i.infoManipulada.getNome()+" ## "+i.infoManipulada.getAltura()+" ## "+i.infoManipulada.getPeso()+" ## "+i.infoManipulada.getAnoNascimento()+" ## "+i.infoManipulada.getUniversidade()+" ## "+i.infoManipulada.getCidadeNascimento()+" ## "+i.infoManipulada.getEstadoNascimento()+" ##");
		}
	}

	public int mostraInverso(int contador, Celula i){
		if(i!=null){
			contador = mostraInverso(contador, i.prox);
			MyIO.println("["+contador+"] ## "+i.infoManipulada.getNome()+" ## "+i.infoManipulada.getAltura()+" ## "+i.infoManipulada.getPeso()+" ## "+i.infoManipulada.getAnoNascimento()+" ## "+i.infoManipulada.getUniversidade()+" ## "+i.infoManipulada.getCidadeNascimento()+" ## "+i.infoManipulada.getEstadoNascimento()+" ##");
			contador++;
		}
		return contador;
	}
}

class Celula{
    public Jogador infoManipulada;
    public Celula prox;

    public Celula(){
		this(null);
	}

	public Celula(Jogador infoManipulada){
		this.infoManipulada = infoManipulada;
		this.prox = null;
	}
}

class Jogador {
    private int id;
	private String nome;
	private int altura;
	private int peso;
	private String universidade;
	private int anoNascimento;
	private String cidadeNascimento;
	private String estadoNascimento;

	public Jogador() {
	}

	public Jogador(String linha) {
		String infos[] = linha.split(",");
		this.id = Integer.parseInt(infos[0]);
		this.nome = infos[1];
		this.altura = Integer.parseInt(infos[2]);
		this.peso = Integer.parseInt(infos[3]);
		this.universidade = (infos[4].isEmpty()) ? "nao informado" : infos[4];
		this.anoNascimento = Integer.parseInt(infos[5]);
		if (infos.length > 6) {
			this.cidadeNascimento = (infos[6].isEmpty())? "nao informado": infos[6];
			if (infos.length < 8) {
				this.estadoNascimento = "nao informado";
			} else {
				this.estadoNascimento = infos[7];
			}
		} else {
			this.cidadeNascimento = "nao informado";
			this.estadoNascimento = "nao informado";
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public void setAnoNascimento(int anoNascimento){
		this.anoNascimento = anoNascimento;
	}

	public int getAnoNascimento(){
		return anoNascimento;
	}

	public String getUniversidade() {
		return universidade;
	}

	public void setUniversidade(String universidade) {
		this.universidade = universidade;
	}

	public String getCidadeNascimento() {
		return cidadeNascimento;
	}

	public void setCidadeNascimento(String cidadeNascimento) {
		this.cidadeNascimento = cidadeNascimento;
	}

	public String getEstadoNascimento() {
		return estadoNascimento;
	}

	public void setEstadoNascimetno(String estadoNascimento) {
		this.estadoNascimento = estadoNascimento;
	}

	public Jogador clone() {
		Jogador clone = new Jogador();
		clone.id = this.id;
		clone.nome = this.nome;
		clone.altura = this.altura;
		clone.anoNascimento = this.anoNascimento;
		clone.peso = this.peso;
		clone.universidade = this.universidade;
		clone.cidadeNascimento = this.cidadeNascimento;
		clone.estadoNascimento = this.estadoNascimento;
		return clone;
	}

	public void printar() {
		System.out.println("## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + " ##");
	}

	public String toString() {
		return "[" + id + " ## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + "]";
	}
}