#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define tamLimiteLinha 250
#define tamMax 5000
#define tamMaxFila 6

typedef struct {
    int id;
    int peso;
    int altura;
    char nome[70];
    char universidade[70];
    int anoNascimento;
    char cidadeNascimento[70];
    char estadoNascimento[70];
}Jogador;

Jogador clone(Jogador *jogador);
char* montaSubstring(char str[], int start, int end);
Jogador removeDaFila();
void insereFila(Jogador j);
void printaFila();
void medAltuFila();
int aproximacao(double number);

Jogador vetJogComp[tamMax];
Jogador jogadores_fila[tamMaxFila];
int first = 0, last = 0;


void insereNF(char *linha, char *NL) {
    int tam = strlen(linha);
    for (int i = 0; i <= tam; i++, linha++) {
        *NL++ = *linha;
        if (*linha == ',' && (*(linha + 1) == ',' || *(linha + 1) == '\0')) {
            strcpy(NL, "nao informado");
            NL += strlen("nao informado");
        }
    }
}

void removeQuebraLinha(char infoLinha[]) {
    int tam = strlen(infoLinha);

    if (infoLinha[tam - 2] == '\r' && infoLinha[tam - 1] == '\n')
        infoLinha[tam - 2] = '\0';

    else if (infoLinha[tam - 1] == '\r' || infoLinha[tam - 1] == '\n')
        infoLinha[tam - 1] = '\0';
}

void lerLinha(Jogador *jogador, char linha[]) {
    char novaLinha[tamLimiteLinha];
    removeQuebraLinha(linha);
    insereNF(linha, novaLinha);
    jogador->id = atoi(strtok(novaLinha, ","));
    strcpy(jogador->nome, strtok(NULL, ","));
    jogador->altura = atoi(strtok(NULL, ","));
    jogador->peso = atoi(strtok(NULL, ","));
    strcpy(jogador->universidade, strtok(NULL, ","));
    jogador->anoNascimento = atoi(strtok(NULL, ","));
    strcpy(jogador->cidadeNascimento, strtok(NULL, ","));
    strcpy(jogador->estadoNascimento, strtok(NULL, ","));
}

void printar(Jogador *jogador) {
    printf("[%d ## %s ## %d ## %d ## %d ## %s ## %s ## %s]\n",jogador->id,jogador->nome,jogador->altura,jogador->peso,jogador->anoNascimento,jogador->universidade,jogador->cidadeNascimento,jogador->estadoNascimento);
}

Jogador clone(Jogador *infoJogador) {
    Jogador clone;
    clone.id = infoJogador->id;
    strcpy(clone.nome, infoJogador->nome);
    clone.altura = infoJogador->altura;
    clone.peso = infoJogador->peso;
    clone.anoNascimento = infoJogador->anoNascimento;
    strcpy(clone.universidade, infoJogador->universidade);
    strcpy(clone.cidadeNascimento, infoJogador->cidadeNascimento);
    strcpy(clone.estadoNascimento, infoJogador->estadoNascimento);
    return clone;
}

void preencheFila(){
    char linha[tamLimiteLinha];
    scanf("%s", linha);
    do{
        insereFila(vetJogComp[atoi(linha)]);
        scanf("%s", linha);
    }while(strcmp(linha, "FIM")!=0);
}

void preencheVetJogInfoArq(){
    FILE *csv = fopen("/tmp/players.csv", "r");
    char * infos_receb[8];
    char line[tamLimiteLinha];
    int i = 0;
    fgets(line, 1024, csv);
    fgets(line, 1024, csv);
    while(!feof(csv)){
        lerLinha(&vetJogComp[i], line);
        i++;
        fgets(line, 1024, csv);
    }
    fclose(csv);
}

void insereFila(Jogador agora){
    if(((last + 1)%tamMaxFila)==first){
        Jogador tmp = removeDaFila();
        insereFila(agora);
    }
    else{
        jogadores_fila[last] = agora;
        jogadores_fila[last].id = last;
        last = (last + 1) % tamMaxFila;
        medAltuFila();
    }
}
Jogador removeDaFila(){
    if(first == last)
        exit(1);
    Jogador excluido = jogadores_fila[first];
    first = (first+1)%tamMaxFila;
    return excluido;
}

void printaFila(){
    int i = first;
    while (i != last) {
        printf("[%d] ## %s ## %d ## %d ## %d ## %s ## %s ## %s ##\n", jogadores_fila[i].id, jogadores_fila[i].nome, jogadores_fila[i].altura, jogadores_fila[i].peso, jogadores_fila[i].anoNascimento, jogadores_fila[i].universidade, jogadores_fila[i].cidadeNascimento, jogadores_fila[i].estadoNascimento);
        i = ((i + 1) % tamMaxFila);
    }
}

void medAltuFila(){
    int quantidade = 0;
    double somado = 0;
    int i = first;
    while (i != last) {
        quantidade++;
        somado += jogadores_fila[i].altura;
        i = ((i + 1) % tamMaxFila);
    }
    printf("%d\n", aproximacao(somado/quantidade));
}

int aproximacao(double result){
    return (result >= 0) ? (int)(result + 0.5) : (int)(result - 0.5);
}

void tratarLinhaComandos(char *linha){
    removeQuebraLinha(linha);
    if(linha[0] == 'I'){
        char *novaInfoLinha = montaSubstring(linha, 2, strlen(linha));
        insereFila(vetJogComp[atoi(novaInfoLinha)]);
    }else if(linha[0] == 'R'){
        Jogador excluido = removeDaFila();
        printf("(R) %s\n", excluido.nome);
    }
}


char* montaSubstring(char str[], int comeco, int fim) {
    int i, j;
    char *substituta; 
    if(comeco >= fim || fim > strlen(str)) {
        return NULL;
    }
    substituta = (char *) malloc(sizeof(char) * (fim - comeco + 1));
    for(i = comeco, j = 0; i < fim; i++, j++) {
        substituta[j] = str[i];
    }
    substituta[j] = '\0';
    return substituta;
}

int main(){
    preencheVetJogInfoArq();
    preencheFila();
    int qtdOps;
    scanf("%d", &qtdOps);
    char linhaComando[tamLimiteLinha];
    scanf(" %[^\n]", linhaComando);
    do{
		tratarLinhaComandos(linhaComando);
        scanf(" %[^\n]", linhaComando);
	}while(--qtdOps > 0);
    printaFila();
    return 0;
}