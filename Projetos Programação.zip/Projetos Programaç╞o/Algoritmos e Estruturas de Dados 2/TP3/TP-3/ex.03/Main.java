public class Main{
	public static Jogador[]vetorJogadorCheio = vetorPreenche();

	private static boolean isFim(String s){
        return (s.length() == 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }
	
	private static Jogador[] vetorPreenche(){
		Arq.openRead("/tmp/players.csv");
        Jogador vetorDeJogador[] = new Jogador[5000];
        String linha = Arq.readLine();
        linha = Arq.readLine();
        int i = 0;
        while(Arq.hasNext()){
            vetorDeJogador[i] = new Jogador(linha);
            linha = Arq.readLine();
            i++;
        }
        vetorDeJogador[i] = new Jogador(linha);
        Arq.close();
        return vetorDeJogador;
	}


    public static void main(String[]args){
		Pilha pilha = new Pilha();
		String funcionalidade = MyIO.readString();
        int i = 0;
        do{
			pilha.jogadores[Pilha.n] = vetorJogadorCheio[Integer.parseInt(funcionalidade)];
			pilha.jogadores[Pilha.n].setId(Pilha.n++);
            funcionalidade = MyIO.readString();
            i++;
		}while(isFim(funcionalidade) == false);
		
		funcionalidade = MyIO.readLine();
		int qtdfuncionalidade = Integer.parseInt(funcionalidade);
		/*
		do{
			MyIO.println(qtdfuncionalidade);
		}while(--qtdfuncionalidade > 0);
		*/
		pilha.printar();
	}
}

class Pilha{
	public final static int tamT = 5000;
	public static Jogador[]jogadores = new Jogador[tamT];
	public static int n = 0;
	public static Pilha fazerManipulacaoLista(String[]procedimentos,Pilha pilha, Jogador[]vetorJogadorCheio){
		if(procedimentos[0].equals("I"))
			pilha.insereFim(vetorJogadorCheio[Integer.parseInt(procedimentos[1])]);
		else if(procedimentos[0].equals("R")){
			Jogador excluido = pilha.removeFim();
			MyIO.println("(R) "+excluido.getNome());
		}
		return pilha;
	}
	public void insereFim(Jogador jogador){
		if(n >= jogadores.length)
            MyIO.println("Erro!");
        else{
			jogadores[n] = jogador;
			jogadores[n].setId(n);
            n++;
        }
	}
	public Jogador removeFim(){
		if(n == 0)
			MyIO.println("Error!");
        return jogadores[--n];
	}
	public void printar(){
		for(int i = 0; i < this.n; i++)
			MyIO.println("["+jogadores[i].getId()+"] ## "+jogadores[i].getNome()+" ## "+jogadores[i].getAltura()+" ## "+jogadores[i].getPeso()+" ## "+jogadores[i].getAnoNascimento()+" ## "+jogadores[i].getUniversidade()+" ## "+jogadores[i].getCidadeNascimento()+" ## "+jogadores[i].getEstadoNascimento()+" ##");
	}
}

class Lista{
	public final static int tamT = 5000;
	public static Jogador[]jogadores = new Jogador[tamT];
	public static int n = 0;
	public static Lista fazerProcedimentosLista(String[]procedimentos,Lista lista, Jogador[]vetorJogadorCheio){
		if(procedimentos[0].equals("II"))
			lista.insereInicio(vetorJogadorCheio[Integer.parseInt(procedimentos[1])]);

		else if(procedimentos[0].equals("I*"))
			lista.inserir(vetorJogadorCheio[Integer.parseInt(procedimentos[2])], Integer.parseInt(procedimentos[1]));

		else if(procedimentos[0].equals("IF"))
			lista.insereFim(vetorJogadorCheio[Integer.parseInt(procedimentos[1])]);

		else if(procedimentos[0].equals("RI")){
			Jogador jogExcluido = lista.removeInicio();
			MyIO.println("(R) "+jogExcluido.getNome());
		}
		else if(procedimentos[0].equals("R*")){
			Jogador jogExcluido = lista.remover(Integer.parseInt(procedimentos[1]));
			MyIO.println("(R) "+jogExcluido.getNome());
		}
		else if(procedimentos[0].equals("RF")){
			Jogador jogExcluido = lista.removeFim();
			MyIO.println("(R) "+jogExcluido.getNome());
		}
		return lista;
	}

	public void insereInicio(Jogador jogador){
        if(n < jogadores.length){
            for(int i = n; i > 0; i--){
				jogadores[i] = jogadores[i-1];
				jogadores[i].setId(jogadores[i].getId()+1);
			}
			jogadores[0] = jogador;
			jogadores[0].setId(0);
            n++;
        }else MyIO.println("Erro!");
    }

    public void inserir(Jogador jogador, int pos){
        if(n >= jogadores.length || pos < 0 || pos > n)
            MyIO.println("Erro!");
        else{
            for(int i = n; i > pos; i--){
				jogadores[i] = jogadores[i-1];
				jogadores[i].setId(jogadores[i].getId()+1);
			}
			jogadores[pos] = jogador;
			jogadores[pos].setId(pos);
            n++;
        }
    }

    public void insereFim(Jogador jogador){
        if(n >= jogadores.length)
            MyIO.println("Erro!");
        else{
			jogadores[n] = jogador;
			jogadores[n].setId(n);
            n++;
        }
    }

    public Jogador removeInicio(){
        if(n == 0)
            MyIO.println("Error!");
        
        Jogador excluido = jogadores[0];
        n--;
        for(int i = 0; i < n; i++){
			jogadores[i] = jogadores[i+1];
			jogadores[i].setId(jogadores[i].getId()-1);
		}
        return excluido;
    }

    public Jogador remover(int posicao){
        if(n == 0 || posicao < 0 || posicao >= n)
			MyIO.println("Error!");
        
        Jogador excluido = jogadores[posicao];
        n--;
        for(int i = posicao; i < n; i++){
			jogadores[i] = jogadores[i+1];
			jogadores[i].setId(jogadores[i].getId()-1);
		}
        return excluido;
    }

    public Jogador removeFim(){
        if(n == 0)
		{
			MyIO.println("Error!");
	    }
        return jogadores[--n];
	}
	
	public void printar(){
		for(int i = 0; i < this.n; i++)
			MyIO.println("["+jogadores[i].getId()+"] ## "+jogadores[i].getNome()+" ## "+jogadores[i].getAltura()+" ## "+jogadores[i].getPeso()+" ## "+jogadores[i].getAnoNascimento()+" ## "+jogadores[i].getUniversidade()+" ## "+jogadores[i].getCidadeNascimento()+" ## "+jogadores[i].getEstadoNascimento()+" ##");
	}
}

class Jogador {
    private int id;
	private String nome;
	private int altura;
	private int peso;
	private String universidade;
	private int anoNascimento;
	private String cidadeNascimento;
	private String estadoNascimento;

	public Jogador() {
	}

	public Jogador(String linha) {
		String infos[] = linha.split(",");
		this.id = Integer.parseInt(infos[0]);
		this.nome = infos[1];
		this.altura = Integer.parseInt(infos[2]);
		this.peso = Integer.parseInt(infos[3]);
		this.universidade = (infos[4].isEmpty()) ? "nao informado" : infos[4];
		this.anoNascimento = Integer.parseInt(infos[5]);
		if (infos.length > 6) {
			this.cidadeNascimento = (infos[6].isEmpty())? "nao informado": infos[6];
			if (infos.length < 8) {
				this.estadoNascimento = "nao informado";
			} else {
				this.estadoNascimento = infos[7];
			}
		} else {
			this.cidadeNascimento = "nao informado";
			this.estadoNascimento = "nao informado";
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public void setAnoNascimento(int anoNascimento){
		this.anoNascimento = anoNascimento;
	}

	public int getAnoNascimento(){
		return anoNascimento;
	}

	public String getUniversidade() {
		return universidade;
	}

	public void setUniversidade(String universidade) {
		this.universidade = universidade;
	}

	public String getCidadeNascimento() {
		return cidadeNascimento;
	}

	public void setCidadeNascimento(String cidadeNascimento) {
		this.cidadeNascimento = cidadeNascimento;
	}

	public String getEstadoNascimento() {
		return estadoNascimento;
	}

	public void setEstadoNascimetno(String estadoNascimento) {
		this.estadoNascimento = estadoNascimento;
	}

	public Jogador clone() {
		Jogador clone = new Jogador();
		clone.id = this.id;
		clone.nome = this.nome;
		clone.altura = this.altura;
		clone.anoNascimento = this.anoNascimento;
		clone.peso = this.peso;
		clone.universidade = this.universidade;
		clone.cidadeNascimento = this.cidadeNascimento;
		clone.estadoNascimento = this.estadoNascimento;
		return clone;
	}

	public void printar() {
		System.out.println("## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + " ##");
	}

	public String toString() {
		return "[" + id + " ## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + "]";
	}
}