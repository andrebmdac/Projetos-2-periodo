class Main{
    public static void main(String[] args){
		int qtdVezes = MyIO.readInt();
		do{
			int linhas = MyIO.readInt();
			int colunas = MyIO.readInt();
			int vetor[] = new int[linhas*colunas];
			Matriz matriz1 = new Matriz(linhas, colunas);
			for(int i = 0; i < linhas*colunas; i++)
				vetor[i] = MyIO.readInt();

			linhas = MyIO.readInt();
			colunas = MyIO.readInt();
			int vetor2[] = new int[linhas*colunas];
			Matriz matriz2 = new Matriz(linhas, colunas);
			for(int i = 0; i < linhas*colunas; i++)
				vetor2[i] = MyIO.readInt();
			matriz1.preencher(vetor); matriz2.preencher(vetor2);
			matriz1.printarDiagonalPrincipal();
			matriz1.printarDiagonalSecundaria();
			Matriz somaMatrizes = Matriz.soma(matriz1, matriz2);
			somaMatrizes.printarMatriz();
			Matriz prodMatrizes = Matriz.multiplicacao(matriz1, matriz2);
			prodMatrizes.printarMatriz();
		}while(--qtdVezes > 0);
    }
}

class Matriz{
    private Celula start;
    public int linha, coluna;

    public Matriz (){
        this.start = null;
    }

    public Matriz (int linha, int coluna){
        this.linha = linha;
        this.coluna = coluna;
		this.start = new Celula();
		Celula tmp = start;

		for(int j = 1; j < coluna; j++){
			tmp.prox = new Celula();
			tmp.prox.ant = tmp;
			tmp = tmp.prox;
		}
		tmp = start;
		for(int i = 0; i < linha-1; i++){
			Celula tmp2 = tmp;
			for(int j = 0; j < coluna; j++){
				if(j == 0){
					tmp2.inf = new Celula();
					tmp2.inf.sup = tmp2;
					tmp2 = tmp2.prox;
				}else if(j != coluna-1 && j > 0){
					tmp2.inf = new Celula();
					tmp2.inf.sup = tmp2;
					tmp2.inf.ant = tmp2.ant.inf;
					tmp2.ant.inf.prox = tmp2.inf;
					tmp2 = tmp2.prox;
				}else{
					tmp2.inf = new Celula();
					tmp2.inf.sup = tmp2;
					tmp2.inf.ant = tmp2.ant.inf;
					tmp2.ant.inf.prox = tmp2.inf;
				}
			}
			tmp2 = tmp.inf;
			tmp = tmp.inf;
		}
	}
	
	public static Matriz soma(Matriz matriz1, Matriz matriz2) {
        Matriz mat = null;
        if(matriz1.linha == matriz2.linha && matriz1.coluna == matriz2.coluna){
			mat = new Matriz(matriz1.linha, matriz1.coluna);
            int vet[] = matriz1.vetorEmMatriz();
			int vet2[] = matriz2.vetorEmMatriz();
			int[]result = new int[vet.length];
			for(int i = 0; i < vet.length; i++)
				result[i] = vet[i] + vet2[i];
			mat.preencher(result);
        }
        return mat;
	}

	public static Matriz multiplicacao (Matriz matriz1, Matriz matriz2) {
        Matriz mat = null;
        if(matriz1.coluna == matriz2.linha){
			mat = new Matriz(matriz1.linha, matriz2.coluna);
			int[][]matr1=matriz1.pegaValMEmM();
			int[][]matr2=matriz2.pegaValMEmM();
			int[][]matr3=new int[matriz1.linha][matriz2.coluna];
			for(int i = 0; i < matr1.length; i++)
				for(int j = 0; j < matr2[0].length; j++){
					int soma = 0;
					for (int k = 0; k < matr1[0].length; k++) {
						int multiplicacao = matr1[i][k] * matr2[k][j];
						soma += multiplicacao;
					}
					matr3[i][j] =soma;
				}
			int[]vetorResultante = new int[matr1.length*matr2[0].length];
			for(int i = 0, k = 0; i < matr1.length; i++)
				for(int j = 0; j < matr2[0].length; j++, k++)
					vetorResultante[k] = matr3[i][j];
			mat.preencher(vetorResultante);
        }

        return mat;
    }
	
	public void preencher(int[]vet){
		Celula tmp = start;
		for(int i = 0, k = 0; i < this.linha; i++){
			Celula tmp2 = tmp;
			for(int j = 0; j < this.coluna; j++, k++){
				tmp2.elemento = vet[k];
				tmp2 = tmp2.prox;
			}
			tmp2 = tmp.inf;
			tmp = tmp.inf;
		}
	}

	public void printarDiagonalPrincipal (){
        if(matrizQuadrada() == true){
			Celula tmp = start;
			for(int i = 0, k = 0; i < this.linha; i++){
				Celula tmp2 = tmp;
				for(int j = 0; j < this.coluna; j++, k++){
					if(i == j)
						MyIO.print(tmp2.elemento+" ");
					tmp2 = tmp2.prox;
				}
				tmp2 = tmp.inf;
				tmp = tmp.inf;
			}
			MyIO.print("\n");
        }else MyIO.println("A matriz não é quadrada");
	}

	public int[] vetorEmMatriz(){
		int[]vetor = new int[this.linha*this.coluna];
		Celula tmp = start;
		for(int i = 0, k = 0; i < this.linha; i++){
			Celula tmp2 = tmp;
			for(int j = 0; j < this.coluna; j++, k++){
				vetor[k] = tmp2.elemento;
				tmp2 = tmp2.prox;
			}
			tmp2 = tmp.inf;
			tmp = tmp.inf;
		}
		return vetor;
	}

	public int[][] pegaValMEmM(){
		int[][]vetor = new int[this.linha][this.coluna];
		Celula tmp = start;
		for(int i = 0, k = 0; i < this.linha; i++, k++){
			Celula tmp2 = tmp;
			for(int j = 0, z = 0; j < this.coluna; j++, z++){
				vetor[k][z] = tmp2.elemento;
				tmp2 = tmp2.prox;
			}
			tmp2 = tmp.inf;
			tmp = tmp.inf;
		}
		return vetor;
	}

	public void printarMatriz(){
		Celula tmp = start;
		for(int i = 0; i < this.linha; i++){
			Celula tmp2 = tmp;
			for(int j = 0; j < this.coluna; j++){
				MyIO.print(tmp2.elemento+" ");
				tmp2 = tmp2.prox;
			}
			MyIO.print("\n");
			tmp2 = tmp.inf;
			tmp = tmp.inf;
		}
	}

	public void printarDiagonalSecundaria (){
        if(matrizQuadrada() == true){
			Celula tmp = start;
			for(int i = 0, k = 0; i < this.linha; i++){
				Celula tmp2 = tmp;
				for(int j = 0; j < this.coluna; j++, k++){
					if(i == this.coluna - 1 - j)
						MyIO.print(tmp2.elemento+" ");
					tmp2 = tmp2.prox;
				}
				tmp2 = tmp.inf;
				tmp = tmp.inf;
			}
			MyIO.print("\n");
        }else MyIO.println("A matriz não é quadrada");
    }
	
	public boolean matrizQuadrada(){
        return (this.linha == this.coluna);
	}
	
}

class Celula{
    public int elemento;
    public Celula inf, sup, ant, prox;

    public Celula(){
        this(0, null, null, null, null);
    }

    public Celula(int elemento){
        this(elemento, null, null, null, null);
    }

    public Celula(int elemento, Celula inf, Celula sup, Celula ant, Celula prox){
        this.elemento = elemento;
        this.inf = inf;
        this.sup = sup;
        this.ant = ant;
        this.prox = prox;
    }
}
