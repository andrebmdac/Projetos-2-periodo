#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define tamLimiteLinha 250
#define tamMax 5000

typedef struct {
    int id;
    int peso;
    int altura;
    char nome[70];
    char universidade[70];
    int anoNascimento;
    char cidadeNascimento[70];
    char estadoNascimento[70];
}Jogador;

Jogador clone(Jogador *jogador);
int preencherLista();
void inserirInicio(Jogador j);
void insere(Jogador j, int pos);
void inserirFim(Jogador j);
Jogador removerInicio();
Jogador remover(int pos);
Jogador removerFim();
char* montaSubstring(char str[], int start, int end);


Jogador vetorJogadoresComp[tamMax];
Jogador jogadores_lista[tamMax];
int n = 0;


void insereNF(char *linha, char *novaLinha) {
    int tam = strlen(linha);
    for (int i = 0; i <= tam; i++, linha++) {
        *novaLinha++ = *linha;
        if (*linha == ',' && (*(linha + 1) == ',' || *(linha + 1) == '\0')) 
        {
            strcpy(novaLinha, "nao informado");
            novaLinha += strlen("nao informado");
        }
    }
}

void removeQuebraLinha(char infoLinha[]) {
    int tam = strlen(infoLinha);

    if (infoLinha[tam - 2] == '\r' && infoLinha[tam - 1] == '\n') 
        infoLinha[tam - 2] = '\0';

    else if (infoLinha[tam - 1] == '\r' || infoLinha[tam - 1] == '\n') 
        infoLinha[tam - 1] = '\0'; 
}

void ler(Jogador *jogador, char linha[]) {
    char novaLinha[tamLimiteLinha];
    removeQuebraLinha(linha);
    insereNF(linha, novaLinha);
    jogador->id = atoi(strtok(novaLinha, ","));
    strcpy(jogador->nome, strtok(NULL, ","));
    jogador->altura = atoi(strtok(NULL, ","));
    jogador->peso = atoi(strtok(NULL, ","));
    strcpy(jogador->universidade, strtok(NULL, ","));
    jogador->anoNascimento = atoi(strtok(NULL, ","));
    strcpy(jogador->cidadeNascimento, strtok(NULL, ","));
    strcpy(jogador->estadoNascimento, strtok(NULL, ","));
}

void printar(Jogador *jogador) {
    printf("[%d ## %s ## %d ## %d ## %d ## %s ## %s ## %s]\n",jogador->id,jogador->nome,jogador->altura,jogador->peso,jogador->anoNascimento,jogador->universidade,jogador->cidadeNascimento,jogador->estadoNascimento);
}


void printarListaCompleta(){
    for(int i = 0; i < n; i++)
			printf("[%d] ## %s ## %d ## %d ## %d ## %s ## %s ## %s ##\n", jogadores_lista[i].id, jogadores_lista[i].nome, jogadores_lista[i].altura, jogadores_lista[i].peso, jogadores_lista[i].anoNascimento, jogadores_lista[i].universidade, jogadores_lista[i].cidadeNascimento, jogadores_lista[i].estadoNascimento);
}

Jogador clone(Jogador *jogador) {
    Jogador clone;
    clone.id = jogador->id;
    strcpy(clone.nome, jogador->nome);
    clone.altura = jogador->altura;
    clone.peso = jogador->peso;
    clone.anoNascimento = jogador->anoNascimento;
    strcpy(clone.universidade, jogador->universidade);
    strcpy(clone.cidadeNascimento, jogador->cidadeNascimento);
    strcpy(clone.estadoNascimento, jogador->estadoNascimento);

    return clone;
}


void preencheVetJogInfoArq(){
    FILE *csv = fopen("/tmp/players.csv", "r");
    //char * infos_receb[8];
    char linhaAux[tamLimiteLinha];
    int i = 0;
    fgets(linhaAux, 1024, csv);
    fgets(linhaAux, 1024, csv);
    while(!feof(csv)){
        ler(&vetorJogadoresComp[i], linhaAux);
        i++;
        fgets(linhaAux, 1024, csv);
    }
    fclose(csv);
}

int preencherLista(){
    int n = 0;
    char linha[tamLimiteLinha];
    scanf("%s", linha);
    do{
        jogadores_lista[n] = clone(&vetorJogadoresComp[atoi(linha)]);
        jogadores_lista[n].id = n;
        n++;
        scanf("%s", linha);
    }while(strcmp(linha, "FIM")!=0);
    return n;
}


void inserirInicio(Jogador j){
    if(n >= tamMax)
    {
        exit(1);
    }
    for(int i = n; i > 0; i--){
        jogadores_lista[i] = jogadores_lista[i-1];
        jogadores_lista[i].id = jogadores_lista[i].id+1;
    }
    jogadores_lista[0] = clone(&j);
    jogadores_lista[0].id = 0;
    n++;
}

void insere(Jogador j, int lugar){
    if (n >= tamMax || lugar < 0 || lugar > n)
    {
        exit(1);
    }
    for (int i = n; i > lugar; i--){
        jogadores_lista[i] = jogadores_lista[i-1];
        jogadores_lista[i].id = jogadores_lista[i].id+1;
    }
    jogadores_lista[lugar] = clone(&j);
    jogadores_lista[lugar].id = lugar;
    n++;
}

void inserirFim(Jogador j){
    if (n >= tamMax)
    {
        exit(1);
    }
    jogadores_lista[n] = clone(&j);
    jogadores_lista[n].id = n;
    n++;
}

Jogador removerInicio(){
    if (n == 0)
        exit(1);
    Jogador correto = jogadores_lista[0];
    n--;
    for (int i = 0; i < n; i++){
        jogadores_lista[i] = jogadores_lista[i+1];
        jogadores_lista[i].id = i;
    }
    return correto;
}

Jogador remover(int pos){
    if (n == 0 || pos < 0 || pos >= n)
        exit(1);
    Jogador correto = jogadores_lista[pos];
    n--;
    for (int i = pos; i < n; i++){
        jogadores_lista[i] = jogadores_lista[i+1];
        jogadores_lista[i].id = i;
    }
    return correto;
}

Jogador removerFim(){
    if (n == 0)
    {
        exit(1);
    }
    return jogadores_lista[--n];
}

void corrigirCommand(char *linha){
    removeQuebraLinha(linha);
    if(linha[0] == 'I' && linha[1] == 'I'){
        char *linhaNova = montaSubstring(linha, 3, strlen(linha));
        inserirInicio(vetorJogadoresComp[atoi(linhaNova)]);

    }else if(linha[0] == 'I' && linha[1] == 'F'){
        char *linhaNova = montaSubstring(linha, 3, strlen(linha));
        inserirFim(vetorJogadoresComp[atoi(linhaNova)]);

    }else if(linha[0] == 'I' && linha[1] == '*'){
        char *linhaNova = montaSubstring(linha, 3, strlen(linha));
        int posEsp = 0;
        for(int i = 0; i < strlen(linhaNova); i++)
            if(linhaNova[i] == ' ')
                posEsp = i;
        char *lCommand1 = montaSubstring(linhaNova, 0, posEsp);
        char *lCommand2 = montaSubstring(linhaNova, posEsp+1, strlen(linhaNova));
        insere(vetorJogadoresComp[atoi(lCommand2)], atoi(lCommand1));

    }else if(linha[0] == 'R' && linha[1] == '*'){
        char *newLine = montaSubstring(linha, 3, strlen(linha));
        Jogador retirado = remover(atoi(newLine));
        printf("(R) %s\n", retirado.nome);

    }else if(linha[0] == 'R' && linha[1] == 'I'){
        Jogador retirado = removerInicio();
        printf("(R) %s\n", retirado.nome);

    }else if(linha[0] == 'R' && linha[1] == 'F'){
        Jogador retirado = removerFim();
        printf("(R) %s\n", retirado.nome);
    }
}


char* montaSubstring(char str[], int comeco, int fim) {
    int i, j;
    char *substituta; 
    if(comeco >= fim || fim > strlen(str)) {
        return NULL;
    }
    substituta = (char *) malloc(sizeof(char) * (fim - comeco + 1));    
    for(i = comeco, j = 0; i < fim; i++, j++) {
        substituta[j] = str[i];
    }
    substituta[j] = '\0';
    return substituta;
}

int main(){
    preencheVetJogInfoArq();
    n = preencherLista();
    int qtdOps;
    scanf("%d", &qtdOps);
    char linhaComando[tamLimiteLinha];
    scanf(" %[^\n]", linhaComando);
    do{
		corrigirCommand(linhaComando);
        scanf(" %[^\n]", linhaComando);
	}while(--qtdOps > 0);
    printarListaCompleta();
    return 0;
}