#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <string.h>

#define TAM_MAX_LINHA 250
#define MAX_TAM 5000

typedef struct {
    int id;
    int peso;
    int altura;
    char nome[70];
    char universidade[70];
    int anoNascimento;
    char cidadeNascimento[70];
    char estadoNascimento[70];
} Jogador;

//CELULA=============================================================================
typedef struct CelulaDupla {
	Jogador elemento;        // Elemento inserido na celula.
    struct CelulaDupla* prox; // Aponta a celula prox.
    struct CelulaDupla* ant;  // Aponta a celula anterior.
} CelulaDupla;

CelulaDupla* novaCelulaDupla(Jogador elemento) {
   CelulaDupla* nova = (CelulaDupla*) malloc(sizeof(CelulaDupla));
   nova->elemento = elemento;
   nova->ant = nova->prox = NULL;
   return nova;
}

//LISTA PROPRIAMENTE DITA=============================================================================
CelulaDupla* primeiro;
CelulaDupla* ultimo;
int n = 0;

void quickSortPorEstado(int esq, int dir, CelulaDupla *tmp1, CelulaDupla *tmp2);
void swap(int i, int j);
CelulaDupla* elementoNaPosicao(int pos);
int preencher();

void startListaDupla () {
    Jogador j;
    primeiro = novaCelulaDupla(j);
    ultimo = primeiro;
}

//FUNÇÕES DA LISTA=============================================================================
void inserirFim(Jogador x) {
   ultimo->prox = novaCelulaDupla(x);
   ultimo->prox->ant = ultimo;
   ultimo = ultimo->prox;
}

void mostrar() {
   CelulaDupla* i;
   for (i = primeiro->prox; i != NULL; i = i->prox) {
      printf("[%d ## %s ## %d ## %d ## %d ## %s ## %s ## %s]\n",
         i->elemento.id,
         i->elemento.nome,
         i->elemento.altura,
         i->elemento.peso,
         i->elemento.anoNascimento,
         i->elemento.universidade,
         i->elemento.cidadeNascimento,
         i->elemento.estadoNascimento);
   }
}

void quickSortPorEstado(int esq, int dir, CelulaDupla *tmp1, CelulaDupla *tmp2){
    int i = esq, j = dir;
    CelulaDupla *iCelula = tmp1, *jCelula = tmp2; 
    printf("iCelula->%s\n", iCelula->elemento.nome);
    printf("jCelula->%s\n", jCelula->elemento.nome);
    CelulaDupla *pivo = elementoNaPosicao((dir+esq)/2);

    char pivo2[100]; strcpy(pivo2, pivo->elemento.nome);
    printf("pivo->%s\n", pivo2);

    
    while(i <= j){
        while(strcmp(iCelula->elemento.nome, pivo2) < 0 && i < dir){
            iCelula = iCelula->prox;
            i++;
        }
        while(strcmp(jCelula->elemento.nome, pivo2) > 0 && j > esq){
            jCelula = jCelula->ant;
            j--;
        }
        // printf("%s\n", iCelula->elemento.nome);
        // printf("%s\n", jCelula->elemento.nome);
        // printf("\n\n");
        if(i <= j){
			swap(i, j);
			i++;j--;
			iCelula = iCelula->prox;
            jCelula = jCelula->ant;
		}
        // if (j > esq)
		//  	quickSortPorEstado(esq, j, tmp1, jCelula);
		// if (i < dir)
		// 	quickSortPorEstado(i, dir, iCelula, tmp2);
    }
}

void swap(int i, int j){
    Jogador aux = elementoNaPosicao(i)->elemento;
	elementoNaPosicao(i)->elemento = elementoNaPosicao(j)->elemento;
	elementoNaPosicao(j)->elemento = aux;
}

CelulaDupla* elementoNaPosicao(int pos){
    CelulaDupla *i = primeiro->prox;
    for(int j = 0; j < pos; j++, i = i->prox);

    return i;
}

//=============================================================================



//=============================================================================



//=============================================================================


Jogador vetCompletoJogadores[MAX_TAM];

//FUNÇÕES INICIAIS NECESSÁRIAS DO PROGRAMA
void inserirNaoInformado(char *linha, char *novaLinha) {
    int tam = strlen(linha);
    for (int i = 0; i <= tam; i++, linha++) {
        *novaLinha++ = *linha;
        if (*linha == ',' && (*(linha + 1) == ',' || *(linha + 1) == '\0')) {
            strcpy(novaLinha, "nao informado");
            novaLinha += strlen("nao informado");
        }
    }
}

void tirarQuebraDeLinha(char linha[]) {
    int tam = strlen(linha);

    if (linha[tam - 2] == '\r' && linha[tam - 1] == '\n') // Linha do Windows
        linha[tam - 2] = '\0'; // Apaga a linha

    else if (linha[tam - 1] == '\r' || linha[tam - 1] == '\n') // Mac ou Linux
        linha[tam - 1] = '\0'; // Apaga a linha
}

void ler(Jogador *jogador, char linha[]) {
    char novaLinha[TAM_MAX_LINHA];
    tirarQuebraDeLinha(linha);
    inserirNaoInformado(linha, novaLinha);

    jogador->id = atoi(strtok(novaLinha, ","));
    strcpy(jogador->nome, strtok(NULL, ","));
    jogador->altura = atoi(strtok(NULL, ","));
    jogador->peso = atoi(strtok(NULL, ","));
    strcpy(jogador->universidade, strtok(NULL, ","));
    jogador->anoNascimento = atoi(strtok(NULL, ","));
    strcpy(jogador->cidadeNascimento, strtok(NULL, ","));
    strcpy(jogador->estadoNascimento, strtok(NULL, ","));
}

void preencherListaDuplamenteEncadeada(){
    char linha[TAM_MAX_LINHA];
    startListaDupla();
    scanf("%s", linha);
    do{
        inserirFim(vetCompletoJogadores[atoi(linha)]);
        scanf("%s", linha);
        n++;
    }while(strcmp(linha, "FIM")!=0);
}

//preenche vetor inteiro de jogadores
void preencherVetorDeJogadoresArquivo(){
    FILE *csv = fopen("players.csv", "r");
   
    char * infos_receb[8];
    char line[TAM_MAX_LINHA];
    int i = 0;
    fgets(line, 1024, csv);
    fgets(line, 1024, csv);

    while(!feof(csv)){
        ler(&vetCompletoJogadores[i], line);
        i++;
        fgets(line, 1024, csv);
    }
    fclose(csv);
}

int preencher(){
    int i = 0;
    for(i = 1; i < 20; i++)
        inserirFim(vetCompletoJogadores[i]);
    return i;
}

int main(){
    preencherVetorDeJogadoresArquivo();
    preencherListaDuplamenteEncadeada();
    quickSortPorEstado(0, n-1, primeiro->prox, ultimo);
    mostrar();
    return 0;
}