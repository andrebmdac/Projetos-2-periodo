public class Main{
	public static Jogador[]vetCompletoJogador = PreencherComArquivo();

	private static Jogador[] PreencherComArquivo(){
		Arq.openRead("/tmp/players.csv");
        Jogador vet[] = new Jogador[5000];
        String linha = Arq.readLine();
        linha = Arq.readLine();
        int i = 0;
        while(Arq.hasNext()){
            vet[i] = new Jogador(linha);
            linha = Arq.readLine();
            i++;
        }
        vet[i] = new Jogador(linha);
        Arq.close();
        return vet;
	}

    public static void main(String[]args){
		
    	ListaDupla ld = new ListaDupla();
        String entrada = MyIO.readString();
        int i = 0;
        do{
            ld.insereFim(vetCompletoJogador[Integer.parseInt(entrada)]);
            entrada = MyIO.readString();
		}while(!(entrada.equals("FIM")));
		ld.orgListQS(0, ld.index-1);
		ld.desempatarNome();
		ld.mostra();
	}
}

class CelulaDupla {
	public Jogador elemento;
	public int index;
	public CelulaDupla ant;
    public CelulaDupla prox;

	
	public CelulaDupla() {
		this.elemento = null;
		this.index = -1;
		this.ant = this.prox = null;
	}


	
	public CelulaDupla(Jogador elemento, int index) {
		this.index = index;
		this.elemento = elemento;
        this.ant = this.prox = null;
	}
}

class Jogador {
    private int id;
	private String nome;
	private int altura;
	private int peso;
	private String universidade;
	private int anoNascimento;
	private String cidadeNascimento;
	private String estadoNascimento;

	public Jogador() {
	}

	public Jogador(String linha) {
		String infos[] = linha.split(",");
		this.id = Integer.parseInt(infos[0]);
		this.nome = infos[1];
		this.altura = Integer.parseInt(infos[2]);
		this.peso = Integer.parseInt(infos[3]);
		this.universidade = (infos[4].isEmpty()) ? "nao informado" : infos[4];
		this.anoNascimento = Integer.parseInt(infos[5]);
		if (infos.length > 6) {
			this.cidadeNascimento = (infos[6].isEmpty())? "nao informado": infos[6];
			if (infos.length < 8) {
				this.estadoNascimento = "nao informado";
			} else {
				this.estadoNascimento = infos[7];
			}
		} else {
			this.cidadeNascimento = "nao informado";
			this.estadoNascimento = "nao informado";
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public void setAnoNascimento(int anoNascimento){
		this.anoNascimento = anoNascimento;
	}

	public int getAnoNascimento(){
		return anoNascimento;
	}

	public String getUniversidade() {
		return universidade;
	}

	public void setUniversidade(String universidade) {
		this.universidade = universidade;
	}

	public String getCidadeNascimento() {
		return cidadeNascimento;
	}

	public void setCidadeNascimento(String cidadeNascimento) {
		this.cidadeNascimento = cidadeNascimento;
	}

	public String getEstadoNascimento() {
		return estadoNascimento;
	}

	public void setEstadoNascimetno(String estadoNascimento) {
		this.estadoNascimento = estadoNascimento;
	}

	public Jogador clone() {
		Jogador clone = new Jogador();
		clone.id = this.id;
		clone.nome = this.nome;
		clone.altura = this.altura;
		clone.anoNascimento = this.anoNascimento;
		clone.peso = this.peso;
		clone.universidade = this.universidade;
		clone.cidadeNascimento = this.cidadeNascimento;
		clone.estadoNascimento = this.estadoNascimento;
		return clone;
	}

	public void imprimir() {
		System.out.println("## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + " ##");
	}

	public String toString() {
		return "[" + id + " ## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + "]";
	}
}

class ListaDupla {
	private CelulaDupla first;
    private CelulaDupla last;
    public int index;
	public ListaDupla() {
		first = new CelulaDupla();
		last = first;
	}
	public void orgListQS(int esq, int dir){
		orgListQS(esq, dir, first.prox, last);
	}
	private void orgListQS(int esq, int dir, CelulaDupla tmp1, CelulaDupla tmp2){
		int i = esq, j = dir;
		CelulaDupla celAux1 = tmp1, celAux2 = tmp2;
		CelulaDupla base = first.prox;
		for(int k = 0; k < (dir+esq)/2 && base.prox != null; base = base.prox, k++);
		String base2 = base.elemento.getEstadoNascimento();
		while(i <= j){
			while(celAux1.elemento.getEstadoNascimento().compareTo(base2) < 0 && i < dir) {
				celAux1 = celAux1.prox;
                i++;
			}
			while(celAux2.elemento.getEstadoNascimento().compareTo(base2) > 0 && j > esq) {
				celAux2 = celAux2.ant;
                j--;
			}
			if(i <= j){
				swap(i, j);
				i++;
				j--;
				celAux1 = celAux1.prox;
                celAux2 = celAux2.ant;
			}
		}
		if (j > esq)
		 	orgListQS(esq, j, tmp1, celAux2);
		if (i < dir)
			orgListQS(i, dir, celAux1, tmp2);
	}

	public void desempatarNome(){
		for(CelulaDupla cel = first.prox.prox; cel != null; cel = cel.prox){
			Jogador tmp = cel.elemento;
			CelulaDupla j = cel.ant;
			while((j != first) && (j.elemento.getEstadoNascimento().compareTo(tmp.getEstadoNascimento()) == 0 && j.elemento.getNome().compareTo(tmp.getNome()) > 0)){
				j.prox.elemento = j.elemento;
				j = j.ant;
			}
			j.prox.elemento = tmp;
		}
	}
	
	public CelulaDupla pegaPosComElemento(int posicao){
        CelulaDupla info;
        CelulaDupla cel = first.prox;
        for(int j = 0; j < posicao; j++, cel = cel.prox);
        info = cel;
        return info;
    }
	
	public void swap(int i, int j){
		Jogador aux = pegaPosComElemento(i).elemento;
		pegaPosComElemento(i).elemento = pegaPosComElemento(j).elemento;
		pegaPosComElemento(j).elemento = aux;
	}

	public void insereFim(Jogador jog) {
		last.prox = new CelulaDupla(jog, index++);
        last.prox.ant = last;
        last = last.prox;
	}

	public void mostra()
	{
		for (CelulaDupla i = first.prox; i != null; i = i.prox) {
            MyIO.println("["+i.elemento.getId()+" ## "+i.elemento.getNome()+" ## "+i.elemento.getAltura()+" ## "+i.elemento.getPeso()+" ## "+i.elemento.getAnoNascimento()+" ## "+i.elemento.getUniversidade()+" ## "+i.elemento.getCidadeNascimento()+" ## "+i.elemento.getEstadoNascimento()+"]");
		}
	}

	public void mostraEstado() {
		int cont  = 0;
		for (CelulaDupla cel = first.prox; cel != null; cel = cel.prox, cont++) {
            MyIO.println(cont+" - "+cel.elemento.getEstadoNascimento());
		}
	}
}

