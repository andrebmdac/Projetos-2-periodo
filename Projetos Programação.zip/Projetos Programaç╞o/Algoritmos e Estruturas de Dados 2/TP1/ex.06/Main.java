public class Main{
    public static void main(String[] args){
        String str;
        str = MyIO.readLine();
        do{
        MyIO.print((isVogal(str))? "SIM " : "NAO ");
        MyIO.print((isConsoante(str))? "SIM " : "NAO ");
        MyIO.print((isInteiro(str))? "SIM " : "NAO ");
        MyIO.println((isReal(str))? "SIM" : "NAO");
        str = MyIO.readLine();
        }while(isFim(str)==false);
    }

    // função que testa se a string é composta apenas por vogais
    public static boolean isVogal(String str)
    {
       int cont=0;
       int tam=0;
       tam=str.length();
       // percorre toda a string testando se cada posição sua tem uma vogal e incrementando um contador
       for(int i=0;i<str.length();i++)
       {
           if(isUpper(str.charAt(i))=='A' || isUpper(str.charAt(i))=='E' || isUpper(str.charAt(i))=='I' || isUpper(str.charAt(i))=='O' || isUpper(str.charAt(i))=='U')
           {
               cont++;
           }
       }
       // caso o numero de vogais seja igual ao tamanho da string retorna true
       return(tam==cont && cont>0)?true:false;
    }

    // função que testa se a string é composta apenas por consoantes
    public static boolean isConsoante(String str)
    {
       int cont=0;
       for(int i=0;i<str.length();i++)
       {
           // percorre toda a string testando se cada posição sua tem uma consoante e incrementando um contador
           if((isUpper(str.charAt(i))!='A' && isUpper(str.charAt(i))!='E' && isUpper(str.charAt(i))!='I' && isUpper(str.charAt(i))!='O' && isUpper(str.charAt(i))!='U') && (isUpper(str.charAt(i))>='A' && isUpper(str.charAt(i))<='Z'))
           {
               cont++;
           }
       }
       // caso o numero de consoantes seja igual ao tamanho da string retorna true
       return(cont==str.length())?true:false;
    }

    // função que testa se a string é composta apenas por Números inteiros
    public static boolean isInteiro(String str)
    {
       int cont=0;
       for(int i=0;i<str.length();i++)
       {
           // percorre toda a string testando se cada posição sua tem um número incrementando um contador
           if(Character.isDigit(str.charAt(i))==true)
           {
               cont++;
           }
       }
       // caso a quantidade de números seja igual ao tamanho da string retorna true
       return(cont==str.length());
    }
    
    // função que testa se a string é composta apenas por Números
    public static boolean isReal(String str)
    {
       int contPV=0;
       int contNum=0;
       for(int i=0;i<str.length();i++)
       {
          // percorre toda a string testando se cada posição sua tem um número incrementando um contador
          if(Character.isDigit(str.charAt(i))==true)
          {
              contNum++;
          }
       }
       if(contNum==str.length())
       {
          return true;
       }
       else if(contNum==str.length()-1)
       {
          for(int i=0; i<str.length(); i++)
          {
              // percorre toda a string testando se cada posição sua tem um ponto ou vírgula incrementando um contador
              if(str.charAt(i)=='.' || str.charAt(i)==',')
              {
                contPV++;
              }
          }
          if(contPV==1)
          {
              return true;
          }
       }
       // caso não há retornado true ainda significa que é falso
       return false;
    }
    
    // função que transforma o caracter analisado em maiúsculo para ser analisado
    static char isUpper(char c){
        return (c >= 'a' && c <= 'z') ? (char)(c-32) : c;
    }

    // função booleana para testar se a string digitada é 'FIM' 
    public static boolean isFim(String s)
    {
       return (s.length() == 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }
}
