#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


int isVogal(char frase[1000]);
char isUpper(char c);
int isConsoante(char frase[1000]);
int isInt(char frase[]);
int isReal(char frase[]);


int main()
{
    char string[1000];
    do
    {
        fflush(stdin);
        fgets(string,1000,stdin);
        if(strcmp(string,"FIM\n")!=0)
        {
            if(isVogal(string)==1)
            {
                printf("SIM ");
            }
            else if(isVogal(string)==2)
            {
                printf("NAO ");
            }
            if(isConsoante(string)==1)
            {
                printf("SIM ");
            }
            else if(isConsoante(string)==2)
            {
                printf("NAO ");
            }
            if(isInt(string)==1)
            {
                printf("SIM ");
            }
            else if(isInt(string)==2)
            {
                printf("NAO ");
            }
            if(isReal(string)==1)
            {
                printf("SIM ");
            }
            else if(isReal(string)==2)
            {
                printf("NAO ");
            }
            printf("\n");
        }
    }while(strcmp(string,"FIM\n")!=0);
    return 0;
}

// função que transforma o caracter analisado em maiúsculo para ser analisado
char isUpper(char c)
{
   return(c>='a' && c<='z')?(char)(c-32):c;
}

// função que testa se a string é composta apenas por vogais
int isVogal(char frase[])
{
    int cont=0;
    int tam=0;
    tam=strlen(frase)-1;
    // percorre toda a string testando se cada posição sua tem uma vogal e incrementando um contador
    for(int i=0;i<tam;i++)
    {
       if(isUpper(frase[i])=='A' || isUpper(frase[i])=='E' || isUpper(frase[i])=='I' || isUpper(frase[i])=='O' || isUpper(frase[i])=='U')
        {
           cont++;
        }
    } 
    // caso o numero de vogais seja igual ao tamanho da string e o contador não esteja vazio retorna 1
    return(tam==cont && cont>0)?1:2;
}

// função que testa se a string é composta apenas por consoantes
int isConsoante(char frase[])
{
    int cont=0;
    int tam=0;
    tam=strlen(frase)-1;
    // percorre toda a string testando se cada posição sua tem uma consoante e incrementando um contador
    for(int i=0;i<tam;i++)
    {
       if((isUpper(frase[i])!='A' && isUpper(frase[i])!='E' && isUpper(frase[i])!='I' && isUpper(frase[i])!='O' && isUpper(frase[i])!='U') && (isUpper(frase[i])>='A' && (isUpper(frase[i])<='Z')))
        {
           cont++;
        }
    } 
    // caso o numero de consoantes seja igual ao tamanho da string e o contador não esteja vazio retorna 1
    return(cont==tam && cont>0)?1:2;
}

// função que testa se a string é composta apenas por Números inteiros
int isInt(char frase[])
{
    int cont=0;
    int tam=0;
    tam=strlen(frase)-1;
    for(int i=0;i<tam;i++)
    {
        // percorre toda a string testando se cada posição sua tem um número incrementando um contador
       if(isdigit(frase[i]))
       {
           cont++;
       }
    }
    // caso a quantidade de números seja igual ao tamanho da string e o contador for maior que 0 retorna 1
    return(cont==tam && cont>0)?1:2;
}

// função que testa se a string é composta apenas por Números
int isReal(char frase[])
{
    int cont=0;
    int contp=0;
    int tam=0;
    tam=strlen(frase)-1;
    for(int i=0;i<tam;i++)
    {
       // percorre toda a string testando se cada posição sua tem um número incrementando um contador
       if(isdigit(frase[i]))
       {
           cont++;
       }
       // percorre toda a string testando se cada posição sua tem um ponto ou vírgula incrementando um contador
       if(frase[i]==',' || frase[i]=='.')
       {
           cont++;
           contp++;
       }
    }
    // caso a quantidade de números seja igual ao tamanho da string-1 e tenha apenas UM ponto ou vírgula retorna 1
    return(cont==tam && cont>0 && contp>=0 && contp<=1)?1:2;
}
