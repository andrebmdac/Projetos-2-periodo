public class Main{
    public static void main(String[] args){
        String str;
        // faz o do while enquanto a string for diferente de 'FIM'
        do{
        str = MyIO.readLine();
        MyIO.println(fazCripto(str));
        }while(isFim(str)==false);
    }

    // função para fazer a criptografia de cesar de chave 3
    public static String fazCripto(String s)
    {
        String strNova="";
        char c=' ';
        // percorre toda a string original
        for(int i = 0; i < s.length(); i++)
        {
           // atribui ao char C o caracter presente na string na posição analisada
           c=s.charAt(i);
           // uma string auxiliar recebe o caracter de C somado 3 na tabela ASCII
           strNova+=(char)(c+3);
        }
        return(strNova);
    }
    
    // função booleana para testar se a string digitada é 'FIM' 
    public static boolean isFim(String s)
    {
       return (s.length() == 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }
}
