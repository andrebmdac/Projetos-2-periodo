public class Main{
    public static void main(String[] args){
        String str;
        str = MyIO.readLine();
        //faz o do while enquanto não encontrar a palavra "FIM"
        do{
        MyIO.println(fazCripto(str));
        str = MyIO.readLine();
        
        }while(isFim(str)==false);
    }

    // função para inicializar as variáveis da função de recurssão
    public static String fazCripto(String s)
    {
        return fazCripto(s,0);
    }

    // função para fazer a criptografia de cesar de chave 3
    public static String fazCripto(String s, int cont)
    {
        String strNova="";
        // testa se o contador ainda é menor que o tamanho da string
        if(cont<s.length())
        {
            char c=' ';
            c=s.charAt(cont);
            // string nova recebe a letra já criptografada
            strNova+=(char)(c+3);
            // quando a string chega na condição de parada ela volta printando
            strNova+=fazCripto(s,cont+1);
        }
        return strNova;
    }

    // função booleana para testar se a string digitada é 'FIM'
    public static boolean isFim(String s)
    {
       return (s.length() == 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }
}
