import java.io.*;

public class Main{
    public static void main(String[] args) throws Exception{
        int quantidade=MyIO.readInt();
        RandomAccessFile raf = new RandomAccessFile("numeros.txt", "rw");
        // escreve a (quantidade digitada de vezes) números double dentro do arquivo
        for(int i=0;i<quantidade;i++)
        {
            double x=MyIO.readDouble();
            raf.writeDouble(x);
        }
        raf.close();
        RandomAccessFile rF= new RandomAccessFile("numeros.txt","r");
        // marca uma posicao no ponto 8*quantidade pois foram (quantidade) números digitados e cada double ocupa 8 bytes
        int posicao=(8*quantidade);
        // como no arquivo existe uma linha a mais do que a escrita, volta-se 8 bytes, que é a primeira posição da última linha
        rF.seek(posicao-8);
        int cont=0;
        // percorre o arquivo printando o que está na linha \atual e voltando 8 bytes para a linha de cima
        do{
            if(cont!=0)
            {
                double x=rF.readDouble();
                //MyIO.println(rF.readDouble());
                if(x == (int)x){     
                    System.out.printf("%.0f\n", x);
                }
                else{               
                     MyIO.println(x);            
                }
            }
             posicao=posicao-8;
             rF.seek(posicao);
             cont++;
        }while(posicao>0);
        // como o while parou na posicao>0, a primeira linha do arquivo não foi lida, então marca-se o ponteiro na posição 0 e se lê o que está lá
        rF.seek(0);
        double x=rF.readDouble();
        if(x == (int)x){     
            System.out.printf("%.0f\n", x);
         }
        else{               
            MyIO.println(x);            
        }
        rF.close();
    }
}
    
