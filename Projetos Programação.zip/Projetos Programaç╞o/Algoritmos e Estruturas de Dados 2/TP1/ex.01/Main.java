public class Main{
    public static void main(String[] args){
        String str = MyIO.readLine(); 
        //faz o do while enquanto não encontrar a palavra "FIM"
        do{
        MyIO.println(verificaPalindromo(str));
        str=MyIO.readLine();
        }while(isFim(str)==false);
    }

    // função para verificar se é palindromo recebendo como parâmetro a string digitada
    public static String verificaPalindromo(String s)
    {
        int cont = 0;
        //percorre toda a string comparando a primeira e a ultima posicao ainda não analisadas para saber se são iguais
        for(int i = 0, n = s.length()-1; i < n; i++, n--)
            if(s.charAt(i) == s.charAt(n))
            {
                cont++;   
            }
        //se o contador for maior ou igual a metade do tamanho da string, a função retorna 'SIM', pois uma metade a igual a outra    
        return (cont >= (s.length()/2)) ? "SIM" : "NAO";
    }
    
    // função booleana para testar se a string digitada é 'FIM' 
    public static boolean isFim(String s)
    {
       return (s.length() == 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }
}




//String[] str = new String[1000];