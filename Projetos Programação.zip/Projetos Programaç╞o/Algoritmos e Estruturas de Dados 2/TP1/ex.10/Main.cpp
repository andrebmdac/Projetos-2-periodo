#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void fazLoop(int qtd, FILE *arq);

int main()
{
    int qtd=0;
    scanf("%i", &qtd);
    FILE *arq = fopen("numeros.txt","wb");
    // escreve a (quantidade digitada de vezes) números double dentro do arquivo
    for(int i=0;i<qtd;i++)
    {
        double agora=0;
        scanf("%lf", &agora);
        fwrite(&agora, sizeof(double), 1, arq);
    }
    fclose(arq);
    // abre o arquivo em modo binário
    arq = fopen("numeros.txt","rb");
    if(arq==NULL)
    {
        printf("erro!");
    }
    else
    {
        fazLoop(qtd,arq);
        fclose(arq);
    }
    return 0;
}

// função que percorre o arquivo lendo-o
void fazLoop(int qtd, FILE *arq)
{
    // faz enquanto a variavel contador for maior que 0
    if(qtd!=0)
    {
        double x;
        // lê o que está no arquivo naquela posição
        fread(&x, sizeof(double), 1, arq);
        fazLoop(qtd-1,arq);
        // quando começa a desempilhar a recursividade volta printando o valor encontrado na linha
        if(x == (int)x)
        {
            printf("%.0lf\n", x);
        }
        else
        {
            printf("%.3lf\n", x);
        }
    }
}


