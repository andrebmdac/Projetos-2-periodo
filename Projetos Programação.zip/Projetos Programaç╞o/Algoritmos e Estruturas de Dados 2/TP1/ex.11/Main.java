public class Main{
    public static void main(String[] args){
        String str = MyIO.readLine();
        //faz o do while enquanto não encontrar a palavra "FIM"
        do{
        MyIO.println(verificaPalindromo(str)?"SIM":"NAO");
        str=MyIO.readLine();

        }while(isFim(str)==false);
    }

    // função para inicializar os valores do loop
    public static boolean verificaPalindromo(String s)
    {
        return verificaPalindromo(s,0,(s.length()-1));
    }

    // função que faz o loop testando se a primeira e a última letra não testadas são iguais
    public static boolean verificaPalindromo(String s, int atCom, int atFim)
    {
        boolean resp=true;
        // testa se o marcador de letra inicial é menor que o tamanho e o marcador final de letra é maior que 0
        if(atCom<s.length()-1 && atFim>0)
        {
            // caso as letras analisadas sejam iguais chama a função testando as próximas posições 
            if(s.charAt(atCom)== s.charAt(atFim))
            {
                resp = verificaPalindromo(s,atCom+1,atFim-1);
            }
            // caso sejam diferentes a resp é definida como false e volta retornando false para todas as chamadas
            else
            {
                resp = false;
            }
        }
        return resp;
    }

    // função booleana para testar se a string digitada é 'FIM'
    public static boolean isFim(String s)
    {
       return (s.length() == 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }
}


