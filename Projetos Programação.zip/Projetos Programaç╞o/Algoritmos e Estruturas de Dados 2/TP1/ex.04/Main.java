import java.util.Random;

public class Main{
    public static void main(String[] args){
        String str;
        char base,troca;
        Random gerador = new Random();
        gerador.setSeed(4);
        str = MyIO.readLine();
        do{
        // recebe letra aleatória a ser trocada
        base=((char)('a'+(Math.abs( gerador.nextInt()) %26)));
        // receba letra aleatória que vai ser colocada
        troca=((char)('a'+(Math.abs( gerador.nextInt()) %26)));
        MyIO.println(fazTroca(str,base,troca));
        str = MyIO.readLine();
        }while(isFim(str)==false);
    }

    // função que recebe a string e as duas letras aleatórias e faz a troca
    public static String fazTroca(String s,char base,char troca)
    {
        String strNova="";
        for(int i = 0; i < s.length(); i++)
        {
            // testa se a string na posição analisada é igual a letra alvo, e caso seja faz a troca 
            if(s.charAt(i)==base)
            {
                strNova+=(char)(troca);
            }
            else
            {
                strNova+=s.charAt(i);
            }
        }
        return(strNova);
    }
    
    // função booleana para testar se a string digitada é 'FIM' 
    public static boolean isFim(String s)
    {
       return (s.length() == 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }
}
