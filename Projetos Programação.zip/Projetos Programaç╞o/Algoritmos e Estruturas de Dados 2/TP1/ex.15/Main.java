public class Main{
    public static void main(String[] args){
        String str;
        str = MyIO.readLine();
        do{
        MyIO.print((isVogal(str,0,str.length()-1))? "SIM " : "NAO ");
        MyIO.print((isConsoante(str,0,str.length()-1))? "SIM " : "NAO ");
        MyIO.print((isInteiro(str,0,str.length()-1))? "SIM " : "NAO ");
        MyIO.println((isReal(str,0,0,str.length()-1))? "SIM" : "NAO");
        str = MyIO.readLine();
        
        }while(isFim(str)==false);
    }

     // função que testa se a string é composta apenas por vogais
    public static boolean isVogal(String str, int cont, int tam)
    {
       // recebe o caractere maiúsculo na posição analisada
       char letra=isUpper(str.charAt(cont));
       // variável testa a condição esperada e recebe um valor true ou false
       boolean resp=(letra=='A' || letra=='E' || letra=='I' || letra=='O' || letra=='U');
       // condição de parada sendo a resposta false ou o contador já ter ultrapassado o tamanho da string
       if(cont>=tam || resp==false)
       {
           return resp;
       }
       else
       { 
           resp=isVogal(str,cont+1,tam);
       }
       // caso percorra toda a string e não seja false em nenhum momento, volta retornando true para todas
       return resp;   
    }

     // função que testa se a string é composta apenas por consoantes
    public static boolean isConsoante(String str, int cont, int tam)
    {
       // recebe o caractere maiúsculo na posição analisada
       char letra=isUpper(str.charAt(cont));
       // variável testa a condição esperada e recebe um valor true ou false
       boolean resp=((letra!='A' && letra!='E' && letra!='I' && letra!='O' && letra!='U') && Character.isDigit(str.charAt(cont))==false);
       // condição de parada sendo a resposta false ou o contador já ter ultrapassado o tamanho da string
       if(cont>=tam || resp==false)
       {
           return resp;
       }
       else
       {
           resp=isConsoante(str,cont+1,tam);
       }
        // caso percorra toda a string e não seja false em nenhum momento, volta retornando true para todas
       return resp;
    }

     // função que testa se a string é composta apenas por números inteiros 
    public static boolean isInteiro(String str, int cont, int tam)
    {
       // variável testa a condição esperada e recebe um valor true ou false
       boolean resp=(Character.isDigit(str.charAt(cont))==true);
       // condição de parada sendo a resposta false ou o contador já ter ultrapassado o tamanho da string
       if(cont>=tam || resp==false)
       {
           return resp;
       }
       else
       {
           resp=isInteiro(str,cont+1,tam);
       }
       // caso percorra toda a string e não seja false em nenhum momento, volta retornando true para todas
       return resp;
    }
    
     // função que testa se a string é composta apenas por números reais
    public static boolean isReal(String str, int cont,int contPV, int tam)
    {
       // variável testa a condição esperada e recebe um valor true ou false 
       boolean resp=((Character.isDigit(str.charAt(cont))==true) || (str.charAt(cont)=='.' || str.charAt(cont)==','));
       // variável testa a condição esperada e recebe um valor true ou false
       boolean respPV=(str.charAt(cont)=='.' || str.charAt(cont)==',');
       // caso o teste dê true, entra na condição incrementando o contPV em uma unidade
       if(respPV==true)
       {
           contPV++;
           // caso o contPV ultrapasse 1, volta retornando false para todas
           if(contPV>1)
           {
               return false;
           }
       }
       // condição de parada sendo a resposta false ou o contador já ter ultrapassado o tamanho da string
       if(cont>=tam || resp==false)
       {
           return resp;
       }
       else
       {
           resp=isReal(str,cont+1,contPV,tam);
       }
       // caso percorra toda a string e não seja false em nenhum momento, volta retornando true para todas
       return resp;
    }
    
    // função que transforma o caracter analisado em maiúsculo para ser analisado
    static char isUpper(char c){
        return (c >= 'a' && c <= 'z') ? (char)(c-32) : c;
    }

     // função booleana para testar se a string digitada é 'FIM'
    public static boolean isFim(String s)
    {
       return (s.length() == 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }
}