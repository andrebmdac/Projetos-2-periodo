#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int conferePalindromo(char frase[1000], int tam, int cont);

int main()
{
    char frase[1000];
    do
    {
        int resp=0;
        fflush(stdin);
        fgets(frase,1000,stdin);
        // verifica se a string digitada foi 'FIM'
        if(strcmp(frase,"FIM\n")!=0)
        {
            resp=conferePalindromo(frase, strlen(frase)-1, 0);
            // testa caso o valor retornado de resp seja maior ou igual a metade do tamanho
            if(resp>=(strlen(frase)/2))
            {
                printf("SIM\n");
            }
            else
            {
                printf("NAO\n");
            }
        }
    // faz a repetição enquanto a palavra digitada for diferente de 'FIM'    
    }while(strcmp(frase,"FIM\n")!=0);

    return 0;
}

// função para testar se é palindromo
int conferePalindromo(char frase[1000], int tam, int cont)
{
      int result=0;
      // testa se o marcador inicial é maior ou igual a 0, indicando que chegou ao final da string
      if(cont>=tam)
      {
          return 0;
      }
      else
      {
          // testa se a string na posição inicial testada é igual ao símbolo na posição final testada, e caso seja o resultado volta somado de 1, caso não volta somado de 0
          if(frase[cont]==frase[tam-1])
          {
              result+= 1+conferePalindromo(frase, tam-1,cont+1);
          }
          else
          {
              result+= 0+conferePalindromo(frase, tam-1, cont+1);
          }
      }
      // aqui retorna o valor da soma
      return result;
}