#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int conferePalindromo(char frase[200]);

int main()
{
    char frase[1000];
    do
    {
        int resp=0;
        fflush(stdin);
        fgets(frase,1000,stdin);
        // verifica se a string digitada foi 'FIM'
        if(strcmp(frase,"FIM")!=0)
        {
            resp=conferePalindromo(frase);
            if(resp==2)
            {
                printf("SIM\n");
            }
            else
            {
                printf("NAO\n");
            }
        }
    // faz a repetição enquanto a palavra digitada for diferente de 'FIM'    
    }while(strcmp(frase,"FIM")!=0);

    return 0;
}

// função para testar se é palindromo
int conferePalindromo(char frase[1000])
{
        char frase2[1000];
        int i,j,tam=0,valor=0;
        tam=strlen(frase);
        frase[tam-1]='\0';
        tam=0;
        // testa se a string digitada é 'fim' ou 'FIM'
        if(frase[0]=='f' && frase[1]=='i' &&frase[2]=='m' || frase[0]=='F' && frase[1]=='I' &&frase[2]=='M')
        {
            return 0;
        }
        tam=strlen(frase)-1;
        // uma string auxiliar recebe a string original ao contrário
        for(i=0;i<=tam;i++)
        {
            frase2[i]=frase[tam-i];
        }
        frase2[i]='\0';
        // percorre toda a string original eliminando os espaços
        for(i=0; i<=tam; i++)
        {
            if(frase[i] == ' ')
            {
                for(j=i; j<=tam; j++)
                {
                    frase[j] = frase[j+1];
                }
            }
        }
        // percorre toda a string auxiliar eliminando os espaços
        for(i=0; i<=tam; i++)
        {
            if(frase2[i] == ' ')
            {
                for(j=i; j<=tam; j++)
                {
                    frase2[j] = frase2[j+1];
                }
            }
        }
        // compara o conteúdo da string original com a auxiliar;
        valor=strcmp(frase,frase2);
        int marcador=0;
        if(valor==0)
        {
            // variável marcador recebe 2 se a string for palíndromo
            marcador+=2;
        }
        else
        {
            // variável marcador recebe 1 se a string não for palíndromo
            marcador++;
        }
        // retorna 2 se a string for palíndromo e 1 se não for
        return(marcador==2)?2:1;
}