public class Main{

    private static int vir=0;
    private static boolean[] teste=new boolean[3];
    private static String string=MyIO.readLine();

    public static void main(String[] args){
        int cont=0;
        do{
            cont=pegarVariaveis();
            substVariaveisPorValor();
            substBoolPorSimbolos();
            eliminaNumerosComeco(cont);
            substComUmaVirgula();
            fazNotX();
            substComUmaVirgula();
            tabelaVerdade();
            fazNotX();
            substComUmaVirgula();
            tabelaVerdade();
            substComDuasVirgulas();
            substComUmaVirgula();
            substComDuasVirgulas();
            substComTresVirgulas();
            substComUmaVirgula();
            tabelaVerdade();
            MyIO.println(string);
            string=MyIO.readLine();
        }while(string.charAt(0)!='0');
    }

    // função que pega os números antes da string e guarda um resultado booleano correspondente
    public static int pegarVariaveis()
    {
        int cont=0;
        int qtsVar=0;
        int i=0;
        // percorre a string enquanto a mesma nao chega no '(' de início da expressão
         do{
             // testa se a string na posicão analisada é um número
            if(Character.isDigit(string.charAt(i)))
            {
                // na primeira vez que percorre guarda a primeira variável como a quantidade de valores a serem substituidos
                if(cont==0)
                {
                    qtsVar=string.charAt(i)-48;
                    cont++;
                }
                // apartir daqui o programa testa se a valor naquela posição da string é 0 ou 1 , atribuindo a um array o resultado booleano associado ao número
                else if(cont==1)
                {
                    if(string.charAt(i)=='0')
                    {
                        teste[0]=false;
                    }
                    else
                    {
                        teste[0]=true;
                    }
                    cont++;
                }
                else if(cont==2)
                {
                    if(string.charAt(i)=='0')
                    {
                        teste[1]=false;
                    }
                    else
                    {
                        teste[1]=true;
                    }
                    cont++;
                }
                else if(cont==3)
                {
                    if(string.charAt(i)=='0')
                    {
                        teste[2]=false;
                    }
                    else
                    {
                        teste[2]=true;
                    }
                    cont++;
                }
            }
            i++;
        }while(string.charAt(i)!='(');
        return cont;
    }

    // função que utiliza o vetor gerado na função acima para preencher a expressão booleana com os números
    public static void substVariaveisPorValor()
    {
        String nova="";
        int posc=0;
        int tam=string.length();
        // percorre a string para saber quantas variávies vão ser substituídas
        for(int i=0;i<tam;i++)
        {
            if(string.charAt(i)>='0' && string.charAt(i)<='3')
            {
                posc=i;
                // finaliza a execução quando encontra a informação
                i=string.length();
            }
        }
        // percorre toda a string apartir do valor marcado buscando onde estão as letras para substituí-las
        for(int i=posc;i<tam;i++)
        {
            if(string.charAt(i)=='A')
            {
                // aqui usa-se o array booleano para saber se o 'A' será substituído por 0 ou 1
                if(teste[0]==true)
                {
                    nova+=1;
                }
                else if(teste[0]==false)
                {
                    nova+=0;
                }  
            }
            else if(string.charAt(i)=='B')
            {
                // aqui usa-se o array booleano para saber se o 'B' será substituído por 0 ou 1
                if(teste[1]==true)
                {
                    nova+=1;
                }
                else if(teste[1]==false)
                {
                    nova+=0;
                }   
            }
            else if(string.charAt(i)=='C')
            {
                // aqui usa-se o array booleano para saber se o 'C' será substituído por 0 ou 1
                if(teste[2]==true)
                {
                    nova+=1;
                }
                else if(teste[2]==false)
                {
                    nova+=0;
                }  
            }
            else
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
        nova="";
        // percorre a string eliminando os espaços
        for(int i=0;i<tam;i++)
        {
            if(string.charAt(i)!=' ')
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
    }

    // percorre a string buscando marcadores escritos booleanos
    public static void substBoolPorSimbolos()
    {
        String nova="";
        int tam=string.length();
        // percorre a string buscando por 'not' ou 'or' ou 'and' substituindo por simbolos booleanos
        for(int i=0;i<tam;i++)
        {
            if(string.charAt(i)=='n')
            {
                if(string.charAt(i+1)=='o')
                {
                    if(string.charAt(i+2)=='t')
                    {
                        nova+='~';
                        i+=2;
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else if(string.charAt(i)=='o')
            {
                if(string.charAt(i+1)=='r')
                {
                    nova+='v';
                    i++;
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else if(string.charAt(i)=='a')
            {
                if(string.charAt(i+1)=='n')
                {
                   if(string.charAt(i+2)=='d')
                   {
                       nova+='^';
                       i+=2;
                   }
                   else
                   {
                       nova+=string.charAt(i);
                   }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
    }

    // limpa a string tirando os números presentes no início
    public static void eliminaNumerosComeco(int cont)
    {
        String nova="";
        int tam=0;
        tam=string.length();
        // percorre a string começando o marcador na posição logo a frente do último número encontrado inicialmente
        for(int i=cont;i<tam;i++)
        {
            nova+=string.charAt(i);
        }
        string=nova;
    }

    // percorre a string buscando pela sequencia de marcador not com um numero entre parenteses
    public static void fazNotX()
    {
        String nova="";
        int tam=string.length();
        for(int i=0;i<tam;i++)
        {
            // faz a busca da sequencia desejada e caso encontrada substitui-a pelo resultado numérico
            if(string.charAt(i)=='~')
            {
                if(string.charAt(i+1)=='(')
                {
                    if(string.charAt(i+2)=='0')
                    {
                        if(string.charAt(i+3)==')')
                        {
                            nova+='1';
                            i+=3;
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else if(string.charAt(i+2)=='1')
                    {
                        if(string.charAt(i+3)==')')
                        {
                            nova+='0';
                            i+=3;
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
    }

    // percorre a string substituindo expressões que tem entre parênteses dois números e uma vírgula
    public static void substComUmaVirgula()
    {
        String nova="";
        int tam=string.length();
        for(int i=0;i<tam;i++)
        {
            // percorre a string testando se suas posições tem a sequência desejada, e caso tenha coloca o símbolo booleano substituindo a vírgula presente
            if(string.charAt(i)=='v')
            {
                if(string.charAt(i+1)=='(')
                {
                    if(string.charAt(i+2)=='1' || string.charAt(i+2)=='0')
                    {
                        if(string.charAt(i+3)==',')
                        {
                            if(string.charAt(i+4)=='1' || string.charAt(i+4)=='0')
                            {
                                if(string.charAt(i+5)==')')
                                {
                                    int j=i+1;
                                    do{
                                        if(string.charAt(j)==',')
                                        {
                                            nova+='v';
                                        }
                                        else
                                        {
                                            nova+=string.charAt(j);
                                        }
                                        j++;
                                    }while(string.charAt(j)!=')');
                                    nova+=')';
                                    i+=5;
                                }
                                else
                                {
                                    nova+=string.charAt(i);
                                }
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else if(string.charAt(i)=='^')
            {
                if(string.charAt(i+1)=='(')
                {
                    if(string.charAt(i+2)=='1' || string.charAt(i+2)=='0')
                    {
                        if(string.charAt(i+3)==',')
                        {
                            if(string.charAt(i+4)=='1' || string.charAt(i+4)=='0')
                            {
                                if(string.charAt(i+5)==')')
                                {
                                    int j=i+1;
                                    do{
                                        if(string.charAt(j)==',')
                                        {
                                            nova+='^';
                                        }
                                        else
                                        {
                                            nova+=string.charAt(j);
                                        }
                                        j++;
                                    }while(string.charAt(j)!=')');
                                    nova+=')';
                                    i+=5;
                                }
                                else
                                {
                                    nova+=string.charAt(i);
                                }
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
    }

    // percorre a string substituindo expressões que tem entre parênteses três números e duas vírgulas já dando seu resultado
    public static void substComDuasVirgulas()
    {
        String nova="";
        int tam=string.length();
        for(int i=0;i<tam;i++)
        {
            // percorre a string testando se suas posições tem a sequência desejada, e caso tenha já resolve a expressão booleana e guarda o resultado na string
            if(string.charAt(i)=='v')
            {
                if(string.charAt(i+1)=='(')
                {
                    if(string.charAt(i+2)=='1' || string.charAt(i+4)=='1' || string.charAt(i+6)=='1')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',')
                        {
                            if(string.charAt(i+7)==')')
                            {
                                nova+='1';
                                i+=7;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else if(string.charAt(i+2)=='0' && string.charAt(i+4)=='0' && string.charAt(i+6)=='0')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',')
                        {
                            if(string.charAt(i+7)==')')
                            {
                                nova+='0';
                                i+=7;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else if(string.charAt(i)=='^')
            {
                if(string.charAt(i+1)=='(')
                {
                    if(string.charAt(i+2)=='0' || string.charAt(i+4)=='0' || string.charAt(i+6)=='0')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',')
                        {
                            if(string.charAt(i+7)==')')
                            {
                                nova+='0';
                                i+=7;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else if(string.charAt(i+2)=='1' && string.charAt(i+4)=='1' && string.charAt(i+6)=='1')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',')
                        {
                            if(string.charAt(i+7)==')')
                            {
                                nova+='1';
                                i+=7;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else 
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
    } 

    // percorre a string substituindo expressões que tem entre parênteses quatro números e três vírgulas já dando seu resultado
    public static void substComTresVirgulas()
    {
        String nova="";
        int tam=string.length();
        for(int i=0;i<tam;i++)
        {
            // percorre a string testando se suas posições tem a sequência desejada, e caso tenha já resolve a expressão booleana e guarda o resultado na string
            if(string.charAt(i)=='v')
            {
                if(string.charAt(i+1)=='(')
                {
                    if(string.charAt(i+2)=='1' || string.charAt(i+4)=='1' || string.charAt(i+6)=='1' || string.charAt(i+8)=='1')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',' && string.charAt(i+7)==',')
                        {
                            if(string.charAt(i+9)==')')
                            {
                                nova+='1';
                                i+=9;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else if(string.charAt(i+2)=='0' && string.charAt(i+4)=='0' && string.charAt(i+6)=='0' && string.charAt(i+8)=='0')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',' && string.charAt(i+7)==',')
                        {
                            if(string.charAt(i+9)==')')
                            {
                                nova+='0';
                                i+=9;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else if(string.charAt(i)=='^')
            {
                if(string.charAt(i+1)=='(')
                {
                    if(string.charAt(i+2)=='0' || string.charAt(i+4)=='0' || string.charAt(i+6)=='0' || string.charAt(i+8)=='0')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',' && string.charAt(i+7)==',')
                        {
                            if(string.charAt(i+9)==')')
                            {
                                nova+='0';
                                i+=9;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else if(string.charAt(i+2)=='1' && string.charAt(i+4)=='1' && string.charAt(i+6)=='1' && string.charAt(i+8)=='1')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',' && string.charAt(i+7)==',')
                        {
                            if(string.charAt(i+9)==')')
                            {
                                nova+='1';
                                i+=9;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else 
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
    } 

    // funcção que resolve uma expressão booleana que tenha dois números e um operador relacional
    public static void tabelaVerdade()
    {
        String nova="";
        int tam=string.length();
        for(int i=0;i<tam;i++)
        {
            // busca pela sequência desejada, e caso encontre, da o resultado númerico da expressão booleana
            if(string.charAt(i)=='(')
            {
                if(string.charAt(i+1)=='1')
                {
                    if(string.charAt(i+2)=='v')
                    {
                        if(string.charAt(i+3)=='1')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='1';
                                i+=4;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else if(string.charAt(i+3)=='0')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='1';
                                i+=4;
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else if(string.charAt(i+2)=='^')
                    {
                        if(string.charAt(i+3)=='1')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='1';
                                i+=4;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else if(string.charAt(i+3)=='0')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='0';
                                i+=4;
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else if(string.charAt(i+1)=='0')
                {
                    if(string.charAt(i+2)=='v')
                    {
                        if(string.charAt(i+3)=='1')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='1';
                                i+=4;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else if(string.charAt(i+3)=='0')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='0';
                                i+=4;
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else if(string.charAt(i+2)=='^')
                    {
                        if(string.charAt(i+3)=='1')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='0';
                                i+=4;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else if(string.charAt(i+3)=='0')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='0';
                                i+=4;
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
    }
    
}



