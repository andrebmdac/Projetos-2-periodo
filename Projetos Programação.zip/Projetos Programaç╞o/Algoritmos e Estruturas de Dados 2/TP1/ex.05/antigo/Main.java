public class Main{

    private static int vir=0;
    private static boolean[] teste=new boolean[3];
    private static String string=MyIO.readLine();

    public static void main(String[] args){
        int cont=0;
        do{
            cont=pegarVal();
            substVal();
            substComp();
            arrumaString(cont);
            melhoraString();
            substVirgulaPequeno();
            tabelaVerdade();
            substVirgulaPequeno();
            tabelaVerdade();
            melhoraString();
            substVirgulaPequeno();
            tabelaVerdade();
            substVirgulaGrande();
            substVirgulaPequeno();
            substVirgulaGrande();
            tabelaVerdade();
            substVirgulaGigante();
            substVirgulaPequeno();
            tabelaVerdade();
            MyIO.println(string);
            string=MyIO.readLine();
        }while(string.charAt(0)!='0');
    }

    public static int pegarVal()
    {
        int cont=0;
        int qtsVar=0;
        int i=0;
        do{
            if(Character.isDigit(string.charAt(i)))
            {
                if(cont==0)
                {
                    qtsVar=string.charAt(i)-48;
                    cont++;
                }
                else if(cont==1)
                {
                    if(string.charAt(i)=='0')
                    {
                        teste[0]=false;
                    }
                    else
                    {
                        teste[0]=true;
                    }
                    cont++;
                }
                else if(cont==2)
                {
                    if(string.charAt(i)=='0')
                    {
                        teste[1]=false;
                    }
                    else
                    {
                        teste[1]=true;
                    }
                    cont++;
                }
                else if(cont==3)
                {
                    if(string.charAt(i)=='0')
                    {
                        teste[2]=false;
                    }
                    else
                    {
                        teste[2]=true;
                    }
                    cont++;
                }
            }
            i++;
        }while(string.charAt(i)!='(');
        return cont;
    }

    public static void substVal()
    {
        String nova="";
        int posc=0;
        int tam=string.length();
        for(int i=0;i<tam;i++)
        {
            if(string.charAt(i)>='0' && string.charAt(i)<='3')
            {
                posc=i;
                i=string.length();
            }
        }
        for(int i=posc;i<tam;i++)
        {
            if(string.charAt(i)=='A')
            {
                if(teste[0]==true)
                {
                    nova+=1;
                }
                else if(teste[0]==false)
                {
                    nova+=0;
                }  
            }
            else if(string.charAt(i)=='B')
            {
                if(teste[1]==true)
                {
                    nova+=1;
                }
                else if(teste[1]==false)
                {
                    nova+=0;
                }   
            }
            else if(string.charAt(i)=='C')
            {
                if(teste[2]==true)
                {
                    nova+=1;
                }
                else if(teste[2]==false)
                {
                    nova+=0;
                }  
            }
            else
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
        nova="";
        for(int i=0;i<tam;i++)
        {
            if(string.charAt(i)!=' ')
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
    }

    public static void substComp()
    {
        String nova="";
        int tam=string.length();
        for(int i=0;i<tam;i++)
        {
            if(string.charAt(i)=='n')
            {
                if(string.charAt(i+1)=='o')
                {
                    if(string.charAt(i+2)=='t')
                    {
                        nova+='~';
                        i+=2;
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else if(string.charAt(i)=='o')
            {
                if(string.charAt(i+1)=='r')
                {
                    nova+='v';
                    i++;
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else if(string.charAt(i)=='a')
            {
                if(string.charAt(i+1)=='n')
                {
                   if(string.charAt(i+2)=='d')
                   {
                       nova+='^';
                       i+=2;
                   }
                   else
                   {
                       nova+=string.charAt(i);
                   }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
    }

    public static void arrumaString(int cont)
    {
        String nova="";
        int tam=0;
        tam=string.length();
        for(int i=cont;i<tam;i++)
        {
            nova+=string.charAt(i);
        }
        string=nova;
    }

    public static void melhoraString()
    {
        String nova="";
        int tam=string.length();
        for(int i=0;i<tam;i++)
        {
            if(string.charAt(i)=='~')
            {
                if(string.charAt(i+1)=='(')
                {
                    if(string.charAt(i+2)=='0')
                    {
                        if(string.charAt(i+3)==')')
                        {
                            nova+='1';
                            i+=3;
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else if(string.charAt(i+2)=='1')
                    {
                        if(string.charAt(i+3)==')')
                        {
                            nova+='0';
                            i+=3;
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
    }

    public static void substVirgulaPequeno()
    {
        String nova="";
        int tam=string.length();
        for(int i=0;i<tam;i++)
        {
            if(string.charAt(i)=='v')
            {
                if(string.charAt(i+1)=='(')
                {
                    if(string.charAt(i+2)=='1' || string.charAt(i+2)=='0')
                    {
                        if(string.charAt(i+3)==',')
                        {
                            if(string.charAt(i+4)=='1' || string.charAt(i+4)=='0')
                            {
                                if(string.charAt(i+5)==')')
                                {
                                    int j=i+1;
                                    do{
                                        if(string.charAt(j)==',')
                                        {
                                            nova+='v';
                                        }
                                        else
                                        {
                                            nova+=string.charAt(j);
                                        }
                                        j++;
                                    }while(string.charAt(j)!=')');
                                    nova+=')';
                                    i+=5;
                                }
                                else
                                {
                                    nova+=string.charAt(i);
                                }
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else if(string.charAt(i)=='^')
            {
                if(string.charAt(i+1)=='(')
                {
                    if(string.charAt(i+2)=='1' || string.charAt(i+2)=='0')
                    {
                        if(string.charAt(i+3)==',')
                        {
                            if(string.charAt(i+4)=='1' || string.charAt(i+4)=='0')
                            {
                                if(string.charAt(i+5)==')')
                                {
                                    int j=i+1;
                                    do{
                                        if(string.charAt(j)==',')
                                        {
                                            nova+='^';
                                        }
                                        else
                                        {
                                            nova+=string.charAt(j);
                                        }
                                        j++;
                                    }while(string.charAt(j)!=')');
                                    nova+=')';
                                    i+=5;
                                }
                                else
                                {
                                    nova+=string.charAt(i);
                                }
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
    }

    public static void substVirgulaGrande()
    {
        String nova="";
        int tam=string.length();
        for(int i=0;i<tam;i++)
        {
            if(string.charAt(i)=='v')
            {
                if(string.charAt(i+1)=='(')
                {
                    if(string.charAt(i+2)=='1' || string.charAt(i+4)=='1' || string.charAt(i+6)=='1')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',')
                        {
                            if(string.charAt(i+7)==')')
                            {
                                nova+='1';
                                i+=7;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else if(string.charAt(i+2)=='0' && string.charAt(i+4)=='0' && string.charAt(i+6)=='0')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',')
                        {
                            if(string.charAt(i+7)==')')
                            {
                                nova+='0';
                                i+=7;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else if(string.charAt(i)=='^')
            {
                if(string.charAt(i+1)=='(')
                {
                    if(string.charAt(i+2)=='0' || string.charAt(i+4)=='0' || string.charAt(i+6)=='0')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',')
                        {
                            if(string.charAt(i+7)==')')
                            {
                                nova+='0';
                                i+=7;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else if(string.charAt(i+2)=='1' && string.charAt(i+4)=='1' && string.charAt(i+6)=='1')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',')
                        {
                            if(string.charAt(i+7)==')')
                            {
                                nova+='1';
                                i+=7;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else 
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
    } 

    public static void substVirgulaGigante()
    {
        String nova="";
        int tam=string.length();
        for(int i=0;i<tam;i++)
        {
            if(string.charAt(i)=='v')
            {
                if(string.charAt(i+1)=='(')
                {
                    if(string.charAt(i+2)=='1' || string.charAt(i+4)=='1' || string.charAt(i+6)=='1' || string.charAt(i+8)=='1')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',' && string.charAt(i+7)==',')
                        {
                            if(string.charAt(i+9)==')')
                            {
                                nova+='1';
                                i+=9;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else if(string.charAt(i+2)=='0' && string.charAt(i+4)=='0' && string.charAt(i+6)=='0' && string.charAt(i+8)=='0')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',' && string.charAt(i+7)==',')
                        {
                            if(string.charAt(i+9)==')')
                            {
                                nova+='0';
                                i+=9;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else if(string.charAt(i)=='^')
            {
                if(string.charAt(i+1)=='(')
                {
                    if(string.charAt(i+2)=='0' || string.charAt(i+4)=='0' || string.charAt(i+6)=='0' || string.charAt(i+8)=='0')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',' && string.charAt(i+7)==',')
                        {
                            if(string.charAt(i+9)==')')
                            {
                                nova+='0';
                                i+=9;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else if(string.charAt(i+2)=='1' && string.charAt(i+4)=='1' && string.charAt(i+6)=='1' && string.charAt(i+8)=='1')
                    {
                        if(string.charAt(i+3)==',' && string.charAt(i+5)==',' && string.charAt(i+7)==',')
                        {
                            if(string.charAt(i+9)==')')
                            {
                                nova+='1';
                                i+=9;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else 
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
    } 


    public static void tabelaVerdade()
    {
        String nova="";
        int tam=string.length();
        for(int i=0;i<tam;i++)
        {
            if(string.charAt(i)=='(')
            {
                if(string.charAt(i+1)=='1')
                {
                    if(string.charAt(i+2)=='v')
                    {
                        if(string.charAt(i+3)=='1')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='1';
                                i+=4;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else if(string.charAt(i+3)=='0')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='1';
                                i+=4;
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else if(string.charAt(i+2)=='^')
                    {
                        if(string.charAt(i+3)=='1')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='1';
                                i+=4;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else if(string.charAt(i+3)=='0')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='0';
                                i+=4;
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else if(string.charAt(i+1)=='0')
                {
                    if(string.charAt(i+2)=='v')
                    {
                        if(string.charAt(i+3)=='1')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='1';
                                i+=4;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else if(string.charAt(i+3)=='0')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='0';
                                i+=4;
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else if(string.charAt(i+2)=='^')
                    {
                        if(string.charAt(i+3)=='1')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='0';
                                i+=4;
                            }
                            else
                            {
                                nova+=string.charAt(i);
                            }
                        }
                        else if(string.charAt(i+3)=='0')
                        {
                            if(string.charAt(i+4)==')')
                            {
                                nova+='0';
                                i+=4;
                            }
                        }
                        else
                        {
                            nova+=string.charAt(i);
                        }
                    }
                    else
                    {
                        nova+=string.charAt(i);
                    }
                }
                else
                {
                    nova+=string.charAt(i);
                }
            }
            else
            {
                nova+=string.charAt(i);
            }
        }
        string=nova;
    }
    
}
