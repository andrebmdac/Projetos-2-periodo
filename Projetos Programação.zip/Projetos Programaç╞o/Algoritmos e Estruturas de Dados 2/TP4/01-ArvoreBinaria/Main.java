public class Main{
    public static Jogador[]vetorJogador = fileFill();
	public static arvoreBinaria arvoreBi = new arvoreBinaria();
    private static Jogador[] fileFill(){
		Jogador vetJog[] = new Jogador[5000];
        Arq.openRead("/tmp/players.csv");
		String line = Arq.readLine();
        line = Arq.readLine();
        int i = 0;
        while(Arq.hasNext())
		{
            vetJog[i] = new Jogador(line);
            line = Arq.readLine();
            i++;
        }
        vetJog[i] = new Jogador(line);
        Arq.close();
        return vetJog;
    }
    
    public static void main(String[]args) throws Exception{
        String line = MyIO.readString();
        do
		{
            arvoreBi.inserir(vetorJogador[Integer.parseInt(line)]);
            line = MyIO.readString();
        }while(!line.equals("FIM"));
        line = MyIO.readLine();
        double start = System.currentTimeMillis();
        do
		{
            MyIO.print(line);
            MyIO.println(arvoreBi.pesquisar(line) == true ? " SIM" : " NAO");
            line = MyIO.readLine();
        }while(!line.equals("FIM"));
        Arq.openWriteClose("matricula_arvoreBinaria.txt", "700481\t"+((System.currentTimeMillis()-start)/1000)+"\t"+arvoreBinaria.comps);
    }
}

class arvoreBinaria {
    private No raiz;
    public static int comps = 0;

    public arvoreBinaria(){
        this.raiz = null;
    }

    public void inserir(Jogador x) throws Exception{
		raiz = inserir(x, raiz);
    }
    
    private No inserir(Jogador x, No i) throws Exception{
	    if (i == null)
        i = new No(x);

        else if (x.getNome().compareTo(i.elemento.getNome()) < 0)
            i.esq = inserir(x, i.esq);

        else if (x.getNome().compareTo(i.elemento.getNome()) > 0)
            i.dir = inserir(x, i.dir);

        else 
            throw new Exception("Erro ao inserir!");

        return i;
	}

    public boolean pesquisar(String searchName){
        comps++;
        MyIO.print(" raiz");
        return pesquisar(searchName, raiz);
    }

    private boolean pesquisar(String searchName, No i){
        boolean resp;
        if(i == null)
            resp = false;
        else if(searchName.compareTo(i.elemento.getNome()) == 0){
            comps++;
            resp = true;
        }
        else if(searchName.compareTo(i.elemento.getNome()) < 0){
            comps++;
            MyIO.print(" esq");
            resp = pesquisar(searchName, i.esq);
        }
        else {
            comps++;
            MyIO.print(" dir");
            resp = pesquisar(searchName, i.dir);
        }
        return resp;
    }

    public void caminharCentral() {
		System.out.print("[ ");
		caminharCentral(raiz);
		System.out.println("]");
	}

	private void caminharCentral(No i) {
		if (i != null) {
			caminharCentral(i.esq); // Elementos da esquerda.
			System.out.print(i.elemento.getNome() + " "); // Conteudo do no.
			caminharCentral(i.dir); // Elementos da direita.
		}
	}
}

class No{
    public Jogador elemento;
    public No dir, esq;

    public No(Jogador elemento){
		this(elemento, null, null);
	}

	public No(Jogador elemento, No esq, No dir){
		this.elemento = elemento;
        this.dir = null;
        this.esq = null;
	}
}

class Jogador {
    private int id;
	private String nome;
	private int altura;
	private int peso;
	private String universidade;
	private int anoNascimento;
	private String cidadeNascimento;
	private String estadoNascimento;

	public Jogador() {
	}

	public Jogador(String linha) {
		String campos[] = linha.split(",");
		this.id = Integer.parseInt(campos[0]);
		this.nome = campos[1];
		this.altura = Integer.parseInt(campos[2]);
		this.peso = Integer.parseInt(campos[3]);
		this.universidade = (campos[4].isEmpty()) ? "nao informado" : campos[4];
		this.anoNascimento = Integer.parseInt(campos[5]);
		if (campos.length > 6) {
			this.cidadeNascimento = (campos[6].isEmpty())? "nao informado": campos[6];
			if (campos.length < 8) {
				this.estadoNascimento = "nao informado";
			} else {
				this.estadoNascimento = campos[7];
			}
		} else {
			this.cidadeNascimento = "nao informado";
			this.estadoNascimento = "nao informado";
		}
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public void setAnoNascimento(int anoNascimento){
		this.anoNascimento = anoNascimento;
	}

	public int getAnoNascimento(){
		return anoNascimento;
	}

	public String getUniversidade() {
		return universidade;
	}

	public void setUniversidade(String universidade) {
		this.universidade = universidade;
	}

	public String getCidadeNascimento() {
		return cidadeNascimento;
	}

	public void setCidadeNascimento(String cidadeNascimento) {
		this.cidadeNascimento = cidadeNascimento;
	}

	public String getEstadoNascimento() {
		return estadoNascimento;
	}

	public void setEstadoNascimetno(String estadoNascimento) {
		this.estadoNascimento = estadoNascimento;
	}

	public Jogador clone() {
		Jogador novo = new Jogador();
		novo.id = this.id;
		novo.nome = this.nome;
		novo.altura = this.altura;
		novo.anoNascimento = this.anoNascimento;
		novo.peso = this.peso;
		novo.universidade = this.universidade;
		novo.cidadeNascimento = this.cidadeNascimento;
		novo.estadoNascimento = this.estadoNascimento;
		return novo;
	}

	public void imprimir() {
		System.out.println("## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + " ##");
	}

	public String toString() {
		return "[" + id + " ## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + "]";
	}
}