class Main{
    public static Jogador[]vetorJogador = fileFill();
	public static Alvinegra arvore;
	private static Jogador[] fileFill()
   {
		Arq.openRead("/tmp/players.csv");
        Jogador vetJog[] = new Jogador[5000];
        String line = Arq.readLine();
        line = Arq.readLine();
        int i = 0;
        while(Arq.hasNext()){
            vetJog[i] = new Jogador(line);
            line = Arq.readLine();
            i++;
        }
        vetJog[i] = new Jogador(line);
        Arq.close();
        return vetJog;
    }

    public static void main(String[] args) throws Exception {
        arvore = new Alvinegra();
        String line = MyIO.readString();
        do{
            arvore.inserir(vetorJogador[Integer.parseInt(line)]);
            line = MyIO.readString();
        }while(!line.equals("FIM"));
        line = MyIO.readLine();
        double start = System.currentTimeMillis();
        do{
            MyIO.print(line);
            MyIO.println(arvore.pesquisar(line) == true ? " SIM" : " NAO");
            line = MyIO.readLine();
        }while(!line.equals("FIM"));
        Arq.openWriteClose("matricula_alvinegra.txt", "700481\t"+((System.currentTimeMillis()-start)/1000)+"\t"+Alvinegra.comps);
    }
}

class NoAN{
    public boolean cor;
    public Jogador elemento;
    public NoAN esq, dir;

    public NoAN (){
        this(null);
    }

    public NoAN (Jogador elemento){
        this(elemento, false, null, null);
    }

    public NoAN (Jogador elemento, boolean cor){
        this(elemento, cor, null, null);
    }

    public NoAN (Jogador elemento, boolean cor, NoAN esq, NoAN dir){
        this.cor = cor;
        this.elemento = elemento;
        this.esq = esq;
        this.dir = dir;
    }
}


class Alvinegra{
    private NoAN raiz;
    public static int comps = 0;

    public Alvinegra(){
        raiz = null;
    }

    public boolean pesquisar(String elemento) {
        comps++;
        MyIO.print(" raiz");
		return pesquisar(elemento, raiz);
	}

    private boolean pesquisar(String elemento, NoAN i) {
        boolean resp;
          if (i == null) {
           resp = false;
  
        } else if (elemento.compareTo(i.elemento.getNome()) == 0) {
            comps++;
            resp = true;
  
        } else if (elemento.compareTo(i.elemento.getNome()) < 0) {
            comps++;
            MyIO.print(" esq");
           resp = pesquisar(elemento, i.esq);
  
        } else {
            comps++;
            MyIO.print(" dir");
           resp = pesquisar(elemento, i.dir);

        }
        return resp;
    }

     private void inserir(Jogador elemento, NoAN bisavo, NoAN avo, NoAN pai, NoAN i) throws Exception {
		if (i == null) {

         if(elemento.getNome().compareTo(pai.elemento.getNome()) < 0){
            i = pai.esq = new NoAN(elemento, true);
         } else {
            i = pai.dir = new NoAN(elemento, true);
         }

         if(pai.cor == true){
            balancear(bisavo, avo, pai, i);
         }

      } else
       {
         if(i.esq != null && i.dir != null && i.esq.cor == true && i.dir.cor == true){
            i.cor = true;
            i.esq.cor = i.dir.cor = false;
            if(i == raiz){
               i.cor = false;
            }else if(pai.cor == true){
               balancear(bisavo, avo, pai, i);
            }
         }
         if (elemento.getNome().compareTo(i.elemento.getNome()) < 0) {
            inserir(elemento, avo, pai, i, i.esq);
         } else if (elemento.getNome().compareTo(i.elemento.getNome()) > 0) {
            inserir(elemento, avo, pai, i, i.dir);
         } else {
            throw new Exception("Erro inserir (elemento repetido)!");
         }
      }
    }

    public void inserir(Jogador elemento) throws Exception {
   
        //Se a arvore estiver vazia
        if(raiz == null){
           raiz = new NoAN(elemento, false);
  
        //Senao, se a arvore tiver um elemento 
        } else if (raiz.esq == null && raiz.dir == null){
           if (raiz.elemento.getNome().compareTo(elemento.getNome()) > 0){
              raiz.esq = new NoAN(elemento, true);
           } else {
              raiz.dir = new NoAN(elemento, true);
           }
  
        //Senao, se a arvore tiver dois elementos (raiz e dir)
        } else if (raiz.esq == null){
  
           if(raiz.elemento.getNome().compareTo(elemento.getNome()) > 0){
              raiz.esq = new NoAN(elemento);
  
           } else if (raiz.dir.elemento.getNome().compareTo(elemento.getNome()) > 0){
              raiz.esq = new NoAN(raiz.elemento);
              raiz.elemento = elemento;
  
           } else {
              raiz.esq = new NoAN(raiz.elemento);
              raiz.elemento = raiz.dir.elemento;
              raiz.dir.elemento = elemento;
           }
  
           raiz.esq.cor = raiz.dir.cor = false;
           
        //Senao, se a arvore tiver dois elementos (raiz e esq)
        } else if (raiz.dir == null){
           
           if(raiz.elemento.getNome().compareTo(elemento.getNome()) < 0){
              raiz.dir = new NoAN(elemento);
           } else if (raiz.esq.elemento.getNome().compareTo(elemento.getNome()) < 0){
              raiz.dir = new NoAN(raiz.elemento);
              raiz.elemento = elemento;
           } else {
              raiz.dir = new NoAN(raiz.elemento);
              raiz.elemento = raiz.esq.elemento;
              raiz.esq.elemento = elemento;
           }
  
           raiz.esq.cor = raiz.dir.cor = false;
  
        //Senao, a arvore tem tres ou mais elementos
        } else {
             inserir(elemento, null, null, null, raiz);
        }
  
        raiz.cor = false;
    }
    
    private void balancear(NoAN bisavo, NoAN avo, NoAN pai, NoAN i){

        //Se o pai tambem e preto, reequilibrar a arvore, rotacionando o avo
        if(pai.cor == true){
  
           //4 tipos de reequilibrios e acoplamento
           if(pai.elemento.getNome().compareTo(avo.elemento.getNome()) > 0){ // rotacao a esquerda ou direita-esquerda
              if(i.elemento.getNome().compareTo(pai.elemento.getNome()) > 0){
                 avo = rotacaoEsq(avo);
              } else {
                 avo = rotacaoDirEsq(avo);
              }
  
           } else { // rotacao a direita ou esquerda-direita
              if(i.elemento.getNome().compareTo(pai.elemento.getNome()) < 0){
                 avo = rotacaoDir(avo);
              } else {
                 avo = rotacaoEsqDir(avo);
              }
           }
  
           if (bisavo == null){
              raiz = avo;
           } else {
              if(avo.elemento.getNome().compareTo(bisavo.elemento.getNome()) < 0){
                 bisavo.esq = avo;
              } else {
                 bisavo.dir = avo;
              }
           }
  
           //reestabelecer as cores apos a rotacao
           avo.cor = false;
           avo.esq.cor = avo.dir.cor = true;
        } //if(pai.cor == true)
    }

    private NoAN rotacaoDir(NoAN no) {
        NoAN noEsq = no.esq;
        NoAN noEsqDir = noEsq.dir;
  
        noEsq.dir = no;
        no.esq = noEsqDir;
  
        return noEsq;
    }
  
    private NoAN rotacaoEsq(NoAN no) {
        NoAN noDir = no.dir;
        NoAN noDirEsq = noDir.esq;
  
        noDir.esq = no;
        no.dir = noDirEsq;
        return noDir;
    }
  
    private NoAN rotacaoDirEsq(NoAN no) {
        no.dir = rotacaoDir(no.dir);
        return rotacaoEsq(no);
    }
  
    private NoAN rotacaoEsqDir(NoAN no) {
        no.esq = rotacaoEsq(no.esq);
        return rotacaoDir(no);
    }

    public void mostrarPre() {
		mostrarPre(raiz);
	}

	private void mostrarPre(NoAN i) {
		if (i != null) {
			System.out.print(i.elemento.getNome() + ((i.cor) ? "(p) " : "(b) ")); // Conteudo do no.
			mostrarPre(i.esq); // Elementos da esquerda.
			mostrarPre(i.dir); // Elementos da direita.
		}
	}
}


class Jogador {
    private int id;
	private String nome;
	private int altura;
	private int peso;
	private String universidade;
	private int anoNascimento;
	private String cidadeNascimento;
	private String estadoNascimento;

	public Jogador() {
	}

	public Jogador(String linha) {
		String campos[] = linha.split(",");
		this.id = Integer.parseInt(campos[0]);
		this.nome = campos[1];
		this.altura = Integer.parseInt(campos[2]);
		this.peso = Integer.parseInt(campos[3]);
		this.universidade = (campos[4].isEmpty()) ? "nao informado" : campos[4];
		this.anoNascimento = Integer.parseInt(campos[5]);
		if (campos.length > 6) {
			this.cidadeNascimento = (campos[6].isEmpty())? "nao informado": campos[6];
			if (campos.length < 8) {
				this.estadoNascimento = "nao informado";
			} else {
				this.estadoNascimento = campos[7];
			}
		} else {
			this.cidadeNascimento = "nao informado";
			this.estadoNascimento = "nao informado";
		}
	}

	// id,Player,height,weight,collage,born,birth_city,birth_state

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public void setAnoNascimento(int anoNascimento){
		this.anoNascimento = anoNascimento;
	}

	public int getAnoNascimento(){
		return anoNascimento;
	}

	public String getUniversidade() {
		return universidade;
	}

	public void setUniversidade(String universidade) {
		this.universidade = universidade;
	}

	public String getCidadeNascimento() {
		return cidadeNascimento;
	}

	public void setCidadeNascimento(String cidadeNascimento) {
		this.cidadeNascimento = cidadeNascimento;
	}

	public String getEstadoNascimento() {
		return estadoNascimento;
	}

	public void setEstadoNascimetno(String estadoNascimento) {
		this.estadoNascimento = estadoNascimento;
	}

	public Jogador clone() {
		Jogador novo = new Jogador();
		novo.id = this.id;
		novo.nome = this.nome;
		novo.altura = this.altura;
		novo.anoNascimento = this.anoNascimento;
		novo.peso = this.peso;
		novo.universidade = this.universidade;
		novo.cidadeNascimento = this.cidadeNascimento;
		novo.estadoNascimento = this.estadoNascimento;
		return novo;
	}

	public void imprimir() {
		System.out.println("## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + " ##");
	}

	public String toString() {
		return "[" + id + " ## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + "]";
	}
}