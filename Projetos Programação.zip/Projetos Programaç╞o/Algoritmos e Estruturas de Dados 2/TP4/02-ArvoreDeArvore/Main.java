class Main{
	public static Jogador[]vetorJogador = fileFill();
	public static treeOfTree arvore = new treeOfTree();
	public static int[]vetorTeste = {7,3,11,1,5,9,13,0,2,4,6,8,10,12,14};
	private static Jogador[] fileFill(){
		Arq.openRead("/tmp/players.csv");
        Jogador vetJog[] = new Jogador[5000];
        String line = Arq.readLine();
        line = Arq.readLine();
        int i = 0;
        while(Arq.hasNext()){
            vetJog[i] = new Jogador(line);
            line = Arq.readLine();
            i++;
        }
        vetJog[i] = new Jogador(line);
        Arq.close();
        return vetJog;
    }

	public static void main(String[]args){
		int tam=vetorTeste.length;
		for(int i = 0; i < tam; i++){
			arvore.insere(vetorTeste[i]);
		}
		String line = MyIO.readString();
		do{
			int num = Integer.parseInt(line);
			arvore.insereNomes(vetorJogador[num].getNome(), (vetorJogador[num].getAltura()%15));
			line = MyIO.readString();
		}while(!line.equals("FIM"));
		line = MyIO.readLine();
		double start = System.currentTimeMillis();
		do{
			MyIO.print(line);
			arvore.caminhaArvUm(line);
			MyIO.println(arvore.teste == true ? " SIM" : " NAO");
			line = MyIO.readLine();
		}while(!line.equals("FIM"));
		Arq.openWriteClose("matricula_arvoreArvore.txt", "700481\t"+((System.currentTimeMillis()-start)/1000)+"\t"+treeOfTree.comps);
		
	}

}

class noAux{
    noAux dir, esq;
    String name;

    noAux(String name){
        this.name = name;
        this.esq = this.dir = null;
    }

    noAux(String name, noAux dir, noAux esq){
        this.name = name;
        this.esq = esq;
        this.dir = dir;
    }
}

class No{
    int mod;
	No dir, esq;
    noAux prox;

    No(int mod){
       this.mod = mod;
       this.esq = this.dir = null;
       this.prox = null;
    }

    No(int mod, No esq, No dir){
        this.mod = mod;
        this.esq = esq;
        this.dir = dir;
        this.prox = null;
    }
}

class Jogador {
    private int id;
	private String nome;
	private int altura;
	private int peso;
	private String universidade;
	private int anoNascimento;
	private String cidadeNascimento;
	private String estadoNascimento;

	public Jogador() {
	}

	public Jogador(String linha) {
		String campos[] = linha.split(",");
		this.id = Integer.parseInt(campos[0]);
		this.nome = campos[1];
		this.altura = Integer.parseInt(campos[2]);
		this.peso = Integer.parseInt(campos[3]);
		this.universidade = (campos[4].isEmpty()) ? "nao informado" : campos[4];
		this.anoNascimento = Integer.parseInt(campos[5]);
		if (campos.length > 6) {
			this.cidadeNascimento = (campos[6].isEmpty())? "nao informado": campos[6];
			if (campos.length < 8) {
				this.estadoNascimento = "nao informado";
			} else {
				this.estadoNascimento = campos[7];
			}
		} else {
			this.cidadeNascimento = "nao informado";
			this.estadoNascimento = "nao informado";
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public void setAnoNascimento(int anoNascimento){
		this.anoNascimento = anoNascimento;
	}

	public int getAnoNascimento(){
		return anoNascimento;
	}

	public String getUniversidade() {
		return universidade;
	}

	public void setUniversidade(String universidade) {
		this.universidade = universidade;
	}

	public String getCidadeNascimento() {
		return cidadeNascimento;
	}

	public void setCidadeNascimento(String cidadeNascimento) {
		this.cidadeNascimento = cidadeNascimento;
	}

	public String getEstadoNascimento() {
		return estadoNascimento;
	}

	public void setEstadoNascimetno(String estadoNascimento) {
		this.estadoNascimento = estadoNascimento;
	}

	public Jogador clone() {
		Jogador novo = new Jogador();
		novo.id = this.id;
		novo.nome = this.nome;
		novo.altura = this.altura;
		novo.anoNascimento = this.anoNascimento;
		novo.peso = this.peso;
		novo.universidade = this.universidade;
		novo.cidadeNascimento = this.cidadeNascimento;
		novo.estadoNascimento = this.estadoNascimento;
		return novo;
	}

	public void imprimir() {
		System.out.println("## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + " ##");
	}

	public String toString() {
		return "[" + id + " ## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + "]";
	}
}

class treeOfTree{
	private No raiz;
	public static int comps = 0;
	public boolean teste = false;

    treeOfTree(){
        raiz = null;
	}
	
	public void insere(int x){
		raiz = insere(x, raiz);
	}

	private No insere(int x, No i){
		if(i == null)
			i = new No(x);
		else if(x < i.mod)
			i.esq = insere(x, i.esq);
		else if(x > i.mod)
			i.dir = insere(x, i.dir);
		else System.out.println("Nao foi possivel fazer a insercao");
		return i;
	}

	public void insereNomes(String x, int novo){
		No rootSecTree = pesquisaArvUm(novo);
		rootSecTree.prox = insereNome(x, rootSecTree.prox);
	}

	private noAux insereNome(String x, noAux i){
		if(i == null)
			i = new noAux(x);
		else if(x.compareTo(i.name) < 0)
			i.esq = insereNome(x, i.esq);
		else if(x.compareTo(i.name) > 0)
			i.esq = insereNome(x, i.dir);
		else System.out.println("Nao foi possivel fazer a insercao");

		return i;
	}

	private No pesquisaArvUm(int novo){
		return pesquisaArvUm(novo, raiz);
	}

	private No pesquisaArvUm(int mod, No i){
		No resp;
		if(mod == i.mod){
			resp = i;
		}
		else if(mod < i.mod){
			resp = pesquisaArvUm(mod, i.esq);
		}
		else{
			resp = pesquisaArvUm(mod, i.dir);
		}
        return resp;
	}

	public void caminhaArvUm(String x){
		this.teste = false;
		MyIO.print(" raiz");
		caminhaArvUm(x, raiz);
	}

	private void caminhaArvUm(String x, No i){
		if(i != null && this.teste == false){
			if(i.prox != null)
				pesquisaArvDois(i.prox, x);
			if(this.teste == false){
				MyIO.print(" esq");
				caminhaArvUm(x, i.esq);
				if(this.teste == false){
					MyIO.print(" dir");
					caminhaArvUm(x, i.dir);
				}
			}
		}
	}

	private boolean pesquisaArvDois(noAux i, String x){
		boolean result = false;
		if(x.compareTo(i.name) == 0){
			result = true;
		}
		else if(x.compareTo(i.name) < 0){
			MyIO.print(" ESQ");
			if(i.esq != null)
				result = pesquisaArvDois(i.esq, x);
		}
		else{
			MyIO.print(" DIR");
			if(i.dir != null)
				result = pesquisaArvDois(i.dir, x);
		}
		this.teste = result;
		return result;
	}
	
}
