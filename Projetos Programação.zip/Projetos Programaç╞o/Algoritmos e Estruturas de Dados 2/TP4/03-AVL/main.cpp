#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define tamanhoMax 5000
#define tamanhoMaxLinha 150

typedef struct {
    int id;
    int peso;
    int altura;
    char nome[70];
    char universidade[70];
    int anoNascimento;
    char cidadeNascimento[70];
    char estadoNascimento[70];
}Jogador;

typedef struct No{
    Jogador elemento;
    struct No* esq;
    struct No* dir;
    int posicao;
}No;

bool pesquisar(char line[], No* i);
Jogador vetJog[tamanhoMax];

No* novoNo(Jogador i){
    No* novo = (No*)malloc(sizeof(No));
    novo->elemento = i;
    novo->esq = NULL;
    novo->dir = NULL;
    novo->posicao = 1;
}

No* novoNoAux(Jogador i, No* esq, No* dir, int ultPos){
    No* novo = (No*)malloc(sizeof(No));
    novo->elemento = i;
    novo->esq = esq;
    novo->dir = dir;
    novo->posicao = ultPos;
}

int getPos(No* i){
    return (i == NULL) ? 0 : i->posicao;
}

int maxAtual(int x, int y){
    return (x > y) ? x : y;
}

int setPos(No* i){
    i->posicao = 1 + maxAtual(getPos(i->esq), getPos(i->dir));
    return i->posicao;
}

No* raiz;

void comeco(){
    raiz = NULL;
}

bool pesquisar(char line[], No* i){
    bool res = false;
    if(i == NULL)
        res = false;
    else if(strcmp(line, i->elemento.nome) == 0){
        res = true;
    }
    else if(strcmp(line, i->elemento.nome) < 0){
        printf(" esq");
        res = pesquisar(line, i->esq);
    }
    else {
        printf(" dir");
        res = pesquisar(line, i->dir);
    }
    return res;
}

No* rotacaoAEsq(No* i){
    No* noDir = i->dir;
    No* noDirEsq = noDir->esq;
    noDir->esq = i;
    i->dir = noDirEsq;
    setPos(i);
    setPos(noDir);
    return noDir;
}

No* rotacaoADir(No* i){
    No* noEsq = i->esq;
    No* noEsqDir = noEsq->dir;
    noEsq->dir = i;
    i->esq = noEsqDir;

    setPos(i);
    setPos(noEsq);
    return noEsq;
}


No* balanceamento(No* i){
    if(i != NULL){
        int numero = getPos(i->dir) - getPos(i->esq);
        if(abs(numero) <= 1){
            setPos(i);
        }else if(numero == 2){
            int filhoDireita = getPos(i->dir->dir) - getPos(i->dir->esq);
            if(filhoDireita == -1){
                i->dir = rotacaoADir(i->dir);
            }
            i = rotacaoAEsq(i);
        }else if(numero == -2){
            int filhoEsquerda = getPos(i->esq->dir) - getPos(i->esq->esq);
            if(filhoEsquerda == 1){
                i->esq = rotacaoAEsq(i->esq);
            }
            i = rotacaoADir(i);
        }else printf("Erro!");
    }
    return i;
}

No* insereParteDois(Jogador x, No* i){
    if(i == NULL)
        i = novoNo(x);
    else if(strcmp(x.nome, i->elemento.nome) < 0)
        i->esq = insereParteDois(x, i->esq);
    else if(strcmp(x.nome, i->elemento.nome) > 0)
        i->dir = insereParteDois(x, i->dir);
    else
        printf("Erro!");
    return balanceamento(i);
}

void insereNf(char *linha, char *linhaNova) 
{
    int tam = strlen(linha);
    for (int i = 0; i <= tam; i++, linha++) {
        *linhaNova++ = *linha;
        if (*linha == ',' && (*(linha + 1) == ',' || *(linha + 1) == '\0')) 
        {
            strcpy(linhaNova, "nao informado");
            linhaNova += strlen("nao informado");
        }
    }
}


void insere(Jogador x){
    raiz = insereParteDois(x, raiz);
}

void removeQuebraLinha(char linha[]) 
{
    int tam = strlen(linha);
    if (linha[tam - 2] == '\r' && linha[tam - 1] == '\n')
    {
        linha[tam - 2] = '\0';
    }
    else if (linha[tam - 1] == '\r' || linha[tam - 1] == '\n')
    {
        linha[tam - 1] = '\0';
    }
}

void leArquivo(Jogador *jogador, char linha[]) {
    char linhaNova[tamanhoMaxLinha];
    removeQuebraLinha(linha);
    insereNf(linha, linhaNova);
    jogador->id = atoi(strtok(linhaNova, ","));
    strcpy(jogador->nome, strtok(NULL, ","));
    jogador->altura = atoi(strtok(NULL, ","));
    jogador->peso = atoi(strtok(NULL, ","));
    strcpy(jogador->universidade, strtok(NULL, ","));
    jogador->anoNascimento = atoi(strtok(NULL, ","));
    strcpy(jogador->cidadeNascimento, strtok(NULL, ","));
    strcpy(jogador->estadoNascimento, strtok(NULL, ","));
}

void pesquisarNomes(){
    char linha[tamanhoMaxLinha];
    scanf(" %[^\n]", linha);
    do{
        printf("%s", linha);
        printf(" raiz");
        printf(" %s\n", (pesquisar(linha, raiz)) ? "SIM" : "NAO");
        scanf(" %[^\n]", linha);
    }while(!strcmp(linha, "FIM") == 0);
}

void preencherInicial(){
    FILE *csv = fopen("/tmp/players.csv", "r");
    char * infoLeitura[8];
    char line[tamanhoMaxLinha];
    int i = 0;
    fgets(line, 1024, csv);
    fgets(line, 1024, csv);
    while(!feof(csv)){
        leArquivo(&vetJog[i], line);
        i++;
        fgets(line, 1024, csv);
    }
    fclose(csv);
}

void preencheArvoreVL(){
    char linha[tamanhoMaxLinha];
    scanf("%s", linha);
    do{
        insere(vetJog[atoi(linha)]);
        scanf("%s", linha);
    }while(!strcmp(linha, "FIM") == 0);
}

int main(){
    comeco();
    preencherInicial();
    preencheArvoreVL();
    pesquisarNomes();
    return 0;
}