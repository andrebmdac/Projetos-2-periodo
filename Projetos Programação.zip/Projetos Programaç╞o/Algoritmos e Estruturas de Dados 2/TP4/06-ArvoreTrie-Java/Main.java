import java.util.*;

public class Main {
	public static Jogador[]vetorJogador = fileFill();
	public static ArvoreTrie arvoreT = new ArvoreTrie();
	public static ArvoreTrie arvoreT2 = new ArvoreTrie();
	
	private static Jogador[] fileFill(){
		Arq.openRead("/tmp/players.csv");
        Jogador vetJog[] = new Jogador[5000];
        String line = Arq.readLine();
        line = Arq.readLine();
        int i = 0;
        while(Arq.hasNext()){
            vetJog[i] = new Jogador(line);
            line = Arq.readLine();
            i++;
        }
        vetJog[i] = new Jogador(line);
        Arq.close();
        return vetJog;
    }

	public static void main(String[] args) {
		StringBuffer stringB = new StringBuffer();
		String line = MyIO.readString();
		do{
			arvoreT.insert(vetorJogador[Integer.parseInt(line)].getNome());
			stringB.append(line + "\t" + vetorJogador[Integer.parseInt(line)].getNome() + "\n");
			line = MyIO.readString();
		}while(!line.equals("FIM"));
		line = MyIO.readString();
		Lista list = new Lista();
		do{
			arvoreT2.insert(vetorJogador[Integer.parseInt(line)].getNome());
			stringB.append(line + "\t" + vetorJogador[Integer.parseInt(line)].getNome() + "\n");
			list.inserir(Integer.parseInt(line));
			line = MyIO.readString();
		}while(!line.equals("FIM"));
		double start = System.currentTimeMillis();
		int[]vetor = list.vetorLista();
		int tam=vetor.length;
		for(int i = 0; i < tam; i++){
			if(!arvoreT.contains(vetorJogador[vetor[i]].getNome())){
				arvoreT.insert(vetorJogador[vetor[i]].getNome());
			}
		}
		line = MyIO.readLine();
		do{
			if(arvoreT.contains(line))
				stringB.append(line + " SIM\n");
			else stringB.append(line + " NAO\n");
			line = MyIO.readLine();
		}while(!line.equals("FIM"));
		MyIO.print(stringB.toString());
		Arq.openWriteClose("matricula_arvoreTrie.txt", "700481\t"+((System.currentTimeMillis()-start)/1000)+"\t"+arvoreT.comps);
	}

}

class ArvoreTrie{
	private No raiz;
	public int comps = 0;
	
	public ArvoreTrie() {
		raiz = new No();
	}
	
	public void insert(String word) {
	    No current = raiz;

	    for (char c : word.toCharArray()) {
	    	current = current.getChildren().computeIfAbsent(c, n -> new No());
	    }
	    current.setEndOfWord(true);
	}
	
	boolean contains(String word) {
        No current = raiz;

        for (int i = 0; i < word.length(); i++) {
			comps++;
            char ch = word.charAt(i);
            No node = current.getChildren().get(ch);
            if (node == null) {
                return false;
            }
            current = node;
        }
        return current.isEndOfWord();
    }
}

class NoLista{
	public int item;
	public NoLista prox;

	public NoLista(int item){
		this(item, null);
	}

	public NoLista(int item, NoLista prox){
		this.item = item;
		this.prox = prox;
	}
}

class No{
	private HashMap<Character, No> children = new HashMap<>();
    private boolean testePalavra;
    
    public Map<Character, No> getChildren() {
    	return this.children;
    }
    
    public boolean isEndOfWord() {
    	return this.testePalavra;
    }
    
    public void setEndOfWord(boolean x) {
    	this.testePalavra = x;
    }
}

class Jogador {
    private int id;
	private String nome;
	private int altura;
	private int peso;
	private String universidade;
	private int anoNascimento;
	private String cidadeNascimento;
	private String estadoNascimento;

	public Jogador() {
	}

	public Jogador(String linha) {
		String campos[] = linha.split(",");
		this.id = Integer.parseInt(campos[0]);
		this.nome = campos[1];
		this.altura = Integer.parseInt(campos[2]);
		this.peso = Integer.parseInt(campos[3]);
		this.universidade = (campos[4].isEmpty()) ? "nao informado" : campos[4];
		this.anoNascimento = Integer.parseInt(campos[5]);
		if (campos.length > 6) {
			this.cidadeNascimento = (campos[6].isEmpty())? "nao informado": campos[6];
			if (campos.length < 8) {
				this.estadoNascimento = "nao informado";
			} else {
				this.estadoNascimento = campos[7];
			}
		} else {
			this.cidadeNascimento = "nao informado";
			this.estadoNascimento = "nao informado";
		}
	}

	// id,Player,height,weight,collage,born,birth_city,birth_state

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public void setAnoNascimento(int anoNascimento){
		this.anoNascimento = anoNascimento;
	}

	public int getAnoNascimento(){
		return anoNascimento;
	}

	public String getUniversidade() {
		return universidade;
	}

	public void setUniversidade(String universidade) {
		this.universidade = universidade;
	}

	public String getCidadeNascimento() {
		return cidadeNascimento;
	}

	public void setCidadeNascimento(String cidadeNascimento) {
		this.cidadeNascimento = cidadeNascimento;
	}

	public String getEstadoNascimento() {
		return estadoNascimento;
	}

	public void setEstadoNascimetno(String estadoNascimento) {
		this.estadoNascimento = estadoNascimento;
	}

	public Jogador clone() {
		Jogador novo = new Jogador();
		novo.id = this.id;
		novo.nome = this.nome;
		novo.altura = this.altura;
		novo.anoNascimento = this.anoNascimento;
		novo.peso = this.peso;
		novo.universidade = this.universidade;
		novo.cidadeNascimento = this.cidadeNascimento;
		novo.estadoNascimento = this.estadoNascimento;
		return novo;
	}

	public void imprimir() {
		System.out.println("## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + " ##");
	}

	public String toString() {
		return "[" + id + " ## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + "]";
	}
}

class Lista{
	private NoLista first;
	private NoLista last;
	public int quantidade = 0;

	public Lista(){
		first = new NoLista(-1);
		last = first;
	}

	public void inserir(int item){
		last.prox = new NoLista(item);
		last = last.prox;
		quantidade++;
	}

	public int[] vetorLista(){
		NoLista aux = first.prox;
		int[]vet = new int[quantidade];
		for(int i = 0; aux != null; aux = aux.prox, i++)
			vet[i] = aux.item;
		return vet;
	}
}

