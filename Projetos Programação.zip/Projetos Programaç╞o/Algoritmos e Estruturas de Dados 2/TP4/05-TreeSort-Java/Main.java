class Main{
    public static Jogador[]vetorJogador = fileFill();
    public static TreeSort arvoreBinaria = new TreeSort();

    private static Jogador[] fileFill(){
		Arq.openRead("/tmp/players.csv");
        Jogador vetJog[] = new Jogador[5000];
        String line = Arq.readLine();
        line = Arq.readLine();
        int i = 0;
        while(Arq.hasNext()){
            vetJog[i] = new Jogador(line);
            line = Arq.readLine();
            i++;
        }
        vetJog[i] = new Jogador(line);
        Arq.close();
        return vetJog;
    }

    public static void main(String[]args){
        String line = MyIO.readString();
        do{
            arvoreBinaria.insert(vetorJogador[Integer.parseInt(line)]);
            line = MyIO.readString();
        }while(!line.equals("FIM"));
        line = MyIO.readLine();
        double start = System.currentTimeMillis();
        do{
            line = MyIO.readLine();
        }while(!line.equals("FIM"));
        arvoreBinaria.inOrder();
        Arq.openWriteClose("matricula_treesort.txt", "700481\t"+((System.currentTimeMillis()-start)/1000)+"\t"+arvoreBinaria.comps);
    }
}

class TreeSort{
    private No raiz;
    public int comps = 0;
    public TreeSort(){
        raiz = null;
    }
    public void insert(Jogador item){
        raiz = insert(item, raiz);
    }
    private No insert(Jogador x, No i){
        if(i == null)
            return new No(x);
        else if (x.getNome().compareTo(i.item.getNome()) < 0)
            i.esq = insert(x, i.esq);
        else if (x.getNome().compareTo(i.item.getNome()) > 0)
            i.dir = insert(x, i.dir);
        else 
            System.out.println("Erro!");
        return i;
    }
    public void inOrder(){
        inOrder(raiz);
    }

    private void inOrder(No agora){
        if(agora != null){
            inOrder(agora.esq);
            MyIO.println(agora.item.getNome()+" ");
            inOrder(agora.dir);
        }
    }
}

class Jogador {
    private int id;
	private String nome;
	private int altura;
	private int peso;
	private String universidade;
	private int anoNascimento;
	private String cidadeNascimento;
	private String estadoNascimento;

	public Jogador() {
	}

	public Jogador(String linha) {
		String campos[] = linha.split(",");
		this.id = Integer.parseInt(campos[0]);
		this.nome = campos[1];
		this.altura = Integer.parseInt(campos[2]);
		this.peso = Integer.parseInt(campos[3]);
		this.universidade = (campos[4].isEmpty()) ? "nao informado" : campos[4];
		this.anoNascimento = Integer.parseInt(campos[5]);
		if (campos.length > 6) {
			this.cidadeNascimento = (campos[6].isEmpty())? "nao informado": campos[6];
			if (campos.length < 8) {
				this.estadoNascimento = "nao informado";
			} else {
				this.estadoNascimento = campos[7];
			}
		} else {
			this.cidadeNascimento = "nao informado";
			this.estadoNascimento = "nao informado";
		}
	}

	// id,Player,height,weight,collage,born,birth_city,birth_state

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public void setAnoNascimento(int anoNascimento){
		this.anoNascimento = anoNascimento;
	}

	public int getAnoNascimento(){
		return anoNascimento;
	}

	public String getUniversidade() {
		return universidade;
	}

	public void setUniversidade(String universidade) {
		this.universidade = universidade;
	}

	public String getCidadeNascimento() {
		return cidadeNascimento;
	}

	public void setCidadeNascimento(String cidadeNascimento) {
		this.cidadeNascimento = cidadeNascimento;
	}

	public String getEstadoNascimento() {
		return estadoNascimento;
	}

	public void setEstadoNascimetno(String estadoNascimento) {
		this.estadoNascimento = estadoNascimento;
	}

	public Jogador clone() {
		Jogador novo = new Jogador();
		novo.id = this.id;
		novo.nome = this.nome;
		novo.altura = this.altura;
		novo.anoNascimento = this.anoNascimento;
		novo.peso = this.peso;
		novo.universidade = this.universidade;
		novo.cidadeNascimento = this.cidadeNascimento;
		novo.estadoNascimento = this.estadoNascimento;
		return novo;
	}

	public void imprimir() {
		System.out.println("## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + " ##");
	}

	public String toString() {
		return "[" + id + " ## " + nome + " ## " + altura + " ## " + peso + " ## " + anoNascimento + " ## "
				+ universidade + " ## " + cidadeNascimento + " ## " + estadoNascimento + "]";
	}
}

class No{
    public Jogador item;
    public No esq, dir;

    public No(Jogador item){
        this(item, null, null);
    }

    public No(Jogador item, No esq, No dir){
        this.item = item;
        this.esq = esq;
        this.dir = dir;
    }
}
