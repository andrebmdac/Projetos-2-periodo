import java.util.Scanner;

public class Main
{
	public static void main(String[] args) {
	    
	    Scanner entrada = new Scanner(System.in);
	    String frase;
	    String s1="fim";
	    String s2="FIM";
	 do{   
	    //System.out.print("Digite uma frase: ");
	    frase=entrada.nextLine();
	    //System.out.println(frase);
	    String frase2 = new StringBuilder(frase).reverse().toString();
	    //System.out.println(frase2);
	    if((frase.equals(s1)) || (frase.equals(s2)))
	    {
	       //System.out.println("Saindo do programa");
	       System.exit(0);
	    }
	    //int tam=0;
	    //tam=frase.length();
        //frase = frase.replaceAll(" ","");
        //frase2 = frase2.replaceAll(" ","");
        if((frase.equals(frase2)))
        {
            System.out.println("SIM");
        }
        else
        {
            System.out.println("NAO");
        }
        
	    
	 }while((! frase.equals(s1)) || (! frase.equals(s2)));
	    
	  entrada.close();
	}
}



