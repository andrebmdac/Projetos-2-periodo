#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

int main()
{
    setlocale(LC_ALL,"Portuguese");
    char *frase;
    frase=(char *)calloc(200,sizeof(char));
    do
    {
        char *frase2;
        frase2=(char *)calloc(200,sizeof(char));;
        int i,j,tam=0,valor=0;
        fflush(stdin);
        //printf("Digite uma frase: ");
        //gets(frase);
        fgets(frase,200,stdin);
        tam=strlen(frase);
        frase[tam-1]='\0';
        tam=0;
        if(frase[0]=='f' && frase[1]=='i' &&frase[2]=='m' || frase[0]=='F' && frase[1]=='I' &&frase[2]=='M')
        {
            //printf("\nSaindo do programa!\n");
            return 0;
        }
        ////strcpy(frase2, frase);
        tam=strlen(frase)-1;
        //printf("\nFrase digitada: %s", frase);
        ////strrev(frase2);
        for(i=0;i<=tam;i++)
        {
            frase2[i]=frase[tam-i];
        }
        frase2[i]='\0';
        for(i=0; i<=tam; i++)
        {
            if(frase[i] == ' ')
            {
                for(j=i; j<=tam; j++)
                {
                    frase[j] = frase[j+1];
                }
            }
        }
        for(i=0; i<=tam; i++)
        {
            if(frase2[i] == ' ')
            {
                for(j=i; j<=tam; j++)
                {
                    frase2[j] = frase2[j+1];
                }
            }
        }
        valor=strcmp(frase,frase2);
        if(valor==0)
        {
            //printf("\nA frase digitada e um palindromo: SIM\n\n");
            printf("SIM\n");
        }
        else
        {
           // printf("\nA frase digitada e um palindromo: NAO\n\n");
           printf("NAO\n");
        }
    }while(frase[0]!='f' && frase[1]!='i' &&frase[2]!='m' || frase[0]!='F' && frase[1]!='I' &&frase[2]!='M');

    return 0;
}
