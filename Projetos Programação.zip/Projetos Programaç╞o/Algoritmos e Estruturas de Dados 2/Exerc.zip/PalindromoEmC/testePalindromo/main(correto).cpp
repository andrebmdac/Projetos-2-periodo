#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char frase[200];
    char frase2[200];
    int i=0,j=0,tam=0,valor=0;
    do
    {
        i=0;
        j=0;
        valor=0;
        tam=0;
        fflush(stdin);
        //printf("Digite uma frase: ");
        //gets(frase);
        fgets(frase,200,stdin);
        tam=strlen(frase);
        frase[tam-1]='\0';
        tam=0;
        if((strcmp(frase, "fim") == 0) || (strcmp(frase, "FIM") == 0))
        {
            //printf("\nSaindo do programa!\n");
            return 0;
        }
        ////strcpy(frase2, frase);
        tam=strlen(frase)-1;
        //printf("\nFrase digitada: %s", frase);
        ////strrev(frase2);
        for(i=0;i<=tam;i++)
        {
            frase2[i]=frase[tam-i];
        }
        frase2[i]='\0';
        for(i=0; i<=tam; i++)
        {
            if(frase[i] == ' ')
            {
                for(j=i; j<=tam; j++)
                {
                    frase[j] = frase[j+1];
                }
            }
        }
        for(i=0; i<=tam; i++)
        {
            if(frase2[i] == ' ')
            {
                for(j=i; j<=tam; j++)
                {
                    frase2[j] = frase2[j+1];
                }
            }
        }
        valor=strcmp(frase,frase2);
        if(valor==0)
        {
            //printf("\nA frase digitada e um palindromo: SIM\n\n");
            printf("SIM\n");
        }
        else
        {
           // printf("\nA frase digitada e um palindromo: NAO\n\n");
           printf("NAO\n");
        }
    }while((strcmp(frase, "fim") != 0) || (strcmp(frase, "FIM") != 0));

    return 0;
}