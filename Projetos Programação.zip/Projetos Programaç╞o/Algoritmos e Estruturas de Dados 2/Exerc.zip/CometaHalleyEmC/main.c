#include <stdio.h>
#include <stdlib.h>

int main()
{
    int ultimoAno=1986,tempo=76,anoAtual=0,proxAno=0,i=0;
    //printf("Digite o ano atual: ");
    scanf("%i", &anoAtual);
 while(anoAtual!=0)
 {
    if(anoAtual>=2000 & anoAtual<=3000)
    {
        do{
           i++;
           proxAno=ultimoAno+(tempo*i);
        }while(proxAno<anoAtual);
        if(proxAno==anoAtual)
        {
            proxAno=proxAno+tempo;
        }
        //printf("\nO proximo ano sera: %i\n", proxAno);
        printf("%i\n", proxAno);
    }
    scanf("%i", &anoAtual);
    i=0;
  }
    return 0;
}