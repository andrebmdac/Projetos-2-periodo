import java.util.Scanner;

public class Main
{
	public static void main(String[] args) {
	    
	    int idadeMonica=0;
	    int filho1=0;
	    int filho2=0;
	    int filho3=0;
	    Scanner entrada = new Scanner(System.in);
	 
	    //System.out.println("Digite a idade de dona monica: ");
	    idadeMonica=entrada.nextInt();
	    while(idadeMonica!=0)
	    {
	        //System.out.println("Digite a idade do filho 1: ");
	        filho1=entrada.nextInt();
	        //System.out.println("Digite a idade do filho 2: ");
	        filho2=entrada.nextInt();
	         if(((idadeMonica-filho1)-filho2)>0)
	         {
	            filho3=((idadeMonica-filho1)-filho2);
	            if(filho3>=filho1 && filho3>=filho2)
	            {
	                System.out.println(filho3);
	            }
	            else
	            {
	                if(filho3<=filho2 && filho3>=filho1)
                     {
                       System.out.println(filho2);
                     }
                     else if(filho3>=filho2 && filho3<=filho1)
                     {
                       System.out.println(filho1);
                     }

	            }
	         }
	    idadeMonica=entrada.nextInt();
	   }
	  entrada.close();  
	}
}