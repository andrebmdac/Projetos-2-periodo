#include <stdio.h>
#include <stdlib.h>

int main()
{
    int idadeMonica=0,filho1=0,filho2=0,filho3=0;
    //printf("Digite a idade da dona Monica: ");
    scanf("%i", &idadeMonica);
    while(idadeMonica!=0)
    {
       //printf("Digite a idade do filho mais novo: ");
       scanf("%i", &filho1);
       //printf("Digite a idade do filho do meio: ");
       scanf("%i", &filho2);
      if(((idadeMonica-filho1)-filho2)>0)
      {
        filho3=((idadeMonica-filho1)-filho2);
        if(filho3>=filho1 && filho3>=filho2)
        {
            //printf("\nA idade do mais velho e: %i\n", filho3);
            printf("%i\n", filho3);
        }
        else
        {
            if(filho3<=filho2 && filho3>=filho1)
            {
                //printf("\nA idade do mais velho e: %i\n", filho2);
                printf("%i\n", filho2);
            }
            else if(filho3<=filho2 && filho3<=filho1)
            {
                if(filho2>=filho1)
                {
                    printf("%i\n", filho2);
                }
                else
                {
                    printf("%i\n", filho1);
                }
            }
            else if(filho3>=filho2 && filho3<=filho1)
            {
                //printf("\nA idade do mais velho e: %i\n", filho1);
                printf("%i\n", filho1);
            }
            else if(filho2<=filho1 && filho3<=filho2)
            {
                if(filho1>=filho2)
                {
                    printf("%i\n", filho1);
                }
                else
                {
                    printf("%i\n", filho2);
                }
            }
        }
      }
      scanf("%i", &idadeMonica);
    }
    return 0;
}



