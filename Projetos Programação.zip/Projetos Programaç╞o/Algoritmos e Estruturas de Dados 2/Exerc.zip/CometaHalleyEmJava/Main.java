import java.util.Scanner;

public class Main
{
	public static void main(String[] args) {
	    
	    int ultimoAno=1986;
	    int tempo=76;
	    int anoAtual=0;
	    int proxAno=0;
	    int i=0;
	    Scanner entrada = new Scanner(System.in);
	    //System.out.println("Digite o ano atual: ");
	    anoAtual=entrada.nextInt();
	    while(anoAtual!=0)
	    {
	      if(anoAtual>=2000 & anoAtual<=3000)
	      {
	          do{
                  i++;
                  proxAno=ultimoAno+(tempo*i);
              }while(proxAno<anoAtual);
              if(proxAno==anoAtual)
              {
                  proxAno=proxAno+tempo;
              }
              System.out.println(proxAno);
	      }
	      i=0;
	      anoAtual=entrada.nextInt();
	    }
	  entrada.close();  
	}
}